import{K as o}from"./LowCode2.js";import{L as y}from"./logger.js";import{bK as d,bL as S,bM as f,ax as u,ao as g,ap as i,bN as h}from"./utils.js";import{a as x}from"./index2.js";const w={labelCol:6,wrapperCol:12,"x-reactions":{dependencies:[{__DO_NOT_USE_THIS_PROPERTY_index__:0,property:"value",type:"any"}],fulfill:{run:`const handleFormMount = async () => {
  const remoteSchemaSpin = $form.query("remoteSchemaSpin").take()
  const remoteSchemaUrl = $utils.getQueryString("remoteSchemaUrl")
  if (!remoteSchemaUrl) {
    $message.error("请指定远程 schema 参数 remoteSchemaUrl")
    remoteSchemaSpin.componentProps.tip =
      "请指定远程 schema 参数 remoteSchemaUrl"
    return
  }

  const cacheKey = \`remoteSchemaUrl\${remoteSchemaUrl}\`

  let startTime = Date.now()
  // $logger.info("加载缓存 schema start")
  let cachedSchema = null
  const cachedSchemaStr = await $chrome.localStorage.getItem(cacheKey)
  if (cachedSchemaStr) {
    try {
      cachedSchema = JSON.parse(cachedSchemaStr)
      // $logger.info("加载缓存的远程 schema success", Date.now() - startTime)
      $setFormilySchema(cachedSchema)
    } catch (e) {
      $logger.error("解析缓存的远程 schema 失败", remoteSchemaUrl, e)
    }
  } else {
    // $logger.info("没有缓存的远程 schema", remoteSchemaUrl)
  }

  startTime = Date.now()
  // $logger.info("加载远程 schema start")
  try {
    const schema = await fetch(remoteSchemaUrl).then((res) => res.json())
    // $logger.info("加载远程 schema success", Date.now() - startTime)
    if (!cachedSchema) {
      /**
       * 本地有缓存，就用缓存的数据，新拉取的数据给下一次使用
       * 本地没有缓存，则用最新的拉取的数据来展示
       */
      $setFormilySchema(schema)
    }

    // 缓存
    $chrome.localStorage.setItem(cacheKey, JSON.stringify(schema))
  } catch (e) {
    $logger.error("加载远程 schema 失败", e)
    remoteSchemaSpin.componentProps.tip = "加载远程 schema 失败"
  }
}

$formilyCore.onFormMount(() => {
  handleFormMount()
})
`}}},b={type:"object",properties:{remoteSchemaSpin:{type:"void","x-component":"Spin","x-validator":[],"x-component-props":{size:"small",tip:"加载中",style:{}},name:"remoteSchemaSpin","x-designable-id":"p7b4f72q3t8","x-index":0,properties:{om92ryckno4:{type:"void","x-component":"Div","x-component-props":{style:{padding:"150px 150px 150px 150px"}},"x-designable-id":"om92ryckno4","x-index":0}}}},"x-designable-id":"s9csump7v6w"},D={form:w,schema:b},P={labelCol:6,wrapperCol:12},$={type:"object",properties:{q5l4kmucw83:{type:"void","x-component":"Div","x-component-props":{className:"absolute inset-0 size-full bg-white bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]",style:{display:"flex",flexDirection:"column",alignItems:"center",padding:"24px 24px 24px 24px",justifyContent:"flex-start"}},"x-designable-id":"q5l4kmucw83","x-index":0,properties:{uts9yegcx7e:{type:"void","x-component":"Div","x-component-props":{style:{width:"100%"}},"x-designable-id":"uts9yegcx7e","x-index":0,properties:{previewDynamicSchemaBlock:{type:"void","x-component":"DynamicSchemaBlock","x-component-props":{schema:{},cacheRemoteSchema:!0,valueType:"object",reset:!0,style:{}},name:"previewDynamicSchemaBlock","x-reactions":{dependencies:[{__DO_NOT_USE_THIS_PROPERTY_index__:0,property:"value",type:"any"}],fulfill:{run:`const remoteDynamicSchemaBlockUrl = $utils.getQueryString(
  "remoteDynamicSchemaBlockUrl"
)
$logger.info("remoteDynamicSchemaBlockUrl", remoteDynamicSchemaBlockUrl)

if (remoteDynamicSchemaBlockUrl) {
  $props({
    schemaUrl: remoteDynamicSchemaBlockUrl,
  })
}
`}},"x-designable-id":"0cmk2fiptmh","x-index":0}}}}}},"x-designable-id":"pkzf1e50zr4"},k={form:P,schema:$},c=new y("lowCodeApi"),U=()=>({type:"void","x-component":"DynamicSchemaBlock","x-component-props":{schema:{},cacheRemoteSchema:!0,valueType:"object",reset:!0,schemaUrl:"https://gitee.com/bingoogolapple/bga-god-assistant-config/raw/master/buildSelfSchema/PresetDynamicSchemaBlock.json"},"x-designable-id":"ifdbo0e2br7","x-index":999999,name:"presetDynamicSchemaBlock"}),p=async e=>{try{return await fetch(e).then(a=>a.json())}catch{throw g.error("获取默认页面配置失败"),new Error("获取默认页面配置失败")}},m=async(e=l())=>{const t=await u();if(!t)throw g.error("获取扩展配置信息失败"),new Error("获取扩展配置信息失败");return Object.keys(t.defaultSchema).includes(e)?await p(t.defaultSchema[e]):await p(t.defaultSchema.demo)},v=async()=>{var e;try{if(h){if(i("remoteSchemaUrl"))return D;if(i("remoteDynamicSchemaBlockUrl"))return k}const t=await B(),a=t==null?void 0:t.jsonSchema;if(!a)return m();const r=JSON.parse(a);if(h){const s=U();(e=r==null?void 0:r.schema)!=null&&e.properties&&(r.schema.properties[s.name]=s)}return r}catch(t){return c.error("loadFormilySchema error",t),m()}},N=async()=>{const e=await v();return x(e)},_=async(e,t)=>{const a=await m(e);return{id:e,name:t,desc:t,jsonSchema:JSON.stringify(a),isBuiltIn:!1}},n=async(e,t,a)=>{let r=e.find(s=>s.id===t);r||(r=await _(t,a),r.isBuiltIn=!0,await S({[`${o.Prefix}${r.id}`]:r}),e.unshift(r),c.info("添加默认的",r.id))},R=async()=>{try{let e=[],t=await d();return(!t||Object.keys(t).length===0)&&(t={},c.info("record 为空")),Object.keys(t).forEach(a=>{a.startsWith(o.Prefix)&&e.push(t[a])}),await n(e,o.ElementsSidebarPane,"元素边栏面板页"),await n(e,o.DevtoolsPanel,"开发者面板页"),await n(e,o.SidePanel,"边栏页"),await n(e,o.Popup,"弹出式窗口"),await n(e,o.NewTab,"新标签页"),await n(e,o.Demo,"各种示例(待完善)"),e.sort((a,r)=>r.updateTime-a.updateTime)}catch(e){throw c.error("requestLowCodePageList error",e),e}},E=async e=>{try{await S({[`${o.Prefix}${e.id}`]:{...e,updateTime:Date.now()}})}catch(t){throw c.error("addOrUpdateLowCodePage error",t),t}},I=async e=>{try{await f(`${o.Prefix}${e}`)}catch(t){throw c.error("removeLowCodePage error",t),t}},l=()=>i("pageId")||"demo",T=(e=l())=>`${o.Prefix}${e}`,B=async(e=l())=>{const t=T(e);let a=await d(t);return a==null?void 0:a[t]};export{E as a,m as b,I as c,B as g,N as l,R as r};
