import{K as a}from"./LowCode2.js";import{L as p}from"./logger.js";import{bK as h,bL as l,bM as f,ax as u,an as d,ap as S,bN as w}from"./utils.js";import{a as y}from"./index2.js";const P={labelCol:6,wrapperCol:12,"x-reactions":{dependencies:[{__DO_NOT_USE_THIS_PROPERTY_index__:0,property:"value",type:"any"}],fulfill:{run:`const handleFormMount = async () => {
  const remoteSchemaSpin = $form.query("remoteSchemaSpin").take()
  const remoteSchemaUrl = $utils.getQueryString("remoteSchemaUrl")
  if (!remoteSchemaUrl) {
    $message.error("请指定远程 schema 参数 remoteSchemaUrl")
    remoteSchemaSpin.componentProps.tip =
      "请指定远程 schema 参数 remoteSchemaUrl"
    return
  }

  const cacheKey = \`remoteSchemaUrl\${remoteSchemaUrl}\`

  let startTime = Date.now()
  // $logger.info("加载缓存 schema start")
  let cachedSchema = null
  const cachedSchemaStr = await $chrome.localStorage.getItem(cacheKey)
  if (cachedSchemaStr) {
    try {
      cachedSchema = JSON.parse(cachedSchemaStr)
      // $logger.info("加载缓存的远程 schema success", Date.now() - startTime)
      $setFormilySchema(cachedSchema)
    } catch (e) {
      $logger.error("解析缓存的远程 schema 失败", remoteSchemaUrl, e)
    }
  } else {
    // $logger.info("没有缓存的远程 schema", remoteSchemaUrl)
  }

  startTime = Date.now()
  // $logger.info("加载远程 schema start")
  try {
    const schema = await fetch(remoteSchemaUrl).then((res) => res.json())
    // $logger.info("加载远程 schema success", Date.now() - startTime)
    if (!cachedSchema) {
      /**
       * 本地有缓存，就用缓存的数据，新拉取的数据给下一次使用
       * 本地没有缓存，则用最新的拉取的数据来展示
       */
      $setFormilySchema(schema)
    }

    // 缓存
    $chrome.localStorage.setItem(cacheKey, JSON.stringify(schema))
  } catch (e) {
    $logger.error("加载远程 schema 失败", e)
    remoteSchemaSpin.componentProps.tip = "加载远程 schema 失败"
  }
}

$formilyCore.onFormMount(() => {
  handleFormMount()
})
`}}},x={type:"object",properties:{remoteSchemaSpin:{type:"void","x-component":"Spin","x-validator":[],"x-component-props":{size:"small",tip:"加载中",style:{}},name:"remoteSchemaSpin","x-designable-id":"p7b4f72q3t8","x-index":0,properties:{om92ryckno4:{type:"void","x-component":"Div","x-component-props":{style:{padding:"150px 150px 150px 150px"}},"x-designable-id":"om92ryckno4","x-index":0}}}},"x-designable-id":"s9csump7v6w"},$={form:P,schema:x},c=new p("lowCodeApi"),m=async e=>{try{return await fetch(e).then(r=>r.json())}catch{throw d.error("获取默认页面配置失败"),new Error("获取默认页面配置失败")}},s=async(e=i())=>{const t=await u();if(!t)throw d.error("获取扩展配置信息失败"),new Error("获取扩展配置信息失败");return Object.keys(t.defaultSchema).includes(e)?await m(t.defaultSchema[e]):await m(t.defaultSchema.demo)},b=async()=>{try{if(w&&S("remoteSchemaUrl"))return $;const e=await U(),t=e==null?void 0:e.jsonSchema;return t?JSON.parse(t):s()}catch(e){return c.error("loadFormilySchema error",e),s()}},N=async()=>{const e=await b();return y(e)},L=async(e,t)=>{const r=await s(e);return{id:e,name:t,desc:t,jsonSchema:JSON.stringify(r),isBuiltIn:!1}},n=async(e,t,r)=>{let o=e.find(g=>g.id===t);o||(o=await L(t,r),o.isBuiltIn=!0,await l({[`${a.Prefix}${o.id}`]:o}),e.unshift(o),c.info("添加默认的",o.id))},j=async()=>{try{let e=[],t=await h();return(!t||Object.keys(t).length===0)&&(t={},c.info("record 为空")),Object.keys(t).forEach(r=>{r.startsWith(a.Prefix)&&e.push(t[r])}),await n(e,a.ElementsSidebarPane,"元素边栏面板页"),await n(e,a.DevtoolsPanel,"开发者面板页"),await n(e,a.SidePanel,"边栏页"),await n(e,a.Popup,"弹出式窗口"),await n(e,a.NewTab,"新标签页"),await n(e,a.Demo,"各种示例(待完善)"),e.sort((r,o)=>o.updateTime-r.updateTime)}catch(e){throw c.error("requestLowCodePageList error",e),e}},_=async e=>{try{await l({[`${a.Prefix}${e.id}`]:{...e,updateTime:Date.now()}})}catch(t){throw c.error("addOrUpdateLowCodePage error",t),t}},K=async e=>{try{await f(`${a.Prefix}${e}`)}catch(t){throw c.error("removeLowCodePage error",t),t}},i=()=>S("pageId")||"demo",T=(e=i())=>`${a.Prefix}${e}`,U=async(e=i())=>{const t=T(e);let r=await h(t);return r==null?void 0:r[t]};export{_ as a,s as b,K as c,U as g,N as l,j as r};
