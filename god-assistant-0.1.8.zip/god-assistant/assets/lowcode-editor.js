import{l as Dn}from"./logger.js";import{j as t,c as B,r as b,B as H,a as tt,S as En,b as Vn,d as Ge,u as $n,C as Mn,e as On,A as Ln}from"./utils.js";import{u as zn,L as Un,a as V,W as ot,S as Bn,M as be,o as y,D as A,c as R,G as I,b as h,d as wo,e as Wn,f as $,O as Hn,A as Gn,V as Jn,F as Qn,g as nt,h as Co,i as rt,T as k,P as qn,j as at,I as it,k as Fo,l as Kn,m as vo,n as Zn,p as st,q as Yn,r as Xn,s as To,t as Ao,v as _n,w as er,x as ke,y as tr,z as Je,B as or,C as ko,E as x,R as nr,H as rr,N as ar,J as ir,K as sr,Q as lr,U as mo,X as S,Y as pr,Z as me,_ as M,$ as D,a0 as uo,a1 as ho,a2 as cr,a3 as dr,a4 as mr,a5 as ur,a6 as hr,a7 as we,a8 as xr,a9 as Ce,aa as gr,ab as fr,ac as yr,ad as br,ae as Sr,af as Ir,ag as Fe,ah as wr,ai as Cr,aj as Fr,ak as vr}from"./SettingsForm.js";import{T as Tr,C as lt,I as Ye,a as Ar,b as kr,c as Pr,R as Nr,d as jr,P as Rr,U as Dr,Q as Er,F as pt,s as Vr,A as $r,e as Mr,f as Or}from"./index.js";import{t as Lr,a as zr,i as Po,b as Ur,S as No,e as Br,P as ve,c as xo,d as Wr,r as jo,f as Hr,g as Ee,u as ct,h as de,o as Gr,j as Te}from"./index2.js";import{T as Jr,S as Qr,F as Qe,D as qr,P as Kr,a as Zr}from"./Table.js";import{M as qe,T as Ro}from"./preload-helper.js";import{l as Yr}from"./lowCodeApi.js";import"./FormOutlined.js";import"./LowCode2.js";const Xr=()=>{var e;return(e=zn())==null?void 0:e.position},_r=({logo:e,actions:o,...n})=>{const r=V("main-panel"),a=Xr(),p=B("root",a,n.className);return e||o?t.jsxs("div",{...n,className:B(`${r}-container`,p),children:[t.jsxs("div",{className:r+"-header",children:[t.jsx("div",{className:r+"-header-logo",children:e}),t.jsx("div",{className:r+"-header-actions",children:o})]}),t.jsx("div",{className:r,children:n.children})]}):t.jsx("div",{...n,className:B(r,p),children:n.children})},ea=e=>t.jsx(Un,{theme:e.theme,prefixCls:e.prefixCls,position:e.position,children:t.jsx(_r,{...e})}),ta=e=>t.jsx(ot.Item,{...e,style:{display:"flex",justifyContent:"space-between",marginBottom:4,padding:"0 4px",...e.style},children:e.children}),oa=e=>t.jsx(ot.Item,{...e,flexable:!0,children:t.jsx(Bn,{children:e.children})}),na=()=>t.jsx("div",{style:{display:"flex",alignItems:"center",fontSize:14},children:t.jsx("img",{src:"/images/128.png",style:{marginLeft:2,height:50,width:50}})}),ra=e=>t.jsx(be,{...e,value:JSON.stringify(Lr(e.tree),null,2),onChange:o=>{var n;(n=e.onChange)==null||n.call(e,zr(JSON.parse(o)))},language:"json"}),aa=e=>{const o=l=>{if(!l)return"";const d={...l.props};return l.depth!==0&&(d.name=l.props.name||l.id),`${Object.keys(d).map(s=>{if(s==="x-designable-id"||s==="x-designable-source-name"||s==="_isJSONSchemaObject"||s==="version"||s==="type")return"";const i=d[s];return Po(i)&&Ur(i)?"":typeof i=="string"?`${s}="${i}"`:`${s}={${JSON.stringify(i)}}`}).join(" ")}`},n=l=>l?l.children.map(d=>a(d)).join(""):"",r=l=>l.props.type==="string"?"SchemaField.String":l.props.type==="number"?"SchemaField.Number":l.props.type==="boolean"?"SchemaField.Boolean":l.props.type==="date"?"SchemaField.Date":l.props.type==="datetime"?"SchemaField.DateTime":l.props.type==="array"?"SchemaField.Array":l.props.type==="object"?"SchemaField.Object":l.props.type==="void"?"SchemaField.Void":"SchemaField.Markup",a=l=>l?`<${r(l)} ${o(l)} ${l.children.length?`>${n(l)}</${r(l)}>`:"/>"}`:"",p=e.find(l=>l.componentName==="Form"||l.componentName==="Root");return`import React, { useMemo } from 'react'
import { createForm } from '@formily/core'
import { createSchemaField } from '@formily/react'
import {
  Form,
  FormItem,
  DatePicker,
  Checkbox,
  Cascader,
  Editable,
  Input,
  NumberPicker,
  Switch,
  Password,
  PreviewText,
  Radio,
  Reset,
  Select,
  Space,
  Submit,
  TimePicker,
  Transfer,
  TreeSelect,
  Upload,
  FormGrid,
  FormLayout,
  FormTab,
  FormCollapse,
  ArrayTable,
  ArrayCards,
} from '@formily/antd-v5'
import { Card, Slider, Rate } from 'antd'

const Text: React.FC<{
  value?: string
  content?: string
  mode?: 'normal' | 'h1' | 'h2' | 'h3' | 'p'
}> = ({ value, mode, content, ...props }) => {
  const tagName = mode === 'normal' || !mode ? 'div' : mode
  return React.createElement(tagName, props, value || content)
}

const SchemaField = createSchemaField({
  components: {
    Space,
    FormGrid,
    FormLayout,
    FormTab,
    FormCollapse,
    ArrayTable,
    ArrayCards,
    FormItem,
    DatePicker,
    Checkbox,
    Cascader,
    Editable,
    Input,
    Text,
    NumberPicker,
    Switch,
    Password,
    PreviewText,
    Radio,
    Reset,
    Select,
    Submit,
    TimePicker,
    Transfer,
    TreeSelect,
    Upload,
    Card,
    Slider,
    Rate,
  },
})

export default ()=>{
  const form = useMemo(() => createForm(), [])

  return <Form form={form} ${o(p)}>
    <SchemaField>
      ${n(p)}
    </SchemaField>
  </Form>
}
`},ia=e=>t.jsx(be,{...e,options:{readOnly:!0},value:aa(e.tree),language:"typescript"}),Do=y(e=>t.jsx(A,{children:e.children})),dt=e=>o=>t.jsx(A,{children:t.jsx(e,{...o})}),Eo={"zh-CN":{settings:{style:{width:"宽度",height:"高度",display:"展示",background:"背景",boxShadow:"阴影",font:"字体",margin:"外边距",padding:"内边距",borderRadius:"圆角",border:"边框",opacity:"透明度"}}},"en-US":{settings:{style:{width:"Width",height:"Height",display:"Display",background:"Background",boxShadow:"Box Shadow",font:"Font",margin:"Margin",padding:"Padding",borderRadius:"Radius",border:"Border",opacity:"Opacity"}}}},Vo={"zh-CN":{settings:{name:"字段标识",title:"标题",required:"必填",description:"描述",default:"默认值",enum:"可选项","x-display":{title:"展示状态",tooltip:"半隐藏只会隐藏UI，全隐藏会删除数据",dataSource:["显示","半隐藏","全隐藏","继承"]},"x-pattern":{title:"UI形态",dataSource:["可编辑","禁用","只读","阅读","继承"]},"x-validator":"校验规则","x-decorator":"容器组件","x-reactions":"响应器规则","field-group":"字段属性","component-group":"组件属性","decorator-group":"容器属性","component-style-group":"组件样式","decorator-style-group":"容器样式","x-component-props":{size:{title:"尺寸",dataSource:["大","小","默认","继承"]},allowClear:"允许清除内容",autoFocus:"自动获取焦点",showSearch:"支持搜索",notFoundContent:"空状态内容",bordered:"是否有边框",placeholder:"占位提示",style:{width:"宽度",height:"高度",display:"展示",background:"背景",boxShadow:"阴影",font:"字体",margin:"外边距",padding:"内边距",borderRadius:"圆角",border:"边框",opacity:"透明度"}},"x-decorator-props":{addonAfter:"后缀标签",addonBefore:"前缀标签",tooltip:"提示",asterisk:"星号",gridSpan:"网格跨列",labelCol:"标签网格宽度",wrapperCol:"组件网格宽度",colon:"是否有冒号",labelAlign:{title:"标签对齐",dataSource:["左对齐","右对齐","继承"]},wrapperAlign:{title:"组件对齐",dataSource:["左对齐","右对齐","继承"]},labelWrap:"标签换行",wrapperWrap:"组件换行",labelWidth:"标签宽度",wrapperWidth:"组件宽度",fullness:"组件占满",inset:"内联布局",shallow:"是否浅传递",bordered:"是否有边框",size:{title:"尺寸",dataSource:["大","小","默认","继承"]},layout:{title:"布局",dataSource:["垂直","水平","内联","继承"]},feedbackLayout:{title:"反馈布局",dataSource:["宽松","紧凑","弹层","无","继承"]},tooltipLayout:{title:"提示布局",dataSource:["图标","文本","继承"]},style:{width:"宽度",height:"高度",display:"展示",background:"背景",boxShadow:"阴影",font:"字体",margin:"外边距",padding:"内边距",borderRadius:"圆角",border:"边框",opacity:"透明度"}}}},"en-US":{settings:{name:"Name",title:"Title",required:"Required",description:"Description",default:"Default",enum:"Options","x-display":{title:"Display State",tooltip:'When the display value is "None", the data will be "Hidden" and deleted. When the display value is hidden, only the UI will be hidden',dataSource:["Visible","Hidden","None","Inherit"]},"x-pattern":{title:"UI Pattern",dataSource:["Editable","Disabled","ReadOnly","ReadPretty","Inherit"]},"x-validator":"Validator","x-decorator":"Decorator","x-reactions":"Reactions","field-group":"Field Properties","component-group":"Component Properties","decorator-group":"Decorator Properties","component-style-group":"Component Style","decorator-style-group":"Decorator Style","x-component-props":{size:{title:"Size",dataSource:["Large","Small","Default","Inherit"]},allowClear:"Allow Clear",autoFocus:"Auto Focus",showSearch:"Show Search",notFoundContent:"Not Found Content",bordered:"Bordered",placeholder:"Placeholder",style:{width:"Width",height:"Height",display:"Display",background:"Background",boxShadow:"Box Shadow",font:"Font",margin:"Margin",padding:"Padding",borderRadius:"Radius",border:"Border",opacity:"Opacity"}},"x-decorator-props":{addonAfter:"Addon After",addonBefore:"Addon Before",tooltip:"Tooltip",asterisk:"Asterisk",gridSpan:"Grid Span",labelCol:"Label Col",wrapperCol:"Wrapper Col",colon:"Colon",labelAlign:{title:"Label Align",dataSource:["Left","Right","Inherit"]},wrapperAlign:{title:"Wrapper Align",dataSource:["Left","Right","Inherit"]},labelWrap:"Label Wrap",wrapperWrap:"Wrapper Wrap",labelWidth:"Label Width",wrapperWidth:"Wrapper Width",fullness:"Fullness",inset:"Inset",shallow:"Shallow",bordered:"Bordered",size:{title:"Size",dataSource:["Large","Small","Default","Inherit"]},layout:{title:"Layout",dataSource:["Vertical","Horizontal","Inline","Inherit"]},feedbackLayout:{title:"Feedback Layout",dataSource:["Loose","Terse","Popup","None","Inherit"]},tooltipLayout:{title:"Tooltip Layout",dataSource:["Icon","Text","Inherit"]},style:{width:"Width",height:"Height",display:"Display",background:"Background",boxShadow:"Box Shadow",font:"Font",margin:"Margin",padding:"Padding",borderRadius:"Radius",border:"Border",opacity:"Opacity"}}}}},mt={"zh-CN":{title:"输入框",settings:{"x-component-props":{addonAfter:"后缀标签",addonBefore:"前缀标签",maxLength:"最大长度",prefix:"前缀",suffix:"后缀",autoSize:{title:"自适应高度",tooltip:"可设置为 true | false 或对象：{ minRows: 2, maxRows: 6 }"},showCount:"是否展示字数",checkStrength:"检测强度"}}},"en-US":{title:"Input",settings:{"x-component-props":{addonAfter:"Addon After",addonBefore:"Addon Before",maxLength:"Max Length",prefix:"Prefix",suffix:"Suffix",autoSize:"Auto Size",showCount:"Show Count",checkStrength:"Check Strength"}}}},$o={"zh-CN":{title:"选择框",settings:{"x-component-props":{mode:{title:"模式",dataSource:["多选","标签","单选"]},autoClearSearchValue:{title:"选中自动清除",tooltip:"仅在多选或者标签模式下支持"},defaultActiveFirstOption:"默认高亮第一个选项",dropdownMatchSelectWidth:{title:"下拉菜单和选择器同宽",tooltip:"默认将设置 min-width，当值小于选择框宽度时会被忽略。false 时会关闭虚拟滚动"},defaultOpen:"默认展开",filterOption:"选项筛选器",filterSort:"选项排序器",labelInValue:{title:"标签值",tooltip:"是否把每个选项的 label 包装到 value 中，会把 Select 的 value 类型从 string 变为 { value: string, label: ReactNode } 的格式"},listHeight:"弹窗滚动高度",maxTagCount:{title:"最多标签数量",tooltip:"最多显示多少个 tag，响应式模式会对性能产生损耗"},maxTagPlaceholder:{title:"最多标签占位",tooltip:"隐藏 tag 时显示的内容"},maxTagTextLength:"最多标签文本长度",showArrow:"显示箭头",virtual:"开启虚拟滚动"}}},"en-US":{title:"Select",settings:{"x-component-props":{mode:{title:"Mode",dataSource:["Multiple","Tags","Single"]},autoClearSearchValue:{title:"Auto Clear Search Value",tooltip:"Only used to multiple and tags mode"},defaultActiveFirstOption:"Default Active First Option",dropdownMatchSelectWidth:"Dropdown Match Select Width",defaultOpen:"Default Open",filterOption:"Filter Option",filterSort:"Filter Sort",labelInValue:"label InValue",listHeight:"List Height",maxTagCount:"Max Tag Count",maxTagPlaceholder:{title:"Max Tag Placeholder",tooltip:"Content displayed when tag is hidden"},maxTagTextLength:"Max Tag Text Length",showArrow:"Show Arrow",virtual:"Use Virtual Scroll"}}}},Mo={"zh-CN":{title:"多行输入",settings:{"x-component-props":{maxLength:"最大长度",autoSize:{title:"自适应高度",tooltip:"可设置为 true | false 或对象：{ minRows: 2, maxRows: 6 }"},showCount:"是否展示字数"}}},"en-US":{title:"TextArea",settings:{"x-component-props":{maxLength:"Max Length",autoSize:"Auto Size",showCount:"Show Count"}}}},Oo={"zh-CN":{title:"树选择",settings:{"x-component-props":{mode:{title:"模式",dataSource:["多选","标签","单选"]},autoClearSearchValue:{title:"选中自动清除",tooltip:"仅在多选或者标签模式下支持"},defaultActiveFirstOption:"默认高亮第一个选项",defaultOpen:"默认展开",filterOption:"选项筛选器",filterSort:"选项排序器",labelInValue:{title:"标签值",tooltip:"是否把每个选项的 label 包装到 value 中，会把 Select 的 value 类型从 string 变为 { value: string, label: ReactNode } 的格式"},listHeight:"弹窗滚动高度",maxTagCount:{title:"最多标签数量",tooltip:"最多显示多少个 tag，响应式模式会对性能产生损耗"},maxTagPlaceholder:{title:"最多标签占位",tooltip:"隐藏 tag 时显示的内容"},maxTagTextLength:"最多标签文本长度",showArrow:"显示箭头",virtual:"开启虚拟滚动",dropdownMatchSelectWidth:{title:"下拉选择器同宽",tooltip:"默认将设置 min-width，当值小于选择框宽度时会被忽略。false 时会关闭虚拟滚动"},showCheckedStrategy:{title:"复选回显策略",tooltip:"配置 treeCheckable 时，定义选中项回填的方式。TreeSelect.SHOW_ALL: 显示所有选中节点(包括父节点)。TreeSelect.SHOW_PARENT: 只显示父节点(当父节点下所有子节点都选中时)。 默认只显示子节点",dataSource:["显示所有","显示父节点","显示子节点"]},treeCheckable:"开启复选",treeDefaultExpandAll:"默认展开所有",treeDefaultExpandedKeys:{title:"默认展开选项",tooltip:"格式：Array<string | number>"},treeNodeFilterProp:{title:"节点过滤属性",tooltip:"输入项过滤对应的 treeNode 属性"},treeDataSimpleMode:{title:"使用简单数据结构",tooltip:`使用简单格式的 treeData，具体设置参考可设置的类型 (此时 treeData 应变为这样的数据结构: [{id:1, pId:0, value:'1', title:"test1",...},...]， pId 是父节点的 id)`},treeNodeLabelProp:{title:"标签显示名称",tooltip:"默认为title"},filterTreeNode:"节点过滤器"}}},"en-US":{title:"TreeSelect",settings:{"x-component-props":{mode:{title:"Mode",dataSource:["Multiple","Tags","Single"]},autoClearSearchValue:{title:"Auto Clear Search Value",tooltip:"Only used to multiple and tags mode"},defaultActiveFirstOption:"Default Active First Option",defaultOpen:"Default Open",filterOption:"Filter Option",filterSort:"Filter Sort",labelInValue:"Label In Value",listHeight:"List Height",maxTagCount:"Max Tag Count",maxTagPlaceholder:{title:"Max Tag Placeholder",tooltip:"Content displayed when tag is hidden"},maxTagTextLength:"Max Tag Text Length",notFoundContent:"Not Found Content",showArrow:"Show Arrow",virtual:"Use Virtual Scroll",dropdownMatchSelectWidth:{title:"Dropdown Match Select Width",tooltip:"By default, min-width will be set, and it will be ignored when the value is less than the width of the selection box. false will turn off virtual scrolling"},showCheckedStrategy:{title:"Show Checked Strategy",tooltip:"When configuring treeCheckable, define how to backfill the selected item. TreeSelect.SHOW_ALL: Show all selected nodes (including parent nodes). TreeSelect.SHOW_PARENT: Only display the parent node (when all child nodes under the parent node are selected). Only show child nodes by default",dataSource:["Show All","Show Parent Node","Show Child Nodes"]},treeCheckable:"Tree Checkable",treeDefaultExpandAll:"Tree Default Expand All",treeDefaultExpandedKeys:{title:"Tree Default Expanded Keys",tooltip:"Format：Array<string | number>"},treeNodeFilterProp:{title:"Tree Node Filter Properties",tooltip:"The treeNode attribute corresponding to the input item filter"},treeDataSimpleMode:{title:"Tree Data Simple Mode",tooltip:`Use treeData in a simple format. For specific settings, refer to the settable type (the treeData should be a data structure like this: [{id:1, pId:0, value:'1', title:"test1",...} ,...], pId is the id of the parent node)`},treeNodeLabelProp:{title:"Tree Node Label Properties",tooltip:"The default is title"},filterTreeNode:"Filter Tree Node"}}}},Lo={"zh-CN":{title:"联级选择",settings:{"x-component-props":{changeOnSelect:{title:"选择时触发",tooltip:"点选每级菜单选项值都会发生变化"},displayRender:{title:"渲染函数",tooltip:'选择后展示的渲染函数，默认为label => label.join("/")	'},fieldNames:{title:"自定义字段名",tooltip:'默认值：{ label: "label", value: "value", children: "children" }'}}}},"en-US":{title:"Cascader",settings:{"x-component-props":{changeOnSelect:{title:"Change On Select",tooltip:"Click on each level of menu option value will change"},displayRender:{title:"Display Render",tooltip:'The rendering function displayed after selection, the default is label => label.join("/")	'},fieldNames:{title:"Field Names",tooltip:'Defaults：{ label: "label", value: "value", children: "children" }'}}}}},zo={"zh-CN":{title:"单选框组",settings:{"x-component-props":{buttonStyle:{title:"按钮风格",dataSource:["空心","实心"]},optionType:{title:"选项类型",dataSource:["默认","按钮"]}}}},"en-US":{title:"Radio",settings:{"x-component-props":{buttonStyle:{title:"Button style",dataSource:["Hollow","Solid"]},optionType:{title:"Option type",dataSource:["Default","Button"]}}}}},Uo={"zh-CN":{title:"复选框组"},"en-US":{title:"Checkbox"}},Bo={"zh-CN":{title:"滑动条",settings:{"x-component-props":{dots:"刻度固定",range:"双滑块",reverse:"反向坐标系",vertical:"垂直布局",tooltipPlacement:{title:"提示位置",tooltip:"设置 提示 展示位置。参考 Tooltip"},tooltipVisible:{title:"提示显示",tooltip:"开启时，提示 将会始终显示；否则始终不显示，哪怕在拖拽及移入时"},max:"最大值",min:"最小值",step:"步长",marks:"刻度标签"}}},"en-US":{title:"Slider",settings:{"x-component-props":{dots:"Fixed Scale",range:"Double Slider",reverse:"Reverse Coordinate System",vertical:"Vertical",tooltipPlacement:{title:"Tooltip Placement",tooltip:"Set up prompt placement. Reference Tooltip"},tooltipVisible:{title:"Tooltip Visible",tooltip:"When turned on, the prompt will always be displayed; otherwise, it will always not be displayed, even when dragging and moving in"},max:"Max",min:"Min",step:"Step",marks:"Marks"}}}},Wo={"zh-CN":{title:"评分器",settings:{"x-component-props":{allowHalf:"允许半选",tooltips:{title:"提示信息",tooltip:"格式：string[]"},count:"总数"}}},"en-US":{title:"Rate",settings:{"x-component-props":{allowHalf:"Allow Half",tooltips:{title:"Tooltips",tooltip:"Format：string[]"},count:"Count"}}}},Ve={"zh-CN":{title:"日期选择",settings:{"x-component-props":{disabledDate:{title:"不可选日期",tooltip:"格式 (currentDate: dayjs, info: { from?: dayjs }) => boolean"},disabledTime:{title:"不可选时间",tooltip:"格式 (currentDate: dayjs, info: { from?: dayjs }) => boolean"},inputReadOnly:"输入框只读",format:"格式",picker:{title:"选择器类型",dataSource:["时间","日期","月份","年","季度","财年"]},showNow:"显示此刻",showTime:"时间选择",showToday:"显示今天"}}},"en-US":{title:"DatePicker",settings:{"x-component-props":{disabledDate:{title:"Disabled Date",tooltip:"Format (currentDate: dayjs, info: { from?: dayjs }) => boolean"},disabledTime:{title:"Disabled Time",tooltip:"Format (currentDate: dayjs, info: { from?: dayjs }) => boolean"},inputReadOnly:"Input ReadOnly",format:"Format",picker:{title:"Picker Type",dataSource:["Time","Date","Month","Year","Quarter","Decade"]},showNow:"Show Now",showTime:"Show Time",showToday:"Show Today"}}}},Ho=R(Ve,{"zh-CN":{title:"日期范围"},"en-US":{title:"DateRange"}}),ut=R(Ve,{"zh-CN":{title:"时间选择",settings:{"x-component-props":{clearText:"清除提示",disabledHours:"禁止小时",disabledMinutes:"禁止分钟",disabledSeconds:"禁止秒",hideDisabledOptions:"隐藏禁止选项",hourStep:"小时间隔",minuteStep:"分钟间隔",secondStep:"秒间隔",use12Hours:"12小时制",inputReadOnly:"输入框只读",showNow:"显示此刻",format:"格式"}}},"en-US":{title:"Time Picker",settings:{"x-component-props":{clearText:"Clear Text",disabledHours:"Disbaled Hours",disabledMinutes:"Disabled Minutes",disabledSeconds:"Disabled Seconds",hideDisabledOptions:"Hide Disabled Options",hourStep:"Hour Step",minuteStep:"Minute Step",secondStep:"Second Step",use12Hours:"Use 12-hour",inputReadOnly:"Input ReadOnly",showNow:"Show Now",format:"Format"}}}}),Go=R(ut,{"zh-CN":{title:"时间范围"},"en-US":{title:"Time Range"}}),Jo={"zh-CN":{title:"数字输入",settings:{"x-component-props":{formatter:{title:"格式转换器",tooltip:"格式：function(value: number | string): string"},keyboard:"启用快捷键",parser:{title:"格式解析器",tooltip:"指定从 格式转换器 里转换回数字的方式，和 格式转换器 搭配使用,格式：function(string): number"},decimalSeparator:"小数点",precision:"数字精度",max:"最大值",min:"最小值",step:"步长",stringMode:{title:"字符串格式",tooltip:"开启后支持高精度小数。同时 onChange 将返回 string 类型"}}}},"en-US":{title:"NumberInput",settings:{"x-component-props":{formatter:{title:"Format Converter",tooltip:"Format：function(value: number | string): string"},keyboard:"Enable Shortcut Keys",parser:{title:"Format Parser",tooltip:"Specify the method of converting back to numbers from the format converter, and use it with the format converter, the format:function(string): number"},decimalSeparator:"Decimal Separator",precision:"Precision",max:"Max",min:"Min",step:"Step",stringMode:{title:"String Format",tooltip:"Support high-precision decimals after opening. At the same time onChange will return string type"}}}}},Qo=R(mt,{"zh-CN":{title:"密码输入"},"en-US":{title:"Password"}}),qo={"zh-CN":{title:"穿梭框",settings:{"x-component-props":{oneWay:"单向展示",operations:{title:"操作文案集合",tooltip:"格式：string[]"},titles:{title:"标题集合",tooltip:"格式：string[]"},showSearchAll:"支持全选",filterOption:"选项筛选器"}}},"en-US":{title:"Transfer",settings:{"x-component-props":{oneWay:"One Way",operations:{title:"Operations",tooltip:"Format：string[]"},titles:{title:"Titles",tooltip:"Format：string[]"},showSearchAll:"Show Search All",filterOption:"Filter Option"}}}},ht={"zh-CN":{title:"上传",settings:{"x-component-props":{accept:"可接受类型",action:"上传地址",data:"数据/参数",directory:"支持上传目录",headers:"请求头",listType:{title:"列表类型",dataSource:["文本","图片","卡片"]},multiple:"多选模式",name:"字段标识",openFileDialogOnClick:{title:"点击打开文件对话框",tooltip:"点击打开文件对话框"},showUploadList:"是否展示文件列表",withCredentials:"携带Cookie",maxCount:"最大数量",method:"方法",textContent:"上传文案"}}},"en-US":{title:"Upload",settings:{"x-component-props":{accept:"Accept",action:"Upload Address",data:"Data",directory:"Support Upload Directory",headers:"Headers",listType:{title:"List Type",dataSource:["Text","Image","Card"]},multiple:"Multiple",name:"Name",openFileDialogOnClick:"Open File Dialog On Click",showUploadList:"Show Upload List",withCredentials:"withCredentials",maxCount:"Max Count",method:"Method",textContent:"Text Content"}}}},Ko=R(ht,{"zh-CN":{title:"拖拽上传",settings:{"x-component-props":{}}},"en-US":{title:"UploadDragger",settings:{"x-component-props":{}}}}),Zo={"zh-CN":{title:"开关"},"en-US":{title:"Switch"}},Yo={"zh-CN":{title:"对象容器"},"en-US":{title:"Object"}},Xo=R(Eo,{"zh-CN":{title:"表单",settings:{"x-reactions":"响应器规则",labelCol:"标签网格宽度",wrapperCol:"组件网格宽度",colon:"是否有冒号",labelAlign:{title:"标签对齐",dataSource:["左对齐","右对齐","继承"]},wrapperAlign:{title:"组件对齐",dataSource:["左对齐","右对齐","继承"]},labelWrap:"标签换行",wrapperWrap:"组件换行",labelWidth:"标签宽度",wrapperWidth:"组件宽度",fullness:"组件占满",inset:"内联布局",shallow:"是否浅传递",bordered:"是否有边框",size:{title:"尺寸",dataSource:["大","小","默认","继承"]},layout:{title:"布局",dataSource:["垂直","水平","内联","继承"]},feedbackLayout:{title:"反馈布局",dataSource:["宽松","紧凑","弹层","无","继承"]},tooltipLayout:{title:"提示布局",dataSource:["图标","文本","继承"]}}},"en-US":{title:"Form",settings:{"x-reactions":"Reactions",labelCol:"Label Col",wrapperCol:"Wrapper Col",colon:"Colon",labelAlign:{title:"Label Align",dataSource:["Left","Right","Inherit"]},wrapperAlign:{title:"Wrapper Align",dataSource:["Left","Right","Inherit"]},labelWrap:"Label Wrap",wrapperWrap:"Wrapper Wrap",labelWidth:"Label Width",wrapperWidth:"Wrapper Width",fullness:"Fullness",inset:"Inset",shallow:"Shallow",bordered:"Bordered",size:{title:"Size",dataSource:["Large","Small","Default","Inherit"]},layout:{title:"Layout",dataSource:["Vertical","Horizontal","Inline","Inherit"]},feedbackLayout:{title:"Feedback Layout",dataSource:["Loose","Terse","Popup","None","Inherit"]},tooltipLayout:{title:"Tooltip Layout",dataSource:["Icon","Text","Inherit"]}}}}),_o={"zh-CN":{title:"表单布局",settings:{"x-component-props":{labelCol:"标签网格宽度",wrapperCol:"组件网格宽度",colon:"是否有冒号",labelAlign:{title:"标签对齐",dataSource:["左对齐","右对齐","继承"]},wrapperAlign:{title:"组件对齐",dataSource:["左对齐","右对齐","继承"]},labelWrap:"标签换行",wrapperWrap:"组件换行",labelWidth:"标签宽度",wrapperWidth:"组件宽度",fullness:"组件占满",inset:"内联布局",shallow:"是否浅传递",bordered:"是否有边框",size:{title:"尺寸",dataSource:["大","小","默认","继承"]},layout:{title:"布局",dataSource:["水平","垂直","内联","继承"]},feedbackLayout:{title:"反馈布局",dataSource:["宽松","紧凑","弹层","无","继承"]},tooltipLayout:{title:"提示布局",dataSource:["图标","文本","继承"]}}}},"en-US":{title:"Form Layout",settings:{"x-component-props":{labelCol:"Label Col",wrapperCol:"Wrapper Col",colon:"Colon",labelAlign:{title:"Label Align",dataSource:["Left","Right","Inherit"]},wrapperAlign:{title:"Wrapper Align",dataSource:["Left","Right","Inherit"]},labelWrap:"Label Wrap",wrapperWrap:"Wrapper Wrap",labelWidth:"Label Width",wrapperWidth:"Wrapper Width",fullness:"Fullness",inset:"Inset",shallow:"Shallow",bordered:"Bordered",size:{title:"Size",dataSource:["Large","Small","Default","Inherit"]},layout:{title:"Layout",dataSource:["Horizontal","Vertical","Inline","Inherit"]},feedbackLayout:{title:"Feedback Layout",dataSource:["Loose","Terse","Popup","None","Inherit"]},tooltipLayout:{title:"Tooltip Layout",dataSource:["Icon","Text","Inherit"]}}}}},en={"zh-CN":{title:"文本",settings:{"x-component-props":{content:"文本内容",mode:{title:"文本类型",dataSource:["H1","H2","H3","Paragraph","Normal"]}}}},"en-US":{title:"Text",settings:{"x-component-props":{content:"Text Content",mode:{title:"Text Mode",dataSource:["H1","H2","H3","Paragraph","Normal"]}}}}},xt={"zh-CN":{title:"卡片",settings:{"x-component-props":{type:"类型",title:"标题",extra:"右侧扩展",cardTypes:[{label:"内置",value:"inner"},{label:"默认",value:""}]}}},"en-US":{title:"Card",settings:{"x-component-props":{type:"Type",title:"Title",extra:"Extra",cardTypes:[{label:"Inner",value:"inner"},{label:"Default",value:""}]}}}};I.registerDesignerLocales({"zh-CN":{Previews:{droppable:"可以拖入组件",addTabPane:"添加选项卡",addCollapsePanel:"添加手风琴卡片",addTableColumn:"添加表格列",addTableSortHandle:"添加排序",addIndex:"添加索引",addOperation:"添加操作"}}});const tn={"zh-CN":{title:"添加按钮",settings:{"x-component-props":{method:"方法",defaultValue:"默认值"}}}},on={"zh-CN":{title:"删除按钮"},"en-US":{title:"Remove"}},nn={"zh-CN":{title:"上移按钮"},"en-US":{title:"Move Up"}},rn={"zh-CN":{title:"下移按钮"},"en-US":{title:"Move Down"}},an={"zh-CN":{title:"索引标识"},"en-US":{title:"Index"}},sa={"zh-CN":{title:"排序标识"},"en-US":{title:"Sort Handle"}},la=R(xt,{"zh-CN":{title:"自增卡片",addIndex:"添加索引",addOperation:"添加操作"},"en-US":{title:"Array Cards",addIndex:"Add Index",addOperation:"Add Operations"}}),pa={"zh-CN":{title:"自增表格",addSortHandle:"添加排序",addColumn:"添加列",addIndex:"添加索引",addOperation:"添加操作",settings:{"x-component-props":{showHeader:"显示头部",sticky:"吸顶",align:{title:"对齐",dataSource:["左","右","居中"]},colSpan:"跨列",fixed:{title:"固定列",dataSource:["左","右","无"]},width:"宽度",defaultValue:"默认值",tableLayout:{title:"表格布局",dataSource:["自动","固定"]}}}},"en-US":{title:"Array Table",addSortHandle:"Add Sort Handle",addColumn:"Add Column",addIndex:"Add Index",addOperation:"Add Operations",settings:{"x-component-props":{showHeader:"Show Header",sticky:"Sticky",align:{title:"Align",dataSource:["Left","Right","Center"]},colSpan:"Col Span",fixed:{title:"Fixed",dataSource:["Left","Right","None"]},width:"Width",defaultValue:"Default Value",tableLayout:{title:"Table Layout",dataSource:["Auto","Fixed"]}}}}},sn={"zh-CN":{title:"表格列",settings:{"x-component-props":{title:"标题",align:{title:"内容对齐",dataSource:["左","右","居中"]},colSpan:"跨列",width:"宽度",fixed:{title:"固定",dataSource:["左","右","无"]}}}},"en-US":{title:"Column",settings:{"x-component-props":{title:"Title",align:{title:"Align",dataSource:["Left","Right","Center"]},colSpan:"Col Span",width:"Width",fixed:{title:"Fixed",dataSource:["Left","Right","None"]}}}}},ca={"zh-CN":{title:"虚拟容器"},"en-US":{title:"Void"}},ln={"zh-CN":{title:"弹性间距",settings:{"x-component-props":{direction:{title:"方向",dataSource:["垂直","水平"]},split:"分割内容",wrap:"自动换行",align:{title:"对齐",dataSource:["头部","尾部","居中","基准线"]}}}},"en-US":{title:"Space",settings:{"x-component-props":{direction:{title:"Direction",dataSource:["Vertical","Horizontal"]},split:"Split",wrap:"Word Wrap",align:{title:"Align",dataSource:["Start","End","Center","Baseline"]}}}}},pn={"zh-CN":{title:"选项卡",addTabPane:"添加选项卡",settings:{"x-component-props":{animated:"启用动画过渡",centered:"标签居中",tab:"选项名称",type:{title:"类型",dataSource:[{label:"线框",value:"line"},{label:"卡片",value:"card"}]}}}},"en-US":{title:"Tabs",addTabPane:"Add Panel",settings:{"x-component-props":{animated:"Enable Animated",centered:"Label Centered",tab:"Tab Title",type:{title:"Type",dataSource:[{label:"Line",value:"line"},{label:"Card",value:"card"}]}}}}},cn={"zh-CN":{title:"选项卡面板",settings:{"x-component-props":{tab:"面板标题"}}},"en-US":{title:"Tab Panel",settings:{"x-component-props":{tab:"Panel Title"}}}},dn={"zh-CN":{title:"折叠面板",addCollapsePanel:"添加面板",settings:{"x-component-props":{accordion:"手风琴模式",collapsible:{title:"可折叠区域",dataSource:["头部","禁用"]},ghost:"幽灵模式",bordered:"是否有边框"}}},"en-US":{title:"Collapse",addCollapsePanel:"Add Panel",settings:{"x-component-props":{accordion:"Accordion Mode",collapsible:{title:"Collapsible",dataSource:["Header","Disable"]},ghost:"Ghost Mode",bordered:"Bordered"}}}},mn={"zh-CN":{title:"面板",settings:{"x-component-props":{collapsible:{title:"是否可折叠",dataSource:["头部","禁用"]},header:"标题",extra:"扩展内容"}}},"en-US":{title:"Panel",settings:{"x-component-props":{collapsible:{title:"Collapsible",dataSource:["Header","Disable"]},header:"Header Title",extra:"Extra Content"}}}},un={"zh-CN":{title:"网格布局",addGridColumn:"添加网格列",settings:{"x-component-props":{minWidth:"最小宽度",minColumns:"最小列数",maxWidth:"最大宽度",maxColumns:"最大列数",breakpoints:"响应式断点",columnGap:"列间距",rowGap:"行间距",colWrap:"自动换行",strictAutoFit:"自动占满"}}},"en-US":{title:"Grid",addGridColumn:"Add Grid Column",settings:{"x-component-props":{minWidth:"Min Width",minColumns:"Min Columns",maxWidth:"Max Width",maxColumns:"Max Columns",breakpoints:"Breakpoints",columnGap:"Column Gap",rowGap:"Row Gap",colWrap:"Col Wrap",strictAutoFit:"Auto Fit"}}}},hn={"zh-CN":{title:"网格列",settings:{"x-component-props":{gridSpan:"跨列栏数"}}},"en-US":{title:"Grid Column",settings:{"x-component-props":{gridSpan:"Grid Span"}}}},da={"zh-CN":{title:"图片",settings:{"x-component-props":{src:"图片地址",alt:"替代文本",objectFit:{title:"摆放方式",dataSource:["铺满 Cover","适合 Contain","拉伸 Fill"]}}}},"en-US":{title:"Image",settings:{"x-component-props":{src:"src",alt:"alt",objectFit:"object-fit"}}}},ma={"zh-CN":{title:"Div",settings:{"x-component-props":{children:"children"}}},"en-US":{title:"Div",settings:{"x-component-props":{children:"children"}}}},ua={"zh-CN":{title:"二维码",settings:{"x-component-props":{content:"二维码内容",type:"渲染类型",icon:"二维码中图片的地址（目前只支持图片地址）",size:"二维码大小",iconSize:"二维码中图片的大小",color:"二维码颜色",bgColor:"二维码背景颜色",bordered:"是否有边框",errorLevel:"二维码纠错等级"}}},"en-US":{title:"QRCode",settings:{"x-component-props":{content:"content",type:"type",icon:"icon",size:"size",iconSize:"icon size",color:"color",bgColor:"bg color",bordered:"bordered",errorLevel:"error level"}}}},ha={"zh-CN":{title:"按钮",settings:{"x-component-props":{children:"按钮文字",href:"点击跳转的地址，指定此属性 button 的行为和 a 链接一致",type:"设置按钮类型",danger:"设置危险按钮",shape:"设置按钮形状",size:"设置按钮大小",target:"相当于 a 链接的 target 属性，href 存在时生效",icon:"设置按钮的图标组件",iconPosition:"设置按钮图标组件的位置",block:"将按钮宽度调整为其父宽度的选项",autoInsertSpace:"提供两个汉字之间的空格",ghost:"幽灵属性，使按钮背景透明",loading:"设置按钮载入状态",htmlType:"设置 button 原生的 type 值"}}},"en-US":{title:"Button",settings:{"x-component-props":{children:"Button text",href:"Click the address to jump, specify the behavior of the button and the a link is consistent",type:"Set the type of the button",danger:"Set the danger button",shape:"Set the shape of the button",size:"Set the size of the button",block:"Option to adjust the width of the button to that of its parent",autoInsertSpace:"Provide space between two Chinese characters",ghost:"Ghost attribute, making the button background transparent",loading:"Set the loading status of the button",icon:"Set the icon component of the button",iconPosition:"Set the position of the icon component of the button",htmlType:"Set the native type value of the button",target:"Equivalent to the target attribute of a link, effective when href exists"}}}},he={"zh-CN":{title:"悬浮按钮",settings:{"x-component-props":{icon:"设置按钮的图标组件",description:"文字及其它内容",tooltip:"气泡卡片的内容",type:"设置按钮类型",shape:"设置按钮形状",href:"点击跳转的地址，指定此属性 button 的行为和 a 链接一致",target:"相当于 a 链接的 target 属性，href 存在时生效",insetInlineEnd:"到右侧的距离",insetBlockEnd:"到底部的距离",badge:"设置徽标"}}},"en-US":{title:"Float Button",settings:{"x-component-props":{icon:"Set the icon component of the button",description:"Text and other content",tooltip:"Tooltip content",type:"Set the type of the button",shape:"Set the shape of the button",href:"Click the address to jump, specify the behavior of the button and the a link is consistent",target:"Equivalent to the target attribute of a link, effective when href exists",insetInlineEnd:"Right distance",insetBlockEnd:"Bottom distance",badge:"Set the badge"}}}},xa={"zh-CN":{title:"悬浮按钮组",settings:{"x-component-props":{...he["zh-CN"].settings["x-component-props"],shape:"设置包含的 FloatButton 按钮形状",trigger:"触发方式（有触发方式为菜单模式）"}}},"en-US":{title:"Float Button Group",settings:{"x-component-props":{...he["en-US"].settings["x-component-props"],shape:"Set the shape of the contained FloatButton button",trigger:"Trigger mode (with trigger mode is menu mode)"}}}},ga={"zh-CN":{title:"回到顶部",settings:{"x-component-props":{...he["zh-CN"].settings["x-component-props"],duration:"回到顶部所需时间(ms)",visibilityHeight:"滚动高度达到此参数值才出现 BackTop"}}},"en-US":{title:"Back to Top",settings:{"x-component-props":{...he["en-US"].settings["x-component-props"],duration:"Time required to go back to the top (ms)",visibilityHeight:"Scroll height reaches this parameter value to appear BackTop"}}}},fa={"zh-CN":{title:"分割线",settings:{"x-component-props":{children:"嵌套的标题",variant:"分割线是虚线、点线还是实线",orientation:"分割线标题的位置",orientationMargin:"标题和最近 left/right 边框之间的距离，去除了分割线，同时 orientation 必须为 left 或 right。如果传入 string 类型的数字且不带单位，默认单位是 px",plain:"文字是否显示为普通正文样式",type:"水平还是垂直类型"}}},"en-US":{title:"Divider",settings:{"x-component-props":{children:"Nested title",variant:"Line style",orientation:"Title position",orientationMargin:"Margin between the title and the closest left/right border, without the divider, and orientation must be left or right. If a string type number is passed without a unit, the default unit is px",plain:"Whether to display the text as plain body style",type:"Horizontal or vertical type"}}}},ya={"zh-CN":{title:"循环布局",settings:{"x-component-props":{}}},"en-US":{title:"IteratorLayout",settings:{"x-component-props":{}}}},ba={"zh-CN":{title:"动态 schema 区块",settings:{"x-component-props":{}}},"en-US":{title:"DynamicSchemaBlock",settings:{"x-component-props":{}}}},Sa={"zh-CN":{title:"抽屉",settings:{"x-component-props":{autoFocus:"抽屉展开后是否将焦点切换至其 DOM 节点",afterOpenChange:"切换抽屉时动画结束后的回调",classNames:"语义化结构 className",closeIcon:"自定义关闭图标",destroyOnClose:"关闭时销毁 Drawer 里的子元素",extra:"抽屉右上角的操作区域",footer:"抽屉的页脚",forceRender:"预渲染 Drawer 内元素",getContainer:"指定 Drawer 挂载的节点，并在容器内展现，false 为挂载在当前位置",height:"高度，在 placement 为 top 或 bottom 时使用",keyboard:"是否支持键盘 esc 关闭",mask:"是否展示遮罩",maskClosable:"点击蒙层是否允许关闭",placement:"抽屉的方向",push:"用于设置多层 Drawer 的推动行为",rootStyle:"可用于设置 Drawer 最外层容器的样式，和 style 的区别是作用节点包括 mask",styles:"语义化结构 style",size:"预设抽屉宽度（或高度），default 378px 和 large 736px",title:"标题",loading:"显示骨架屏",open:"Drawer 是否可见",width:"宽度",zIndex:"设置 Drawer 的 z-index",onClose:"点击遮罩层或左上角叉或取消按钮的回调",drawerRender:"自定义渲染抽屉"}}},"en-US":{title:"Drawer",settings:{"x-component-props":{autoFocus:"Whether Drawer should get focused after open",afterOpenChange:"Callback after the animation ends when switching drawers",classNames:"Semantic structure className",closeIcon:"Custom close icon",destroyOnClose:"Whether to unmount child components on closing drawer or not",extra:"Extra actions area at corner",footer:"The footer for Drawer",forceRender:"Pre-render Drawer component forcibly",getContainer:"mounted node and display window for Drawer",height:"Placement is top or bottom, height of the Drawer dialog",keyboard:"Whether support press esc to close",mask:"Whether to show mask or not",maskClosable:"Clicking on the mask (area outside the Drawer) to close the Drawer or not",placement:"The placement of the Drawer",push:"Nested drawers push behavior",rootStyle:"Style of wrapper element which contains mask compare to style",styles:"Semantic structure style",size:"preset size of drawer, default 378px and large 736px",title:"The title for Drawer",loading:"Show the Skeleton",open:"Whether the Drawer dialog is visible or not",width:"Width of the Drawer dialog",zIndex:"The z-index of the Drawer",onClose:"Specify a callback that will be called when a user clicks mask, close button or Cancel button",drawerRender:"Custom drawer content render"}}}},$e={"zh-CN":{settings:{"x-component-props":{arrow:"修改箭头的显示状态以及修改箭头是否指向目标元素中心",autoAdjustOverflow:"气泡被遮挡时自动调整位置",color:"背景颜色",defaultOpen:"默认是否显隐",destroyTooltipOnHide:"关闭后是否销毁 Tooltip",fresh:"默认情况下，Tooltip 在关闭时会缓存内容。设置该属性后会始终保持更新",getPopupContainer:"浮层渲染父节点，默认渲染到 body 上",mouseEnterDelay:"鼠标移入后延时多少才显示 Tooltip，单位：秒",mouseLeaveDelay:"鼠标移出后延时多少才隐藏 Tooltip，单位：秒",overlayClassName:"卡片类名",overlayStyle:"卡片样式",overlayInnerStyle:"卡片内容区域的样式对象",placement:"气泡框位置",trigger:"触发行为，可使用数组设置多个触发行为",open:"用于手动控制浮层显隐",zIndex:"设置 Tooltip 的 z-index",onOpenChange:"显示隐藏的回调"}}},"en-US":{settings:{"x-component-props":{arrow:"Change arrow's visible state and change whether the arrow is pointed at the center of target",autoAdjustOverflow:"Whether to adjust popup placement automatically when popup is off screen",color:"The background color",defaultOpen:"Whether the floating tooltip card is open by default",destroyTooltipOnHide:"Whether destroy tooltip when hidden",fresh:"Tooltip will cache content when it is closed by default. Setting this property will always keep updating",getPopupContainer:"The DOM container of the tip, the default behavior is to create a div element in body",mouseEnterDelay:"Delay in seconds, before tooltip is shown on mouse enter",mouseLeaveDelay:"Delay in seconds, before tooltip is hidden on mouse leave",overlayClassName:"Class name of the tooltip card",overlayStyle:"Style of the tooltip card",overlayInnerStyle:"Style of the tooltip inner content",placement:"The position of the tooltip relative to the target",trigger:"Tooltip trigger mode. Could be multiple by passing an array",open:"Whether the floating tooltip card is open or not",zIndex:"Config z-index of Tooltip",onOpenChange:"Callback executed when visibility of the tooltip card is changed"}}}},Ia=R($e,{"zh-CN":{title:"文字提示",settings:{"x-component-props":{title:"提示文字"}}},"en-US":{title:"Tooltip",settings:{"x-component-props":{title:"The text shown in the tooltip"}}}}),wa={"zh-CN":{title:"对话框",settings:{"x-component-props":{afterClose:"Modal 完全关闭后的回调",classNames:"配置弹窗内置模块的 className",styles:"配置弹窗内置模块的 style",cancelButtonProps:"cancel 按钮 props",cancelText:"取消按钮文字",centered:"垂直居中展示 Modal",closable:"是否显示右上角的关闭按钮",closeIcon:"自定义关闭图标",confirmLoading:"确定按钮 loading",destroyOnClose:"关闭时销毁 Modal 里的子元素",focusTriggerAfterClose:"对话框关闭后是否需要聚焦触发元素",footer:"底部内容，当不需要默认底部按钮时，可以设为 footer={null}",forceRender:"强制渲染 Modal",getContainer:"指定 Modal 挂载的节点，但依旧为全屏展示，false 为挂载在当前位置",keyboard:"是否支持键盘 esc 关闭",mask:"是否展示遮罩",maskClosable:"点击蒙层是否允许关闭",modalRender:"自定义渲染对话框",okButtonProps:"ok 按钮 props",okText:"确认按钮文字",okType:"确认按钮类型",loading:"限时骨架屏",title:"标题",open:"对话框是否可见",width:"宽度",wrapClassName:"对话框外层容器的类名",zIndex:"设置 Modal 的 z-index",onCancel:"点击遮罩层或右上角叉或取消按钮的回调",onOk:"点击确定回调",afterOpenChange:"打开和关闭 Modal 时动画结束后的回调"}}},"en-US":{title:"Modal",settings:{"x-component-props":{afterClose:"Specify a function that will be called when modal is closed completely",classNames:"Config Modal build-in module's className",styles:"Config Modal build-in module's style",cancelButtonProps:"The cancel button props",cancelText:"Text of the Cancel button",centered:"Centered Modal",closable:"Whether a close (x) button is visible on top right or not",closeIcon:"Custom close icon",confirmLoading:"Whether to apply loading visual effect for OK button or not",destroyOnClose:"Whether to unmount child components on onClose",focusTriggerAfterClose:"Whether need to focus trigger element after dialog is closed",footer:"Footer content, set as footer={null} when you don't need default buttons",forceRender:"Force render Modal",getContainer:"The mounted node for Modal but still display at fullscreen",keyboard:"Whether support press esc to close",mask:"Whether show mask or not",maskClosable:"Whether to close the modal dialog when the mask (area outside the modal) is clicked",modalRender:"Custom modal content render",okButtonProps:"The ok button props",okText:"Text of the OK button",okType:"Button type of the OK button",loading:"Show the skeleton",title:"The modal dialog's title",open:"Whether the modal dialog is visible or not",width:"Width of the modal dialog",wrapClassName:"The class name of the container of the modal dialog",zIndex:"The z-index of the Modal",onCancel:"Specify a function that will be called when a user clicks mask, close button on top right or Cancel button",onOk:"Specify a function that will be called when a user clicks the OK button",afterOpenChange:"Callback when the animation ends when Modal is turned on and off"}}}},Ca=R($e,{"zh-CN":{title:"气泡确认框",settings:{"x-component-props":{icon:"自定义弹出气泡 Icon 图标",title:"确认框标题",description:"确认内容的详细描述",okButtonProps:"确认按钮属性",okText:"确认按钮文字",okType:"确认按钮类型",cancelButtonProps:"取消按钮属性",cancelText:"取消按钮文字",showCancel:"是否显示取消按钮",disabled:"阻止点击 Popconfirm 子元素时弹出确认框",onCancel:"点击取消的回调",onConfirm:"点击确认的回调",onPopupClick:"弹出气泡点击事件"}}},"en-US":{title:"Popconfirm",settings:{"x-component-props":{icon:"Customize icon of confirmation",title:"The title of the confirmation box",description:"The description of the confirmation box title",okButtonProps:"The ok button props",okText:"The text of the Confirm button",okType:"Button type of the Confirm button",cancelButtonProps:"The cancel button props",cancelText:"The ok button props",showCancel:"Show cancel button",disabled:"Whether show popconfirm when click its childrenNode",onCancel:"A callback of cancel",onConfirm:"A callback of confirmation",onPopupClick:"A callback of popup click"}}}}),Fa=R($e,{"zh-CN":{title:"气泡卡片",settings:{"x-component-props":{title:"卡片标题",content:"卡片内容"}}},"en-US":{title:"Popover",settings:{"x-component-props":{title:"Title of the card",content:"Content of the card"}}}}),va={"zh-CN":{title:"加载中",settings:{"x-component-props":{delay:"延迟显示加载效果的时间（防止闪烁）",fullscreen:"显示带有 Spin 组件的背景",indicator:"加载指示符",percent:'展示进度，当设置 percent="auto" 时会预估一个永远不会停止的进度',size:"组件大小",spinning:"是否为加载中状态",tip:"当作为包裹元素时，可以自定义描述文案",wrapperClassName:"包装器的类属性"}}},"en-US":{title:"Spin",settings:{"x-component-props":{delay:"Specifies a delay in milliseconds for loading state (prevent flush)",fullscreen:"Display a backdrop with the Spin component",indicator:"React node of the spinning indicator",percent:"The progress percentage, when set to auto, it will be an indeterminate progress",size:"The size of Spin",spinning:"Whether Spin is visible",tip:"Customize description content when Spin has children",wrapperClassName:"The className of wrapper when Spin has children"}}}},Ta={"zh-CN":{title:"标签",settings:{"x-component-props":{children:"标签内容",color:"标签颜色",icon:"设置标签图标",closeIcon:"关闭按钮图标",bordered:"是否有边框",onClose:"关闭时的回调"}}},"en-US":{title:"Tag",settings:{"x-component-props":{children:"Tag content",color:"Color of the Tag",icon:"Set the icon of tag",closeIcon:"Custom close icon",bordered:"Whether has border style",onClose:"Callback executed when tag is closed"}}}},Aa={"zh-CN":{title:"可选择标签",settings:{"x-component-props":{children:"标签内容",checked:"设置标签的选中状态",onChange:"点击标签时触发的回调"}}},"en-US":{title:"CheckableTag",settings:{"x-component-props":{children:"Tag content",checked:"Checked status of Tag",onCheckedChange:"Callback executed when Tag is checked/unchecked"}}}},ka={"zh-CN":{title:"iframe",settings:{"x-component-props":{}}},"en-US":{title:"iframe",settings:{"x-component-props":{}}}},T=Object.freeze(Object.defineProperty({__proto__:null,ArrayAddition:tn,ArrayCards:la,ArrayIndex:an,ArrayMoveDown:rn,ArrayMoveUp:nn,ArrayRemove:on,ArraySortHandle:sa,ArrayTable:pa,ArrayTableColumn:sn,Button:ha,Card:xt,Cascader:Lo,CheckableTag:Aa,CheckboxGroup:Uo,CommonTooltipAPI:$e,Component:Eo,DatePicker:Ve,DateRangePicker:Ho,Div:ma,Divider:fa,Drawer:Sa,DynamicSchemaBlock:ba,Field:Vo,FloatButton:he,FloatButtonBackTop:ga,FloatButtonGroup:xa,Form:Xo,FormCollapse:dn,FormCollapsePanel:mn,FormGrid:un,FormGridColumn:hn,FormLayout:_o,FormTab:pn,FormTabPane:cn,Iframe:ka,Img:da,Input:mt,IteratorLayout:ya,Modal:wa,NumberPicker:Jo,ObjectLocale:Yo,Password:Qo,Popconfirm:Ca,Popover:Fa,QRCode:ua,RadioGroup:zo,Rate:Wo,Select:$o,Slider:Bo,Space:ln,Spin:va,Switch:Zo,Tag:Ta,Text:en,TextArea:Mo,TimePicker:ut,TimeRangePicker:Go,Tooltip:Ia,Transfer:qo,TreeSelect:Oo,Upload:ht,UploadDragger:Ko,Void:ca},Symbol.toStringTag,{value:"Module"}));No.silent(!0);const Pa={title:"title",description:"description",default:"value",enum:"dataSource",readOnly:"readOnly",writeOnly:"editable",required:"required","x-content":"content","x-value":"value","x-editable":"editable","x-disabled":"disabled","x-read-pretty":"readPretty","x-read-only":"readOnly","x-visible":"visible","x-hidden":"hidden","x-display":"display","x-pattern":"pattern"},Na={title:!0,description:!0,default:!0,"x-content":!0,"x-value":!0},Xe=e=>Wr(e)&&/^\{\{.*\}\}$/.test(e),Ae=e=>{if(typeof e=="object"){const o=Hr(e);return jo(e,(r,a,p)=>{if(Xe(a))return r;{const l=Ae(a);return l==null?r:o?r.concat([l]):(r[p]=l,r)}},o?[]:{})}if(!Xe(e))return e},ja=(e,o,n,r)=>{const a={};Br(Pa,(i,c)=>{const m=e[c];if(Xe(m)){if(!Na[c])return;if(m){a[i]=m;return}}else m&&(a[i]=Ae(m))}),o.FormItem||(o.FormItem=nt);const p=e["x-decorator"]&&ve.getIn(o,e["x-decorator"]),l=e["x-component"]&&ve.getIn(o,e["x-component"]),d=Ae(e["x-decorator-props"]||{}),s=Ae(e["x-component-props"]||{});return p&&(a.decorator=[p,xo(d)]),l&&(a.component=[l,xo(s)]),p?ve.setIn(a.decorator[1],n,r):l&&ve.setIn(a.component[1],n,r),a.title=a.title&&t.jsx("span",{"data-content-editable":"title",children:a.title}),a.description=a.description&&t.jsx("span",{"data-content-editable":"description",children:a.description}),a},xn=y(e=>{const o=wo(),n=Wn(),r=$();if(!r)return null;const a=ja(e,n,o.props.nodeIdAttrName,r.id);if(e.type==="object"){const p=t.jsx(Hn,{...a,name:r.id,children:e.children});return e["x-component"]?p:t.jsx(Do,{children:p})}else{if(e.type==="array")return t.jsx(Gn,{...a,name:r.id});if(r.props.type==="void")return t.jsx(Jn,{...a,name:r.id,children:e.children})}return t.jsx(Qn,{...a,name:r.id})});xn.Behavior=h({name:"Field",selector:"Field",designerLocales:Vo});const go=[{label:"URL地址",value:"url"},{label:"邮箱格式",value:"email"},{label:"数字格式",value:"number"},{label:"整数格式",value:"integer"},{label:"身份证格式",value:"idcard"},{label:"手机号格式",value:"phone"},{label:"货币格式",value:"money"},{label:"中文格式",value:"zh"},{label:"日期格式",value:"date"},{label:"邮编格式",value:"zip"}],Ra={"zh-CN":{settings:{"x-validator":{title:"校验规则",addValidatorRules:"添加校验规则",drawer:"配置规则",triggerType:{title:"触发类型",placeholder:"请选择",dataSource:["输入时","聚焦时","失焦时"]},format:{title:"格式校验",placeholder:"请选择",dataSource:go},validator:{title:"自定义校验器",tooltip:'格式: function (value){ return "Error Message"}'},pattern:"正则表达式",len:"长度限制",max:"长度/数值小于",min:"长度/数值大于",exclusiveMaximum:"长度/数值小于等于",exclusiveMinimum:"长度/数值大于等于",whitespace:"不允许空白符",required:"是否必填",message:{title:"错误消息",tooltip:"错误消息只对当前规则集的一个内置规则生效，如果需要对不同内置规则定制错误消息，请拆分成多条规则"}}},SettingComponents:{DataSourceSetter:{nodeProperty:"节点属性",pleaseSelectNode:"请先选择左侧树节点",addKeyValuePair:"添加键值对",configureDataSource:"配置可选项",dataSource:"可选项",defaultTitle:"默认标题",dataSourceTree:"可选项节点树",addNode:"新增节点",label:"键名",value:"键值",item:"选项"},ReactionsSetter:{configureReactions:"配置响应器",relationsFields:"依赖字段",variableName:"变量名",variableNameValidateMessage:"不符合变量命名规则",pleaseInput:"请输入",sourceField:"来源字段",sourceProperty:"字段属性",variableType:"变量类型",operations:"操作",addRelationField:"添加依赖字段",propertyReactions:"属性响应(仅支持JS表达式)",actionReactions:"动作响应(高级，可选，支持JS语句)",visible:"显示/隐藏",hidden:"UI隐藏",display:"展示状态",pattern:"UI形态",title:"标题",description:"描述",value:"字段值",initialValue:"默认值",dataSource:"可选项",required:"是否必填",component:"组件",componentProps:"组件属性",decorator:"容器",decoratorProps:"容器属性",pleaseSelect:"请选择",expressionValueTypeIs:"表达式值类型为"},ValidatorSetter:{pleaseSelect:"请选择",formats:go}}}},fo=[{label:"URL",value:"url"},{label:"Email",value:"email"},{label:"Number",value:"number"},{label:"Integer",value:"integer"},{label:"ID",value:"idcard"},{label:"Phone Number",value:"phone"},{label:"Currency",value:"money"},{label:"Chinese",value:"zh"},{label:"Date",value:"date"},{label:"Zip",value:"zip"}],Da={"en-US":{settings:{"x-validator":{title:"Validator",addValidatorRules:"Add Validator Rules",drawer:"Edit Rules",triggerType:{title:"Trigger Type",placeholder:"Please Select",dataSource:["onInput","onFocus","onBlur"]},format:{title:"Format",placeholder:"Please Select",dataSource:fo},validator:{title:"Custom Validator",tooltip:'Format: function (value){ return "Error Message"}'},pattern:"RegExp",len:"Length Limit",max:"Length/Value Lt",min:"Length/Value Gt",exclusiveMaximum:"Length/Value Lte",exclusiveMinimum:"Length/Value Gte",whitespace:"No Whitespace",required:"Required",message:{title:"Error Message",tooltip:"The error message is only effective for one built-in rule of the current rule set. If you need to customize the error message for different built-in rules, please split into multiple rules"}}},SettingComponents:{DataSourceSetter:{nodeProperty:"Node Property",pleaseSelectNode:"please select node from the tree on the left",addKeyValuePair:"Add Key Value Pair",configureDataSource:"Configure",dataSource:"Options",defaultTitle:"Default Title",dataSourceTree:"Options Tree",addNode:"Add Node",label:"label",value:"value",item:"Item"},ReactionsSetter:{configureReactions:"Configure",relationsFields:"Associated Fields",variableName:"Variable Name",variableNameValidateMessage:"This is not a standard variable name",pleaseInput:"Please Input",sourceField:"Source Field",sourceProperty:"Field Property",variableType:"Variable Type",operations:"Operations",addRelationField:"Add Associated Field",propertyReactions:"Property Reactions(Only Support Javascript Expression)",actionReactions:"Action Reactions(Optional, Support Javascript Statement)",visible:"Show/None",hidden:"Show/UI Hidden",display:"Display",pattern:"Pattern",title:"Title",description:"Description",value:"Value",initialValue:"InitialValue",dataSource:"Options",required:"Required",component:"Component",componentProps:"Component Props",decorator:"Decorator",decoratorProps:"Decorator Props",pleaseSelect:"Please Select",expressionValueTypeIs:"Expression value type is"},ValidatorSetter:{pleaseSelect:"Please Select",formats:fo}}}};I.registerDesignerLocales(Ra,Da);const _e=y(({extra:e,title:o})=>{const n=V("data-source-setter");return t.jsxs("div",{className:`${n+"-layout-item-header"}`,children:[t.jsx("div",{className:`${n+"-layout-item-title"}`,children:o}),e]})}),E=(e,o)=>{var n,r;for(let a=0;a<e.length;a++)o(e[a],a,e),(n=e[a])!=null&&n.children&&E(((r=e[a])==null?void 0:r.children)||[],o)},Ea=e=>{const o=Ee(e);return E(o,(n,r,a)=>{const p={key:"",duplicateKey:"",map:[],children:[]};for(const[d,s]of Object.entries(a[r]||{}))d!=="children"&&p.map.push({label:d,value:s});const l=ct();p.key=l,p.duplicateKey=l,p.children=a[r].children||[],a[r]=p}),o},Va=e=>{const o=Ee(e);return E(o,(n,r,a)=>{var l;const p={children:[]};de(a[r].map).forEach(d=>{d.label&&(p[d.label]=d.value)}),p.children=((l=a[r])==null?void 0:l.children)||[],a[r]=p}),o},J=Co({components:{FormItem:nt,Input:it,ArrayItems:Fo,ValueInput:Kn}}),$a=y(e=>{const{allowExtendOption:o,effects:n}=e,r=V("data-source-setter"),a=b.useMemo(()=>{let p;return E(e.treeDataSource.dataSource,l=>{l.key===e.treeDataSource.selectedKey&&(p=l)}),rt({values:p,effects:n})},[e.treeDataSource.selectedKey,e.treeDataSource.dataSource.length]);return e.treeDataSource.selectedKey?t.jsxs(b.Fragment,{children:[t.jsx(_e,{title:t.jsx(k,{token:"SettingComponents.DataSourceSetter.nodeProperty"}),extra:o?t.jsx(H,{type:"text",onClick:()=>{a.setFieldState("map",p=>{p.value.push({})})},icon:t.jsx(qn,{}),children:t.jsx(k,{token:"SettingComponents.DataSourceSetter.addKeyValuePair"})}):null}),t.jsx("div",{className:`${r+"-layout-item-content"}`,children:t.jsx(at,{form:a,labelWidth:60,wrapperWidth:160,children:t.jsx(J,{children:t.jsx(J.Array,{name:"map","x-component":"ArrayItems",children:t.jsxs(J.Object,{"x-decorator":"ArrayItems.Item","x-decorator-props":{type:"divide"},children:[t.jsx(J.String,{title:t.jsx(k,{token:"SettingComponents.DataSourceSetter.label"}),"x-decorator":"FormItem","x-disabled":!o,name:"label","x-component":"Input"}),t.jsx(J.String,{title:t.jsx(k,{token:"SettingComponents.DataSourceSetter.value"}),"x-decorator":"FormItem",name:"value","x-component":"ValueInput"}),t.jsx(J.Void,{"x-component":"ArrayItems.Remove","x-visible":o,"x-component-props":{style:{margin:5,display:"flex",justifyContent:"center",alignItems:"center"}}})]})})})})})]}):t.jsxs(b.Fragment,{children:[t.jsx(_e,{title:t.jsx(k,{token:"SettingComponents.DataSourceSetter.nodeProperty"}),extra:null}),t.jsx("div",{className:`${r+"-layout-item-content"}`,children:t.jsx(k,{token:"SettingComponents.DataSourceSetter.pleaseSelectNode"})})]})}),Ma=y(e=>{const o=V("data-source-setter-node-title"),n=a=>{const p=["label","title","header"];let l;return p.some(d=>{var i;const s=(i=de(a).find(c=>c.label===d))==null?void 0:i.value;return s!==void 0?(l=s,!0):!1}),l===void 0&&de(a||[]).some(d=>d.value&&typeof d.value=="string"?(l=d.value,!0):!1),l},r=a=>{const p=n(a);return p===void 0?t.jsx(k,{token:"SettingComponents.DataSourceSetter.defaultTitle"}):p+""};return t.jsxs("div",{className:o,children:[t.jsx("span",{style:{marginRight:"5px"},children:r((e==null?void 0:e.map)||[])}),t.jsx(vo,{className:o+"-icon",infer:"Remove",onClick:()=>{var p;const a=Ee((p=e==null?void 0:e.treeDataSource)==null?void 0:p.dataSource);E(a||[],(l,d,s)=>{s[d].key===e.duplicateKey&&de(s).splice(d,1)}),e.treeDataSource.dataSource=a}})]})}),Oa=({dropPosition:e})=>e!==0,La=y(e=>{const o=V("data-source-setter"),n=r=>{var c,m;const a=(c=r.node)==null?void 0:c.key,p=(m=r.dragNode)==null?void 0:m.key,l=r.node.pos.split("-"),d=r.dropPosition-Number(l[l.length-1]),s=[...e.treeDataSource.dataSource];let i={key:""};if(E(s,(u,g,C)=>{C[g].key===p&&(C.splice(g,1),i=u)}),!r.dropToGap)E(s,u=>{u.key===a&&(u.children=u.children||[],u.children.unshift(i))});else if((r.node.children||[]).length>0&&r.node.expanded&&d===1)E(s,u=>{u.key===a&&(u.children=u.children||[],u.children.unshift(i))});else{let u=[],g=0;E(s,(C,Ie,He)=>{C.key===a&&(u=He,g=Ie)}),d===-1?u.splice(g,0,i):u.splice(g+1,0,i)}e.treeDataSource.dataSource=s};return t.jsxs(b.Fragment,{children:[t.jsx(_e,{title:t.jsx(k,{token:"SettingComponents.DataSourceSetter.dataSourceTree"}),extra:t.jsx(H,{type:"text",onClick:()=>{var l;const r=ct(),a=e.treeDataSource.dataSource,p=((l=e.defaultOptionValue)==null?void 0:l.map(d=>({...d})))||[{label:"label",value:`${I.getDesignerMessage("SettingComponents.DataSourceSetter.item")} ${a.length+1}`},{label:"value",value:r}];e.treeDataSource.dataSource=a.concat({key:r,duplicateKey:r,map:p,children:[]})},icon:t.jsx(vo,{infer:"Add"}),children:t.jsx(k,{token:"SettingComponents.DataSourceSetter.addNode"})})}),t.jsx("div",{className:`${o+"-layout-item-content"}`,children:t.jsx(Jr,{blockNode:!0,draggable:!0,allowDrop:e.allowTree?()=>!0:Oa,defaultExpandAll:!0,defaultExpandParent:!0,autoExpandParent:!0,showLine:{showLeafIcon:!1},treeData:e.treeDataSource.dataSource,onDragEnter:()=>{},onDrop:n,titleRender:r=>t.jsx(Ma,{...r,treeDataSource:e.treeDataSource}),onSelect:r=>{r[0]&&(e.treeDataSource.selectedKey=r[0].toString())}})})]})}),za=y(e=>{const{className:o,value:n=[],onChange:r,allowTree:a=!0,allowExtendOption:p=!0,defaultOptionValue:l,effects:d=()=>{}}=e,s=Zn(),i=V("data-source-setter"),[c,m]=b.useState(!1),u=b.useMemo(()=>Gr({dataSource:Ea(n),selectedKey:""}),[n,c]),g=()=>m(!0),C=()=>m(!1);return t.jsxs(b.Fragment,{children:[t.jsx(H,{block:!0,onClick:g,children:t.jsx(k,{token:"SettingComponents.DataSourceSetter.configureDataSource"})}),t.jsx(st,{title:t.jsx(k,{token:"SettingComponents.DataSourceSetter.configureDataSource"}),width:"65%",bodyStyle:{padding:10},transitionName:"",maskTransitionName:"",open:c,onCancel:C,onOk:()=>{r(Va(u.dataSource)),C()},children:t.jsxs("div",{className:`${B(i,o)} ${i+"-"+s} ${i+"-layout"}`,children:[t.jsx("div",{className:`${i+"-layout-item left"}`,children:t.jsx(La,{defaultOptionValue:l,allowTree:a,treeDataSource:u})}),t.jsx("div",{className:`${i+"-layout-item right"}`,children:t.jsx($a,{allowExtendOption:p,treeDataSource:u,effects:d})})]})})]})}),Ua=e=>{const o=e,n=c=>{let m="";for(let u=0;u<c;u++)m+=".";return m},r=(c,m)=>{const u=[],g=C=>{C&&C!==c?u.push(C.props.name||C.id):g(C.parent)};return g(m),u.reverse().join(".")},a=c=>{var m;return(m=c.children)==null?void 0:m.some(u=>u.props.type!=="void"&&u!==o?!0:a(u))},p=c=>{var m;return c!=null&&c.parent?((m=c==null?void 0:c.parent)==null?void 0:m.componentName)!==c.componentName?c.parent:p(c.parent):c},l=c=>{if(c!=null&&c.parent){if(c.parent.props.type==="array")return c.parent;if(c.parent!==i)return l(c.parent)}},d=(c,m)=>m.depth===o.depth?`.${m.props.name||m.id}`:`${n(o.depth-c.depth)}[].${r(c,m)}`,s=(c,m=[])=>c.reduce((u,g)=>{var co;if(g===o||g.props.type==="array"&&!g.contains(o)||g.props.type==="void"&&!a(g))return u;const C=m.concat(g.props.name||g.id),Ie=l(g),He=g.props.title||((co=g.props["x-component-props"])==null?void 0:co.title)||g.props.name||g.designerProps.title,Rn=Ie?d(Ie,g):C.join(".");return u.concat({label:He,value:Rn,node:g,children:s(g.children,C)})},[]),i=p(e);return i?s(i.children):[]},Ba=e=>{const o=Yn(),n=Ua(o),r=(a,p)=>{var l;for(let d=0;d<a.length;d++){const s=a[d];if(s.value===p)return s.node;if((l=s.children)!=null&&l.length){const i=r(s.children,p);if(i)return i}}};return t.jsx(Tr,{...e,onChange:a=>{var p;(p=e.onChange)==null||p.call(e,a,r(n,a))},treeDefaultExpandAll:!0,treeData:n})},O=`
/**
 * You can use the built-in context variables
 *
 * 1. \`$chrome\` 桥接浏览器扩展开发时的 chrome 对象的常用方法。目前只桥接了部分，还在完善中
 *     如果发现有不支持的方法，可用 $chrome.callMethodByPath 替代
 *     如果发现有不支持的属性，可用 $chrome.getPropertyByPath 替代
 *
 * 2. \`$ga\` 小助手暴露到低代码页面中的扩展开发的一些常用方法
 *
 * 3. \`$utils\` 小助手暴露到低代码页面中的常用工具方法
 *
 * 4. \`$self\` is the current Field Model
 *
 * 5. \`$form\` is the current Form Model
 *
 * 6. \`$deps\` is the dependencies value
 *
 * 7. \`$observable\` function is used to create an persistent observable state object
 *
 * 8. \`$memo\` function is is used to create a persistent data
 *
 * 9. \`$effect\` function is used to handle side-effect logic
 *
 * 10. \`$props\` function is used to set component props to current field
 *
 * Document Links
 *
 * https://react.formilyjs.org/api/shared/schema#%E5%86%85%E7%BD%AE%E8%A1%A8%E8%BE%BE%E5%BC%8F%E4%BD%9C%E7%94%A8%E5%9F%9F
 **/
`,Ke=`
/** 
 * Example 1
 * Static Boolean
 **/

false

/** 
 * Example 2
 * Equal Calculation
 **/

$deps.VariableName === 'TARGET_VALUE'

/** 
 * Example 3
 * Not Equal Calculation
 **/

$deps.VariableName !== 'TARGET_VALUE'

/** 
 * Example 4
 * And Logic Calculation
 **/

$deps.VariableName1 && $deps.VariableName2

/** 
 * Example 5
 * Grater Logic Calculation
 **/

$deps.VariableName > 100

/** 
 * Example 6
 * Not Logic Calculation
 **/

!$deps.VariableName

${O}
`,Wa=`
/** 
 * Example 1
 * Static Mode
 **/

'none'

/** 
 * Example 2
 * Equal Condition Associated
 **/

$deps.VariableName === 'TARGET_VALUE' ? 'visible' : 'none'

/** 
 * Example 3
 * Not Equal Condition Associated
 **/

$deps.VariableName !== 'TARGET_VALUE' ? 'visible' : 'hidden'

/** 
 * Example 4
 * And Logic Condition Associated
 **/

$deps.VariableName1 && $deps.VariableName2 ? 'visible' : 'none'

/** 
 * Example 5
 * Grater Logic Condition Associated
 **/

$deps.VariableName > 100 ? 'visible' : 'hidden'

/** 
 * Example 6
 * Not Logic Condition Associated
 **/

!$deps.VariableName ? 'visible' : 'none'

${O}
`,Ha=`
/** 
 * Example 1
 * Static Mode
 **/

'readPretty'

/** 
 * Example 2
 * Equal Condition Associated
 **/

$deps.VariableName === 'TARGET_VALUE' ? 'editable' : 'disabled'

/** 
 * Example 3
 * Not Equal Condition Associated
 **/

$deps.VariableName !== 'TARGET_VALUE' ? 'editable' : 'readOnly'

/** 
 * Example 4
 * And Logic Condition Associated
 **/

$deps.VariableName1 && $deps.VariableName2 ? 'editable' : 'readPretty'

/** 
 * Example 5
 * Grater Logic Condition Associated
 **/

$deps.VariableName > 100 ? 'editable' : 'readOnly'

/** 
 * Example 6
 * Not Logic Condition Associated
 **/

!$deps.VariableName ? 'editable' : 'disabled'

${O}
`,yo=`
/** 
 * Example 1
 * Static String
 **/

'Normal String Text'

/** 
 * Example 2
 * Associated String
 **/

$deps.VariableName === 'TARGET_VALUE' ? 'Associated String Text' : ''

${O}
`,bo=`
/** 
 * Example 1
 * String Type
 **/

'String'

/** 
 * Example 2
 * String Array
 **/

['StringArray']

/** 
 * Example 3
 * Object Array
 **/

[{ key: 'ObjectArray' }]

/** 
 * Example 4
 * Boolean
 **/

true

/** 
 * Example 5
 * RegExp
 **/

/d+/

/** 
 * Example 1
 * Associated String Value
 **/

$deps.VariableName + 'Compose String'

/** 
 * Example 2
 * Associated Array Value
 **/

[ $deps.VariableName ]

/** 
 * Example 3
 * Associated Object Value
 **/

{
  key : $deps.VariableName
}

/** 
 * Example 4
 * Associated Boolean Value
 **/

!$deps.VariableName

${O}
`,Ga=`
/** 
 * Example 1
 * Static DataSource
 **/

[
  { label : "item1", value: "1" },
  { label : "item2", value: "2" }
]

/** 
 * Example 2
 * Associated DataSource
 **/

[
  { label : "item1", value: "1" },
  { label : "item2", value: "2" },
  ...$deps.VariableName
]

${O}
`,Ja=`
/** 
 * Example 1
 * Static Props
 **/

{
  placeholder: "This is placeholder"
}

/** 
 * Example 2
 * Associated Props
 **/

{
  placeholder: $deps.VariableName
}

${O}
`,Qa=`
/** 
 * Example 1
 * Static Props
 **/

{
  labelCol:6
}

/** 
 * Example 2
 * Associated Props
 **/

{
  labelCol: $deps.VariableName
}

${O}
`,qa=`
/**
 * 监听输入框回车事件
 **/
$props({
  onPressEnter: (e) => {
    const keyword = e.target.value
    if (!keyword) {
      return
    }

    $message.info(\`TODO 搜索关键词\${keyword}\`)
  },
})

/**
 * 添加点击事件
 **/
$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})

/**
 * 展示 confirm 弹窗
 **/
$props({
  onClick: () => {
    $modal.confirm({
      title: "我是标题",
      content: "我是内容",
      okText: "确认",
      onOk: () => {
        $message.success("点击了确认")
      },
      cancelText: "取消",
      onCancel: () => {
        $message.info("点击了取消")
      },
    })
  },
})

/**
 * 点击后编辑当前页面
 **/
$props({
  onClick: () => {
    $ga.editCurrentPage()
  },
})

/**
 * 点击打开低代码页面管理页面
 **/
$props({
  onClick: () => {
    $ga.lowCodePageManage()
  },
})

/**
 * 点击打开用户脚本管理页面
 **/
$props({
  onClick: () => {
    $ga.userScriptManage()
  },
})

/**
 * 点击打开设置上帝小助手页面
 **/
$props({
  onClick: () => {
    $ga.settingAssistant()
  },
})

/**
 * 操作系统通知
 */
$props({
  onClick: () => {
    let myNotificationId

    // 创建系统通知
    $chrome.notifications.create(
      null,
      {
        type: "basic",
        title: "我是标题",
        message: "我是内容",
        iconUrl: "../images/128.png",
      },
      $chrome.proxy((notificationId) => {
        myNotificationId = notificationId
        $message.info(\`创建的系统通知 ID 为 \${notificationId}\`)
      })
    )

    // 延迟 3 秒更新系统通知
    setTimeout(() => {
      $chrome.notifications.update(
        myNotificationId,
        {
          type: "basic",
          title: "我是修改后的标题",
          message: "我是修改后内容",
          iconUrl: "../images/128.png",
        },
        $chrome.proxy((wasUpdated) => {
          $message.info(\`更新系统通知 \${wasUpdated}\`)
        })
      )
    }, 3000)

    // 延迟 6 秒清除系统通知
    setTimeout(() => {
      $chrome.notifications.clear(
        myNotificationId,
        $chrome.proxy((wasCleared) => {
          $message.info(\`清除系统通知 \${wasCleared}\`)
        })
      )
    }, 6000)
  },
})

/**
 * 获取指定的循环类组件的条目和索引
 * 使用场景：需要同时获取条目和索引
 */
$props({
  onClick: () => {
    // 第二个参数是可选的，默认值就是循环布局组件 IteratorLayout
    // const { row, index } = $utils.getArrayFieldRowAndIndex($self, "IteratorLayout")
    const { row, index } = $utils.getArrayFieldRowAndIndex($self)
    $message.info(\`点击了 \${index} | \${JSON.stringify(row)}\`)
  },
})

/**
 * 获取指定的循环类组件的条目
 * 使用场景：只需获取条目，不需获取索引
 */
$props({
  onClick: () => {
    // 第二个参数是可选的，默认值就是循环布局组件 IteratorLayout
    // const row = $utils.getArrayFieldRow($self, "IteratorLayout")
    const row = $utils.getArrayFieldRow($self)
    $message.info(\`点击了 \${JSON.stringify(row)}\`)
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-推荐
 */
$props({
  onClick: () => {
    // 默认就是取的条目的 url 字段来打开
    $utils.clickArrayFieldUrlItem($self)
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-相对复杂版本，仅用于演示 API 的使用
 */
$props({
  onClick: () => {
    // 获取迭代器布局中当前点击的条目数据
    const row = $utils.getArrayFieldRow($self)
    // openUrl 内部会自动区分编辑器环境（新标签）还是预览环境（当前标签）打来链接
    $utils.openUrl(row.url)
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-较复杂版本，仅用于演示 API 的使用
 */
$props({
  onClick: () => {
    // 获取迭代器布局中当前点击的条目数据
    const row = $utils.getArrayFieldRow($self)

    if ($utils.isEditorEnv) {
      // 编辑器环境 => 新建一个标签页打开链接
      $utils.openUrlInNewTab(tab.url)
    } else {
      // 预览环境 => 当前窗口选中的标签页替换链接
      $utils.openUrlInCurrentTab(row.url)
    }
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-最复杂版本，仅用于演示 API 的使用
 */
$props({
  onClick: async () => {
    // 获取迭代器布局中当前点击的条目数据
    const row = $utils.getArrayFieldRow($self)

    if ($utils.isEditorEnv) {
      // 编辑器环境 => 新建一个标签页打开链接
      $chrome.tabs.create({
        url: row.url,
      })
    } else {
      // 预览环境 => 当前窗口选中的标签页替换链接
      const tab = await $chrome.tabs.query({
        active: true,
        currentWindow: true,
      })
      $chrome.tabs.update(tab.id, { url: row.url })
    }
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-最复杂版本
 */
$props({
  onClick: async () => {
    // 获取迭代器布局中当前点击的条目数据
    const row = $utils.getArrayFieldRow($self)

    if ($utils.isEditorEnv) {
      // 编辑器环境 => 新建一个标签页打开链接
      $chrome.tabs.create({
        url: row.url,
      })
    } else {
      // 预览环境 => 当前窗口选中的标签页替换链接
      const tab = await $chrome.tabs.query({
        active: true,
        currentWindow: true,
      })
      $chrome.tabs.update(tab.id, { url: row.url })
    }
  },
})

/**
 * 设置指定的循环类组件内部的图标-推荐
 */
$effect(() => {
  // 后面 3 个参数都是可选的
  // $utils.setArrayFieldRowBookmarkIcon($self, "url", "icon", "IteratorLayout")
  $utils.setArrayFieldRowBookmarkIcon($self)
}, [])

/**
 * 设置指定的循环类组件内部的图标-相对复杂版本，仅用于演示 API 的使用
 */
$effect(() => {
  // 获取迭代器布局中当前点击的条目数据
  const row = $utils.getArrayFieldRow($self)
  // 获取书签的图标地址
  $utils.getBookmarkIconUrl(row.url, row.icon).then((iconUrl) => {
    $props({
      src: iconUrl,
    })
  })
}, [])

/**
 * 操作剪贴板
 **/
$props({
  onClick: async () => {
    // 复制文本到剪贴板
    $utils.copyTextToClipboard("我是剪贴板内容")

    // 从剪贴板读取内容
    const text = await $utils.readTextFromClipboard()
    $message.info(\`获取到剪贴板内容 \${text}\`)
  },
})

/**
 * Example 1
 * Async Select
 **/
$effect(()=>{
  $self.loading = true
  fetch('//some.domain/getSomething')
    .then(response=>response.json())
    .then(({ data })=>{
      $self.loading = false
      $self.dataSource = data
    },()=>{
      $self.loading = false
    })
},[])

/**
 * Example 2
 * Async Search Select
 **/
const state = $observable({
  keyword:''
})

$props({
  onSearch(keyword){
    state.keyword = keyword
  }
})

$effect(()=>{
  $self.loading = true
  fetch(\`//some.domain/getSomething?q=\${state.keyword}\`)
    .then(response=>response.json())
    .then(({ data })=>{
      $self.loading = false
      $self.dataSource = data
    },()=>{
      $self.loading = false
    })
},[ state.keyword ])

/**
 * Example 3
 * Async Associated Select
 **/

const state = $observable({
  keyword:''
})

$props({
  onSearch(keyword){
    state.keyword = keyword
  }
})

$effect(()=>{
  $self.loading = true
  fetch(\`//some.domain/getSomething?q=\${state.keyword}&other=\${$deps.VariableName}\`)
    .then(response=>response.json())
    .then(({ data })=>{
      $self.loading = false
      $self.dataSource = data
    },()=>{
      $self.loading = false
    })
},[ state.keyword, $deps.VariableName ])

${O}
`,So=[{key:"visible",type:"boolean",helpCode:Ke},{key:"hidden",type:"boolean",helpCode:Ke},{key:"display",type:'"visible" | "hidden" | "none"',helpCode:Wa},{key:"pattern",type:'"editable" | "disabled" | "readOnly" | "readPretty"',helpCode:Ha},{key:"title",type:"string",helpCode:yo},{key:"description",type:"string",helpCode:yo},{key:"value",type:"any",helpCode:bo},{key:"initialValue",type:"any",helpCode:bo},{key:"required",type:"boolean",helpCode:Ke},{key:"dataSource",type:"Array<{label?:string,value?:any}>",helpCode:Ga},{key:"componentProps",token:"componentProps",type:"object",helpCode:Ja},{key:"decoratorProps",token:"decoratorProps",type:"object",helpCode:Qa}],Ka=e=>{if(e)return e.trim()},Za=e=>{const[o,n]=b.useState(["visible"]),r=V("field-property-setter"),a={...e.value},p=s=>{var i;return s&&((i=String(s).match(/^\{\{([\s\S]*)\}\}$/))==null?void 0:i[1])||""},l=s=>jo(s,(i,c,m)=>(!c||c==="{{}}"||(i[m]=c),i),{}),d=So.find(s=>s.key===o[0]);return t.jsxs("div",{className:r,children:[t.jsx(qe,{mode:"vertical",style:{width:200,height:300,paddingRight:4,overflowY:"auto",overflowX:"hidden"},defaultSelectedKeys:o,selectedKeys:o,onSelect:({selectedKeys:s})=>{n(s)},children:So.map(s=>Po(s)?t.jsx(qe.Item,{children:t.jsx(k,{token:`SettingComponents.ReactionsSetter.${s.token||s.key}`})},s.key):t.jsx(qe.Item,{children:t.jsx(k,{token:`SettingComponents.ReactionsSetter.${s}`})},s))}),t.jsxs("div",{className:r+"-coder-wrapper",children:[t.jsxs("div",{className:r+"-coder-start",children:[`$self.${o[0]} = (`,t.jsxs("span",{style:{fontSize:14,marginLeft:10,color:"#888",fontWeight:"normal"},children:["//"," ",t.jsx(k,{token:"SettingComponents.ReactionsSetter.expressionValueTypeIs"})," ","`",d==null?void 0:d.type,"`"]})]}),t.jsx("div",{className:r+"-coder",children:t.jsx(be,{language:"javascript.expression",extraLib:e.extraLib,helpCode:Ka(d==null?void 0:d.helpCode),value:p(a[o[0]]),options:{lineNumbers:"off",wordWrap:"on",glyphMargin:!1,folding:!1,lineDecorationsWidth:0,lineNumbersMinChars:0,minimap:{enabled:!1}},onChange:s=>{var i;(i=e.onChange)==null||i.call(e,l({...a,[o[0]]:`{{${s}}}`}))}},o[0])}),t.jsx("div",{className:r+"-coder-end",children:")"})]})]})},Ya=`
/**
 * Execution environment for a user script.
 */
export type ExecutionWorld = "MAIN" | "USER_SCRIPT";

/**
 * Properties for configuring the user script world.
 */
export interface WorldProperties {
    /** Specifies the world csp. The default is the \`ISOLATED\` world csp. */
    csp?: string;
    /** Specifies whether messaging APIs are exposed. The default is false.*/
    messaging?: boolean;
}

/**
 * Properties for filtering user scripts.
 */
export interface UserScriptFilter {
    ids?: string[];
}

/**
 * Properties for a registered user script.
 */
export interface RegisteredUserScript {
    /** If true, it will inject into all frames, even if the frame is not the top-most frame in the tab. Each frame is checked independently for URL requirements; it will not inject into child frames if the URL requirements are not met. Defaults to false, meaning that only the top frame is matched. */
    allFrames?: boolean;
    /** Specifies wildcard patterns for pages this user script will NOT be injected into. */
    excludeGlobs?: string[];
    /**Excludes pages that this user script would otherwise be injected into. See Match Patterns for more details on the syntax of these strings. */
    excludeMatches?: string[];
    /** The ID of the user script specified in the API call. This property must not start with a '_' as it's reserved as a prefix for generated script IDs. */
    id: string;
    /** Specifies wildcard patterns for pages this user script will be injected into. */
    includeGlobs?: string[];
    /** The list of ScriptSource objects defining sources of scripts to be injected into matching pages. */
    js: ScriptSource[];
    /** Specifies which pages this user script will be injected into. See Match Patterns for more details on the syntax of these strings. This property must be specified for \${ref:register}. */
    matches?: string[];
    /** Specifies when JavaScript files are injected into the web page. The preferred and default value is document_idle */
    runAt?: RunAt;
    /** The JavaScript execution environment to run the script in. The default is \`USER_SCRIPT\` */
    world?: ExecutionWorld;
}

/**
 * Properties for a script source.
 */
export interface ScriptSource {
    /** A string containing the JavaScript code to inject. Exactly one of file or code must be specified. */
    code?: string;
    /** The path of the JavaScript file to inject relative to the extension's root directory. Exactly one of file or code must be specified. */
    file?: string;
}

/**
 * Enum for the run-at property.
 */
export type RunAt = "document_start" | "document_end" | "document_idle";
`,Xa=`
export type TemplateType = "basic" | "image" | "list" | "progress";

export interface ButtonOptions {
    title: string;
    iconUrl?: string | undefined;
}

export interface ItemOptions {
    /** Title of one item of a list notification. */
    title: string;
    /** Additional details about this item. */
    message: string;
}

export type NotificationOptions<T extends boolean = false> =
    & {
        /**
         * Optional.
         * Alternate notification content with a lower-weight font.
         * @since Chrome 31
         */
        contextMessage?: string | undefined;
        /** Optional. Priority ranges from -2 to 2. -2 is lowest priority. 2 is highest. Zero is default. */
        priority?: number | undefined;
        /** Optional. A timestamp associated with the notification, in milliseconds past the epoch (e.g. Date.now() + n). */
        eventTime?: number | undefined;
        /** Optional. Text and icons for up to two notification action buttons. */
        buttons?: ButtonOptions[] | undefined;
        /** Optional. Items for multi-item notifications. */
        items?: ItemOptions[] | undefined;
        /**
         * Optional.
         * Current progress ranges from 0 to 100.
         * @since Chrome 30
         */
        progress?: number | undefined;
        /**
         * Optional.
         * Whether to show UI indicating that the app will visibly respond to clicks on the body of a notification.
         * @since Chrome 32
         */
        isClickable?: boolean | undefined;
        /**
         * Optional.
         * A URL to the app icon mask. URLs have the same restrictions as iconUrl. The app icon mask should be in alpha channel, as only the alpha channel of the image will be considered.
         * @since Chrome 38
         */
        appIconMaskUrl?: string | undefined;
        /** Optional. A URL to the image thumbnail for image-type notifications. URLs have the same restrictions as iconUrl. */
        imageUrl?: string | undefined;
        /**
         * Indicates that the notification should remain visible on screen until the user activates or dismisses the notification.
         * This defaults to false.
         * @since Chrome 50
         */
        requireInteraction?: boolean | undefined;
        /**
         * Optional.
         * Indicates that no sounds or vibrations should be made when the notification is being shown. This defaults to false.
         * @since Chrome 70
         */
        silent?: boolean | undefined;
    }
    & (T extends true ? {
            /**
             * A URL to the sender's avatar, app icon, or a thumbnail for image notifications.
             * URLs can be a data URL, a blob URL, or a URL relative to a resource within this extension's .crx file. Required for notifications.create method.
             */
            iconUrl: string;
            /** Main notification content. Required for notifications.create method. */
            message: string;
            /** Which type of notification to display. Required for notifications.create method. */
            type: TemplateType;
            /** Title of the notification (e.g. sender name for email). Required for notifications.create method. */
            title: string;
        }
        : {
            /**
             * Optional.
             * A URL to the sender's avatar, app icon, or a thumbnail for image notifications.
             * URLs can be a data URL, a blob URL, or a URL relative to a resource within this extension's .crx file. Required for notifications.create method.
             */
            iconUrl?: string | undefined;
            /** Optional. Main notification content. Required for notifications.create method. */
            message?: string | undefined;
            /** Optional. Which type of notification to display. Required for notifications.create method. */
            type?: TemplateType | undefined;
            /** Optional. Title of the notification (e.g. sender name for email). Required for notifications.create method. */
            title?: string | undefined;
        });
`,_a=`
/**
 * Specifies what type of browser window to create.
 * 'panel' is deprecated and is available only to existing whitelisted extensions on Chrome OS.
 * @since Chrome 44
 */
export type createTypeEnum = "normal" | "popup" | "panel";

/**
 * The state of this browser window.
 * In some circumstances a window may not be assigned a state property; for example, when querying closed windows from the sessions API.
 * @since Chrome 44
 */
export type windowStateEnum = "normal" | "minimized" | "maximized" | "fullscreen" | "locked-fullscreen";

/**
 * The type of browser window this is.
 * In some circumstances a window may not be assigned a type property; for example, when querying closed windows from the sessions API.
 * @since Chrome 44
 */
export type windowTypeEnum = "normal" | "popup" | "panel" | "app" | "devtools";

export interface CreateData {
    /**
     * Optional. The id of the tab for which you want to adopt to the new window.
     * @since Chrome 10
     */
    tabId?: number | undefined;
    /**
     * Optional.
     * A URL or array of URLs to open as tabs in the window. Fully-qualified URLs must include a scheme (i.e. 'http://www.google.com', not 'www.google.com'). Relative URLs will be relative to the current page within the extension. Defaults to the New Tab Page.
     */
    url?: string | string[] | undefined;
    /**
     * Optional.
     * The number of pixels to position the new window from the top edge of the screen. If not specified, the new window is offset naturally from the last focused window. This value is ignored for panels.
     */
    top?: number | undefined;
    /**
     * Optional.
     * The height in pixels of the new window, including the frame. If not specified defaults to a natural height.
     */
    height?: number | undefined;
    /**
     * Optional.
     * The width in pixels of the new window, including the frame. If not specified defaults to a natural width.
     */
    width?: number | undefined;
    /**
     * Optional. If true, opens an active window. If false, opens an inactive window.
     * @since Chrome 12
     */
    focused?: boolean | undefined;
    /** Optional. Whether the new window should be an incognito window. */
    incognito?: boolean | undefined;
    /** Optional. Specifies what type of browser window to create. */
    type?: createTypeEnum | undefined;
    /**
     * Optional.
     * The number of pixels to position the new window from the left edge of the screen. If not specified, the new window is offset naturally from the last focused window. This value is ignored for panels.
     */
    left?: number | undefined;
    /**
     * Optional. The initial state of the window. The 'minimized', 'maximized' and 'fullscreen' states cannot be combined with 'left', 'top', 'width' or 'height'.
     * @since Chrome 44
     */
    state?: windowStateEnum | undefined;
    /**
     * If true, the newly-created window's 'window.opener' is set to the caller and is in the same [unit of related browsing contexts](https://www.w3.org/TR/html51/browsers.html#unit-of-related-browsing-contexts) as the caller.
     * @since Chrome 64
     */
    setSelfAsOpener?: boolean | undefined;
}

export interface Window {
    /** Optional. Array of tabs.Tab objects representing the current tabs in the window. */
    tabs?: chrome.tabs.Tab[] | undefined;
    /** Optional. The offset of the window from the top edge of the screen in pixels. Under some circumstances a Window may not be assigned top property, for example when querying closed windows from the sessions API. */
    top?: number | undefined;
    /** Optional. The height of the window, including the frame, in pixels. Under some circumstances a Window may not be assigned height property, for example when querying closed windows from the sessions API. */
    height?: number | undefined;
    /** Optional. The width of the window, including the frame, in pixels. Under some circumstances a Window may not be assigned width property, for example when querying closed windows from the sessions API. */
    width?: number | undefined;
    /**
     * The state of this browser window.
     * @since Chrome 17
     */
    state?: windowStateEnum | undefined;
    /** Whether the window is currently the focused window. */
    focused: boolean;
    /**
     * Whether the window is set to be always on top.
     * @since Chrome 19
     */
    alwaysOnTop: boolean;
    /** Whether the window is incognito. */
    incognito: boolean;
    /**
     * The type of browser window this is.
     */
    type?: windowTypeEnum | undefined;
    /** Optional. The ID of the window. Window IDs are unique within a browser session. Under some circumstances a Window may not be assigned an ID, for example when querying windows using the sessions API, in which case a session ID may be present. */
    id?: number | undefined;
    /** Optional. The offset of the window from the left edge of the screen in pixels. Under some circumstances a Window may not be assigned left property, for example when querying closed windows from the sessions API. */
    left?: number | undefined;
    /**
     * Optional. The session ID used to uniquely identify a Window obtained from the sessions API.
     * @since Chrome 31
     */
    sessionId?: string | undefined;
}

export interface QueryOptions {
    /**
     * Optional.
     * If true, the windows.Window object will have a tabs property that contains a list of the tabs.Tab objects.
     * The Tab objects only contain the url, pendingUrl, title and favIconUrl properties if the extension's manifest file includes the "tabs" permission.
     */
    populate?: boolean | undefined;
    /**
     * If set, the Window returned is filtered based on its type. If unset, the default filter is set to ['normal', 'popup'].
     */
    windowTypes?: windowTypeEnum[] | undefined;
}
`,ei=`
export interface Tab {
  /**
   * Optional.
   * Either loading or complete.
   */
  status?: string | undefined;
  /** The zero-based index of the tab within its window. */
  index: number;
  /**
   * Optional.
   * The ID of the tab that opened this tab, if any. This property is only present if the opener tab still exists.
   * @since Chrome 18
   */
  openerTabId?: number | undefined;
  /**
   * Optional.
   * The title of the tab. This property is only present if the extension's manifest includes the "tabs" permission.
   */
  title?: string | undefined;
  /**
   * Optional.
   * The URL the tab is displaying. This property is only present if the extension's manifest includes the "tabs" permission.
   */
  url?: string | undefined;
  /**
   * The URL the tab is navigating to, before it has committed.
   * This property is only present if the extension's manifest includes the "tabs" permission and there is a pending navigation.
   * @since Chrome 79
   */
  pendingUrl?: string | undefined;
  /**
   * Whether the tab is pinned.
   * @since Chrome 9
   */
  pinned: boolean;
  /**
   * Whether the tab is highlighted.
   * @since Chrome 16
   */
  highlighted: boolean;
  /** The ID of the window the tab is contained within. */
  windowId: number;
  /**
   * Whether the tab is active in its window. (Does not necessarily mean the window is focused.)
   * @since Chrome 16
   */
  active: boolean;
  /**
   * Optional.
   * The URL of the tab's favicon. This property is only present if the extension's manifest includes the "tabs" permission. It may also be an empty string if the tab is loading.
   */
  favIconUrl?: string | undefined;
  /**
   * Optional.
   * The ID of the tab. Tab IDs are unique within a browser session. Under some circumstances a Tab may not be assigned an ID, for example when querying foreign tabs using the sessions API, in which case a session ID may be present. Tab ID can also be set to chrome.tabs.TAB_ID_NONE for apps and devtools windows.
   */
  id?: number | undefined;
  /** Whether the tab is in an incognito window. */
  incognito: boolean;
  /**
   * Whether the tab is selected.
   * @deprecated since Chrome 33. Please use tabs.Tab.highlighted.
   */
  selected: boolean;
  /**
   * Optional.
   * Whether the tab has produced sound over the past couple of seconds (but it might not be heard if also muted). Equivalent to whether the speaker audio indicator is showing.
   * @since Chrome 45
   */
  audible?: boolean | undefined;
  /**
   * Whether the tab is discarded. A discarded tab is one whose content has been unloaded from memory, but is still visible in the tab strip. Its content gets reloaded the next time it's activated.
   * @since Chrome 54
   */
  discarded: boolean;
  /**
   * Whether the tab can be discarded automatically by the browser when resources are low.
   * @since Chrome 54
   */
  autoDiscardable: boolean;
  /**
   * Optional.
   * Current tab muted state and the reason for the last state change.
   * @since Chrome 46
   */
  mutedInfo?: MutedInfo | undefined;
  /**
   * Optional. The width of the tab in pixels.
   * @since Chrome 31
   */
  width?: number | undefined;
  /**
   * Optional. The height of the tab in pixels.
   * @since Chrome 31
   */
  height?: number | undefined;
  /**
   * Optional. The session ID used to uniquely identify a Tab obtained from the sessions API.
   * @since Chrome 31
   */
  sessionId?: string | undefined;
  /**
   * The ID of the group that the tab belongs to.
   * @since Chrome 88
   */
  groupId: number;
  /**
   * The last time the tab was accessed as the number of milliseconds since epoch.
   * @since Chrome 121
   */
  lastAccessed?: number | undefined;
}

export interface QueryInfo {
  /**
   * Optional. Whether the tabs have completed loading.
   * One of: "loading", or "complete"
   */
  status?: "loading" | "complete" | undefined;
  /**
   * Optional. Whether the tabs are in the last focused window.
   * @since Chrome 19
   */
  lastFocusedWindow?: boolean | undefined;
  /** Optional. The ID of the parent window, or windows.WINDOW_ID_CURRENT for the current window. */
  windowId?: number | undefined;
  /**
   * Optional. The type of window the tabs are in.
   * One of: "normal", "popup", "panel", "app", or "devtools"
   */
  windowType?: "normal" | "popup" | "panel" | "app" | "devtools" | undefined;
  /** Optional. Whether the tabs are active in their windows. */
  active?: boolean | undefined;
  /**
   * Optional. The position of the tabs within their windows.
   * @since Chrome 18
   */
  index?: number | undefined;
  /** Optional. Match page titles against a pattern. */
  title?: string | undefined;
  /** Optional. Match tabs against one or more URL patterns. Note that fragment identifiers are not matched. */
  url?: string | string[] | undefined;
  /**
   * Optional. Whether the tabs are in the current window.
   * @since Chrome 19
   */
  currentWindow?: boolean | undefined;
  /** Optional. Whether the tabs are highlighted. */
  highlighted?: boolean | undefined;
  /**
   * Optional.
   * Whether the tabs are discarded. A discarded tab is one whose content has been unloaded from memory, but is still visible in the tab strip. Its content gets reloaded the next time it's activated.
   * @since Chrome 54
   */
  discarded?: boolean | undefined;
  /**
   * Optional.
   * Whether the tabs can be discarded automatically by the browser when resources are low.
   * @since Chrome 54
   */
  autoDiscardable?: boolean | undefined;
  /** Optional. Whether the tabs are pinned. */
  pinned?: boolean | undefined;
  /**
   * Optional. Whether the tabs are audible.
   * @since Chrome 45
   */
  audible?: boolean | undefined;
  /**
   * Optional. Whether the tabs are muted.
   * @since Chrome 45
   */
  muted?: boolean | undefined;
  /**
   * Optional. The ID of the group that the tabs are in, or chrome.tabGroups.TAB_GROUP_ID_NONE for ungrouped tabs.
   * @since Chrome 88
   */
  groupId?: number | undefined;
}

export interface CreateProperties {
  /** Optional. The position the tab should take in the window. The provided value will be clamped to between zero and the number of tabs in the window. */
  index?: number | undefined;
  /**
   * Optional.
   * The ID of the tab that opened this tab. If specified, the opener tab must be in the same window as the newly created tab.
   * @since Chrome 18
   */
  openerTabId?: number | undefined;
  /**
   * Optional.
   * The URL to navigate the tab to initially. Fully-qualified URLs must include a scheme (i.e. 'http://www.google.com', not 'www.google.com'). Relative URLs will be relative to the current page within the extension. Defaults to the New Tab Page.
   */
  url?: string | undefined;
  /**
   * Optional. Whether the tab should be pinned. Defaults to false
   * @since Chrome 9
   */
  pinned?: boolean | undefined;
  /** Optional. The window to create the new tab in. Defaults to the current window. */
  windowId?: number | undefined;
  /**
   * Optional.
   * Whether the tab should become the active tab in the window. Does not affect whether the window is focused (see windows.update). Defaults to true.
   * @since Chrome 16
   */
  active?: boolean | undefined;
  /**
   * Optional. Whether the tab should become the selected tab in the window. Defaults to true
   * @deprecated since Chrome 33. Please use active.
   */
  selected?: boolean | undefined;
}

export interface UpdateProperties {
  /**
   * Optional. Whether the tab should be pinned.
   * @since Chrome 9
   */
  pinned?: boolean | undefined;
  /**
   * Optional. The ID of the tab that opened this tab. If specified, the opener tab must be in the same window as this tab.
   * @since Chrome 18
   */
  openerTabId?: number | undefined;
  /** Optional. A URL to navigate the tab to. */
  url?: string | undefined;
  /**
   * Optional. Adds or removes the tab from the current selection.
   * @since Chrome 16
   */
  highlighted?: boolean | undefined;
  /**
   * Optional. Whether the tab should be active. Does not affect whether the window is focused (see windows.update).
   * @since Chrome 16
   */
  active?: boolean | undefined;
  /**
   * Optional. Whether the tab should be selected.
   * @deprecated since Chrome 33. Please use highlighted.
   */
  selected?: boolean | undefined;
  /**
   * Optional. Whether the tab should be muted.
   * @since Chrome 45
   */
  muted?: boolean | undefined;
  /**
   * Optional. Whether the tab should be discarded automatically by the browser when resources are low.
   * @since Chrome 54
   */
  autoDiscardable?: boolean | undefined;
}

export interface ReloadProperties {
  /** Optional. Whether using any local cache. Default is false. */
  bypassCache?: boolean | undefined;
}

export interface MessageSendOptions {
  /** Optional. Send a message to a specific frame identified by frameId instead of all frames in the tab. */
  frameId?: number | undefined;
  /**
   * Optional. Send a message to a specific document identified by documentId instead of all frames in the tab.
   * @since Chrome 106
   */
  documentId?: string;
}
`,ti=`
/**
 * 桥接浏览器扩展开发时的 chrome 对象的常用方法。目前只桥接了部分，还在完善中
 * 如果发现有不支持的方法，可用 $chrome.callMethodByPath 替代
 * 如果发现有不支持的属性，可用 $chrome.getPropertyByPath 替代
 */
export interface IChrome {
  /**
   * 沙箱中不支持访问 window.localStorage，该对象桥接的 window.localStorage
   */
  localStorage: ILocalStorage
  /**
   * 桥接 window.fetch，用于支持跨域发起网络请求
   */
  fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response>
  /**
   * 代理对象或回调方法
   */
  proxy<T extends {}>(obj: T): T & ProxyMarked
  /**
   * 根据路径执行 chrome.aa.bb.cc 方法
   * @param apiPath api 路径，例如 'storage.local.get'
   * @param arg1 方法参数1
   * @param arg2 方法参数2
   * @param arg3 方法参数3
   * @param arg4 方法参数4
   * @returns 对应方法执行结果
   */
  callMethodByPath(
    apiPath: string,
    arg1?: any,
    arg2?: any,
    arg3?: any,
    arg4?: any
  ): Promise<any>
  /**
   * 根据路径获取 chrome.aa.bb.cc 属性
   * @param propertyPath property 路径，例如 'runtime.id'
   * @returns 对应属性的值
   */
  getPropertyByPath(propertyPath: string): Promise<any>
  /**
   * 桥接 chrome.storage
   */
  storage: IStorage
  /**
   * 桥接 chrome.runtime
   */
  runtime: IRuntime
  /**
   * 桥接 chrome.tabs
   */
  tabs: ITabs
  /**
   * 桥接 chrome.windows
   */
  windows: IWindows
  /**
   * 桥接 chrome.notifications
   */
  notifications: INotifications
  /**
   * 桥接 chrome.userScripts
   */
  userScripts: IUserScript
}

/**
 * 沙箱中不支持访问 window.localStorage，该对象桥接的 window.localStorage
 */
export interface ILocalStorage {
  getItem(key: string): Promise<string | null>
  setItem(key: string, value: string): Promise<void>
  removeItem(key: string): Promise<void>
  clear(): Promise<void>
}

${Ya}
/**
 * 桥接 chrome.userScripts
 */
export interface IUserScript {
  configureWorld(properties: chrome.userScripts.WorldProperties): Promise<void>
  getScripts(
    filter?: chrome.userScripts.UserScriptFilter
  ): Promise<chrome.userScripts.RegisteredUserScript[]>
  register(scripts: chrome.userScripts.RegisteredUserScript[]): Promise<void>
  update(scripts: chrome.userScripts.RegisteredUserScript[]): Promise<void>
  unregister(filter?: chrome.userScripts.UserScriptFilter): Promise<void>
}

${Xa}
/**
 * 桥接 chrome.notifications
 */
export interface INotifications {
  create(
    notificationId: string,
    options: NotificationOptions<true>,
    callback?: (notificationId: string) => void
  ): Promise<void>

  update(
    notificationId: string,
    options: NotificationOptions,
    callback?: (wasUpdated: boolean) => void
  ): Promise<void>

  clear(
    notificationId: string,
    callback?: (wasCleared: boolean) => void
  ): Promise<void>
}

${_a}
/**
 * 桥接 chrome.windows
 */
export interface IWindows {
  create(createData?: CreateData): Promise<Window>
  get(windowId: number): Promise<Window>
  get(windowId: number, queryOptions: QueryOptions): Promise<Window>
  getCurrent(): Promise<Window>
  getCurrent(queryOptions: QueryOptions): Promise<Window>
  getAll(): Promise<Window[]>
  getAll(queryOptions: QueryOptions): Promise<Window[]>
  update(windowId: number, updateInfo: UpdateInfo): Promise<Window>
  remove(windowId: number): Promise<void>
  getLastFocused(): Promise<Window>
  getLastFocused(queryOptions: QueryOptions): Promise<Window>
}

${ei}
/**
 * 桥接 chrome.tabs
 */
export interface ITabs {
  create(
    createProperties: CreateProperties
  ): Promise<Tab>
  query(queryInfo: QueryInfo): Promise<Tab[]>
  update(updateProperties: UpdateProperties): Promise<Tab>
  update(tabId: number, updateProperties: UpdateProperties): Promise<Tab>
  reload(tabId: number, reloadProperties?: ReloadProperties): Promise<void>
  reload(reloadProperties: ReloadProperties): Promise<void>
  reload(): Promise<void>
  get(tabId: number): Promise<Tab>
  getCurrent(): Promise<Tab | undefined>
  sendMessage(tabId: number, message: any, responseCallback: (response: any) => void): Promise<void>
  sendMessage(tabId: number, message: any, options: MessageSendOptions, responseCallback: (response: any) => void): Promise<void>
  sendMessage(tabId: number, message: any): Promise<any>
  sendMessage(tabId: number, message: any, options: MessageSendOptions): Promise<any>
}

/**
 * 桥接 chrome.runtime
 */
export interface IRuntime {
  getId(): Promise<string>
  getURL(path: string): Promise<string>
  getManifest(): Promise<any>

  sendMessage(message: any, responseCallback: (response: any) => void): Promise<void>
  sendMessage(message: any, options: MessageSendOptions, responseCallback: (response: any) => void): Promise<void>
  sendMessage(message: any): Promise<any>
  sendMessage(message: any, options: MessageSendOptions): Promise<any>

  sendMessage(extensionId: string | undefined | null, message: any, responseCallback: (response: any) => void): Promise<void>
  sendMessage(extensionId: string | undefined | null, message: any, options: MessageSendOptions, responseCallback: (response: any) => void): Promise<void>
  sendMessage(extensionId: string | undefined | null, message: any): Promise<any>
  sendMessage(extensionId: string | undefined | null, message: any, options: MessageSendOptions): Promise<any>

  onMessage: {
    addListener(callback: (message: any, sender: any, sendResponse: (response?: any) => void) => void): void
  }
}

/**
 * 桥接 chrome.storage
 */
export interface IStorage {
  local: IStorageArea
  sync: IStorageArea
  session: IStorageArea
}

/**
 * 桥接 chrome.storage.xxx
 */
export interface IStorageArea {
  get(
    keys?: string | string[] | { [key: string]: any } | null
  ): Promise<{ [key: string]: any }>
  set(items: { [key: string]: any }): Promise<void>
  remove(keys: string | string[]): Promise<void>
  clear(): Promise<void>
}

/**
 * 暴露到低代码页面中的 $ga 上下文对象，封装了扩展开发的一些常用工具方法
 */
export interface IBridge {
  /**
   * 编辑当前页面
   */
  editCurrentPage(): Promise<Tab>
  /**
   * 低代码页面管理
   */
  lowCodePageManage(): Promise<Tab>
  /**
   * 用户脚本管理
   */
  userScriptManage(): Promise<Tab>
  /**
   * 低代码区块模板市场
   */
  dynamicSchemaBlockTemplateMarket(): Promise<Tab>
  /**
   * 低代码页面模板市场
   */
  lowCodePageTemplateMarket(): Promise<Tab>
  /**
   * 用户脚本市场
   */
  userScriptMarket(): Promise<Tab>
  /**
   * 设置上帝小助手
   */
  settingAssistant(): Promise<Tab>
  /**
   * 关于
   */
  about(): Promise<Tab>
  /**
   * 隐私声明
   */
  privacy(): Promise<Tab>
}

declare global {
  /**
   * 暴露到低代码页面中的 $ga 上下文对象，封装了扩展开发的一些常用工具方法
   */
  declare var $ga: IBridge
  /**
   * 桥接浏览器扩展开发时的 chrome 对象的常用方法。目前只桥接了部分，还在完善中
   * 如果发现有不支持的方法，可用 $chrome.callMethodByPath 替代
   * 如果发现有不支持的属性，可用 $chrome.getPropertyByPath 替代
   */
  declare var $chrome: IChrome
}
`,oi=`{
/**
 * 延迟指定毫秒后执行
 * @param time 要延迟的毫秒数
 */
sleep(time: number): Promise<unknown>
/**
 * 获取 url 参数
 * @param name 参数名称
 */
getQueryString(name: string): string | null
/**
 * 导出 json 文件
 * @param jsonString 要导出的 json 字符串
 * @param filename 导出的文件名
 */
exportJsonToFile(jsonString: string, filename: string): void
/**
 * 从本地 json 文件导入数据
 * @returns 从本地 json 文件导入的 json 对象
 */
importJsonFromFile<T>(): Promise<{
    result: T | null;
    canceled: boolean;
}>
/**
 * 从剪贴板导入 json 数据
 * @returns 从剪贴板导入的 json 对象
 */
importJsonFromClipboard<T>(): Promise<T | null>
/**
 * 复制文字到剪贴板
 * @param text 要复制的内容
 */
copyTextToClipboard(text: string): Promise<void>
/**
 * 从剪贴板读取文本内容
 * @returns 从剪贴板读取到的文本内容
 */
readTextFromClipboard(): Promise<string>
/**
 * 复制图片到剪贴板
 * @param imageUrl 要复制的图片 url
 */
copyImageToClipboard(imageUrl: string): Promise<void>
/**
 * 获取指定的循环类组件的条目数据和索引
 * @param 条目 Field 或条目里的子 Field，大部分情况传递 $self 即可
 * @param componentType 默认为 IteratorLayout 循环布局。可选值为 ArrayTable、Table、IteratorLayout、ArrayTabs、ArrayCards、ArrayAccordion 之一
 */
getArrayFieldRowAndIndex(field: GeneralField, componentType?: 'IteratorLayout' | 'ArrayTable'|'Table' | 'ArrayTabs' | 'ArrayCards' | 'ArrayAccordion'): {
    row: any;
    index: number;
}
/**
 * 获取指定的循环类组件的条目数据
 * @param 条目 Field 或条目里的子 Field，大部分情况传递 $self 即可
 * @param componentType 默认为 IteratorLayout 循环布局。可选值为 ArrayTable、Table、IteratorLayout、ArrayTabs、ArrayCards、ArrayAccordion 之一
 */
getArrayFieldRow(field: GeneralField, componentType?: 'IteratorLayout' | 'ArrayTable'|'Table' | 'ArrayTabs' | 'ArrayCards' | 'ArrayAccordion'): any
/**
 * 获取书签的图标地址
 * @param url 书签地址
 * @param defaultIcon 用户指定的默认书签图标地址，如果指定了该值就会以该值为准，否则扩展内部会自动抓取图标地址
 */
getBookmarkIconUrl(url: string, defaultIcon?: string): Promise<string>
/**
 * 获取书签的图标地址（比 getBookmarkIconUrl 速度更快，但前提是之前访问过对应的页面，否则就是个默认图片）
 * @param url 书签地址
 * @param defaultIcon 用户指定的默认书签图标地址，如果指定了该值就会以该值为准，否则扩展内部会自动抓取图标地址
 */
getBookmarkIconUrlFast(url: string, defaultIcon?: string): Promise<string>
/**
 * 设置指定的循环类组件里书签图标
 * @param field 条目里的图片 Field，大部分情况传递 $self 即可
 * @param urlKey 链接对应的字段名，默认为 url
 * @param defaultIconKey 默认图标对应的字段名，默认为 icon
 * @param componentType 默认为 IteratorLayout 循环布局。可选值为 ArrayTable、Table、IteratorLayout、ArrayTabs、ArrayCards、ArrayAccordion 之一
 */
setArrayFieldRowBookmarkIcon(field: GeneralField, urlKey?: string, defaultIconKey?: string, componentType?: ComponentType): Promise<void>
/**
 * 获取 vip 配置信息
 * @param isNeedShowVipDialog 是否展示 vip 开通提示弹窗，默认为 true
 * @param isNeedCheckUpdate 是否检查更新，默认为 true
 */
getVipConfig(isNeedShowVipDialog?: boolean, isNeedCheckUpdate?: boolean): Promise<any>
/**
 * 获取扩展配置信息
 */
getAssistantConfig(): Promise<any>
/**
 * 在新标签页中打开链接
 * @param url 要打开的链接
 */
openUrlInNewTab(url: string): Promise<Tab | undefined>
/**
 * 在当前标签页中打开链接
 * @param url 要打开的链接
 */
openUrlInCurrentTab(url: string): Promise<Tab | undefined>
/**
 * 打开链接，该方法会判断运行环境，如果是编辑器环境，则在新标签页中打开链接，否则在当前标签页中打开链接
 * @param url 要打开的链接
 */
openUrl(url: string): Promise<Tab | undefined>
/**
 * 处理点击指定的循环类组件的条目链接
 * @param field 条目 Field 或条目里的子 Field，大部分情况传递 $self 即可
 * @param key 链接对应的字段名，默认为 url
 * @param componentType 默认为 IteratorLayout 循环布局。可选值为 ArrayTable、Table、IteratorLayout、ArrayTabs、ArrayCards、ArrayAccordion 之一
 */
clickArrayFieldUrlItem(field: GeneralField, key?: string, componentType?: 'IteratorLayout' | 'ArrayTable'|'Table' | 'ArrayTabs' | 'ArrayCards' | 'ArrayAccordion'): Promise<Tab | undefined>
/**
 * 生成 html 节点
 * @param html html 字符串
 * @param tagName 标签名称
 * @returns 生成的 html 节点
 */
html(html: string, tagName?: string): React.DOMElement
/**
 * 是否为低代码编辑器环境（是否为开发环境）
 */
isEditorEnv: boolean
/**
 * 是否为低代码预览环境（是否为发布后的环境）
 */
isPreviewEnv: boolean
}`,ni=`{
info(...args: any[]): void
success(...args: any[]): void
warn(...args: any[]): void
error(...args: any[]): void
}`,ri=`declare global {
    declare var $utils: ${oi}
    declare var $logger: ${ni}
    declare var $dayjs: any
}

export {}`,ai=`
import { Form, Field } from '@formily/core'
declare global {
  /*
   * Form Model
   **/
  declare var $form: Form
  /*
   * Form Values
   **/
  declare var $values: any
  /*
   * Field Model
   **/
  declare var $self: Field
  /*
   * create an persistent observable state object
   **/
  declare var $observable: <T>(target: T, deps?: any[]) => T
  /*
   * create a persistent data
   **/
  declare var $memo: <T>(callback: () => T, deps?: any[]) => T
  /*
   * handle side-effect logic
   **/
  declare var $effect: (callback: () => void | (() => void), deps?: any[]) => void
  /*
   * set initial component props to current field
   **/
  declare var $props: (props: any) => void
  /**
   * set formily schema
   */
  function $setFormilySchema(formilySchema: object): void
  /**
   * @formily/core
   */
  declare var $formilyCore: any
  /**
   * @formily/reactive
   */
  declare var $formilyReactive: any
}
`,ii=`
export interface MessageType extends PromiseLike<boolean> {
    (): void;
}
type TypeOpen = (content: any,
/**
 * @descCN 消息通知持续显示的时间，也可以直接使用 onClose。
 * @descEN You can also use onClose directly to determine how long the message notification continues to be displayed.
 */
duration?: number | VoidFunction,
/**
 * @descCN 消息通知关闭时进行调用的回调函数
 * @descEN The callback function called when the message notification is closed
 */
onClose?: VoidFunction) => MessageType;

type MessageMethods = Record<'info' | 'success' | 'error' | 'warning' | 'loading', TypeOpen>;

type ModalFunc = (props: object) => any;
type ModalStaticFunctions = Record<'info' | 'success' | 'error' | 'warning' | 'confirm', ModalFunc>;

declare global {
  /**
   * Ant Design message
   */
  declare var $message: MessageMethods
  /**
   * Ant Design modal
   */
  declare var $modal: ModalStaticFunctions
  /**
   * React
   */
  declare var $React: any
}
`,si=async e=>Promise.all(e.map(async({name:o,path:n})=>({name:o,path:n,library:await fetch(`${Xn()}/${o}/${n}`).then(r=>r.text())}))),li=async()=>be.loader.init().then(async e=>{const o=await si([{name:"@formily/core",path:"dist/formily.core.all.d.ts"}]);o==null||o.forEach(({name:n,library:r})=>{e.languages.typescript.typescriptDefaults.addExtraLib(`declare module '${n}'{ ${r} }`,`file:///node_modules/${n}/index.d.ts`)}),e.languages.typescript.typescriptDefaults.addExtraLib(ai,"file:///node_modules/formily_global.d.ts"),e.languages.typescript.typescriptDefaults.addExtraLib(ti,"file:///node_modules/ga_global_$ga.d.ts"),e.languages.typescript.typescriptDefaults.addExtraLib(ri,"file:///node_modules/ga_global_$utils.d.ts"),e.languages.typescript.typescriptDefaults.addExtraLib(ii,"file:///node_modules/ga_global_component.d.ts")}),pi=({value:e})=>{const o=String(e);return o.length<=26?t.jsx(ke,{children:o}):t.jsx(ke,{children:t.jsxs(Ro,{title:t.jsx("div",{style:{fontSize:12},children:t.jsx("code",{children:t.jsx("pre",{style:{whiteSpace:"pre-wrap",padding:0,margin:0},children:o})})}),children:[o.substring(0,24),"..."]})})},v=Co({components:{Card:lt,FormCollapse:To,Input:it,TypeView:pi,Select:Ao,FormItem:nt,PathSelector:Ba,FieldPropertySetter:Za,ArrayTable:_n,MonacoInput:be}}),ci=["value","initialValue","inputValue","inputValues","modified","initialized","title","description","mounted","unmounted","active","visited","loading","errors","warnings","successes","feedbacks","valid","invalid","pattern","display","disabled","readOnly","readPretty","visible","hidden","editable","validateStatus","validating"],di={modified:"boolean",initialized:"boolean",title:"string",description:"string",mounted:"boolean",unmounted:"boolean",active:"boolean",visited:"boolean",loading:"boolean",errors:"string[]",warnings:"string[]",successes:"string[]",feedbacks:`Array<
  triggerType?: 'onInput' | 'onFocus' | 'onBlur'
  type?: 'error' | 'success' | 'warning'
  code?:
    | 'ValidateError'
    | 'ValidateSuccess'
    | 'ValidateWarning'
    | 'EffectError'
    | 'EffectSuccess'
    | 'EffectWarning'
  messages?: string[]
>
`,valid:"boolean",invalid:"boolean",pattern:"'editable' | 'disabled' | 'readOnly' | 'readPretty'",display:"'visible' | 'hidden' | 'none'",disabled:"boolean",readOnly:"boolean",readPretty:"boolean",visible:"boolean",hidden:"boolean",editable:"boolean",validateStatus:"'error' | 'warning' | 'success' | 'validating'",validating:"boolean"},gt=e=>{const[o,n]=b.useState(!1),[r,a]=b.useState(!1),p=V("reactions-setter"),l=b.useMemo(()=>rt({values:Ee(e.value)}),[o,e.value]),d=b.useMemo(()=>To.createFormCollapse(["run","deps"]),[o]),s=()=>n(!0),i=()=>n(!1);return b.useEffect(()=>{o?er(()=>{li().then(()=>{a(!0)})},{timeout:400}):a(!1)},[o]),t.jsxs(t.Fragment,{children:[t.jsx(H,{block:!0,onClick:s,children:t.jsx(k,{token:"SettingComponents.ReactionsSetter.configureReactions"})}),t.jsx(st,{title:I.getDesignerMessage("SettingComponents.ReactionsSetter.configureReactions"),width:"90%",centered:!0,bodyStyle:{padding:10},transitionName:"",maskTransitionName:"",open:o,onCancel:i,destroyOnClose:!0,onOk:()=>{l.submit(c=>{var m;(m=e.onChange)==null||m.call(e,c)}),i()},children:t.jsx("div",{className:p,children:r&&t.jsx(at,{form:l,children:t.jsx(v,{children:t.jsxs(v.Void,{"x-component":"FormCollapse","x-component-props":{formCollapse:d,defaultActiveKey:["run","deps"],style:{marginBottom:10}},children:[t.jsx(v.Void,{"x-component":"FormCollapse.CollapsePanel","x-component-props":{key:"run",header:I.getDesignerMessage("SettingComponents.ReactionsSetter.actionReactions"),className:"reaction-runner"},children:t.jsx(v.String,{name:"fulfill.run","x-component":"MonacoInput","x-component-props":{width:"100%",height:400,language:"typescript",helpCode:qa,options:{minimap:{enabled:!1}}},"x-reactions":c=>{const m=c.query("dependencies").value();Array.isArray(m)&&(c.componentProps.extraLib=`
                          declare var $deps : {
                            ${m.map(({name:u,type:g})=>u?`${u}?:${g||"any"},`:"")}
                          }
                          `)}})}),t.jsx(v.Void,{"x-component":"FormCollapse.CollapsePanel","x-component-props":{key:"deps",header:I.getDesignerMessage("SettingComponents.ReactionsSetter.relationsFields")},children:t.jsxs(v.Array,{name:"dependencies",default:[{}],"x-component":"ArrayTable",children:[t.jsxs(v.Object,{children:[t.jsx(v.Void,{"x-component":"ArrayTable.Column","x-component-props":{title:I.getDesignerMessage("SettingComponents.ReactionsSetter.sourceField"),width:240},children:t.jsx(v.String,{name:"source","x-decorator":"FormItem","x-component":"PathSelector","x-component-props":{placeholder:I.getDesignerMessage("SettingComponents.ReactionsSetter.pleaseSelect")}})}),t.jsx(v.Void,{"x-component":"ArrayTable.Column","x-component-props":{title:I.getDesignerMessage("SettingComponents.ReactionsSetter.sourceProperty"),width:200},children:t.jsx(v.String,{name:"property",default:"value","x-decorator":"FormItem","x-component":"Select","x-component-props":{showSearch:!0},enum:ci})}),t.jsx(v.Void,{"x-component":"ArrayTable.Column","x-component-props":{title:I.getDesignerMessage("SettingComponents.ReactionsSetter.variableName"),width:200},children:t.jsx(v.String,{name:"name","x-decorator":"FormItem","x-validator":{pattern:/^[$_a-zA-Z]+[$_a-zA-Z0-9]*$/,message:I.getDesignerMessage("SettingComponents.ReactionsSetter.variableNameValidateMessage")},"x-component":"Input","x-component-props":{addonBefore:"$deps.",placeholder:I.getDesignerMessage("SettingComponents.ReactionsSetter.pleaseInput")},"x-reactions":c=>{Te(c)||c.query(".source").take(m=>{var u,g;Te(m)||m.value&&!c.value&&!c.modified&&(c.value=((g=(u=m.inputValues[1])==null?void 0:u.props)==null?void 0:g.name)||`v_${ct()}`)})}})}),t.jsx(v.Void,{"x-component":"ArrayTable.Column","x-component-props":{title:I.getDesignerMessage("SettingComponents.ReactionsSetter.variableType"),ellipsis:{showTitle:!1},width:200,align:"center"},children:t.jsx(v.String,{name:"type",default:"any","x-decorator":"FormItem","x-component":"TypeView","x-reactions":c=>{if(Te(c))return;const m=c.query(".property").get("inputValues");m&&(m[0]=m[0]||"value",c.query(".source").take(u=>{var g,C;Te(u)||u.value&&(m[0]==="value"||m[0]==="initialValue"||m[0]==="inputValue"?c.value=((C=(g=u.inputValues[1])==null?void 0:g.props)==null?void 0:C.type)||"any":m[0]==="inputValues"?c.value="any[]":m[0]?c.value=di[m[0]]:c.value="any")}))}})}),t.jsx(v.Void,{"x-component":"ArrayTable.Column","x-component-props":{title:I.getDesignerMessage("SettingComponents.ReactionsSetter.operations"),align:"center",width:80},children:t.jsx(v.Markup,{type:"void","x-component":"ArrayTable.Remove"})})]}),t.jsx(v.Void,{title:I.getDesignerMessage("SettingComponents.ReactionsSetter.addRelationField"),"x-component":"ArrayTable.Addition","x-component-props":{style:{marginTop:8}}})]})}),t.jsx(v.Void,{"x-component":"FormCollapse.CollapsePanel","x-component-props":{header:I.getDesignerMessage("SettingComponents.ReactionsSetter.propertyReactions"),key:"state",className:"reaction-state"},children:t.jsx(v.Markup,{name:"fulfill.state","x-component":"FieldPropertySetter"})})]})})})})})]})},mi={type:"array",items:{type:"object","x-decorator":"ArrayItems.Item","x-decorator-props":{style:{alignItems:"center",borderRadius:3,paddingTop:6,paddingBottom:6}},properties:{sortable:{type:"void","x-component":"ArrayItems.SortHandle","x-component-props":{style:{marginRight:10}}},drawer:{type:"void","x-component":"DrawerSetter",properties:{triggerType:{type:"string",enum:["onInput","onFocus","onBlur"],"x-decorator":"FormItem","x-component":"Select"},validator:{type:"string","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},message:{type:"string","x-decorator":"FormItem","x-component":"Input.TextArea"},format:{type:"string","x-decorator":"FormItem","x-component":"Select","x-component-props":{allowClear:!0}},pattern:{type:"string","x-decorator":"FormItem","x-component":"Input","x-component-props":{prefix:"/",suffix:"/"}},len:{type:"string","x-decorator":"FormItem","x-component":"NumberPicker"},max:{type:"string","x-decorator":"FormItem","x-component":"NumberPicker"},min:{type:"string","x-decorator":"FormItem","x-component":"NumberPicker"},exclusiveMaximum:{type:"string","x-decorator":"FormItem","x-component":"NumberPicker"},exclusiveMinimum:{type:"string","x-decorator":"FormItem","x-component":"NumberPicker"},whitespace:{type:"string","x-decorator":"FormItem","x-component":"Switch"},required:{type:"string","x-decorator":"FormItem","x-component":"Switch"}}},moveDown:{type:"void","x-component":"ArrayItems.MoveDown","x-component-props":{style:{marginLeft:10}}},moveUp:{type:"void","x-component":"ArrayItems.MoveUp","x-component-props":{style:{marginLeft:5}}},remove:{type:"void","x-component":"ArrayItems.Remove","x-component-props":{style:{marginLeft:5}}}}},properties:{addValidatorRules:{type:"void","x-component":"ArrayItems.Addition","x-component-props":{style:{marginBottom:10}}}}},ui=y(e=>{const o=tr();return t.jsxs(Je,{label:o.title,children:[t.jsx(Je.Base,{children:t.jsx(Qr,{value:Array.isArray(e.value)?void 0:e.value,onChange:e.onChange,allowClear:!0,placeholder:I.getDesignerMessage("SettingComponents.ValidatorSetter.pleaseSelect"),options:I.getDesignerMessage("SettingComponents.ValidatorSetter.formats")})}),t.jsx(Je.Extra,{children:t.jsx(or.Provider,{value:new No(mi),children:t.jsx(Fo,{})})})]})}),hi=e=>t.jsx(ko,{checked:e.value==="FormItem",onChange:o=>{var n;(n=e.onChange)==null||n.call(e,o?"FormItem":void 0)}}),xe={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/input-cn",properties:{addonBefore:{type:"string","x-decorator":"FormItem","x-component":"Input"},addonAfter:{type:"string","x-decorator":"FormItem","x-component":"Input"},prefix:{type:"string","x-decorator":"FormItem","x-component":"Input"},suffix:{type:"string","x-decorator":"FormItem","x-component":"Input"},allowClear:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},maxLength:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},placeholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},size:{type:"string",enum:["large","small","middle",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"middle"}}}};xe.TextArea={type:"object",properties:{bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},maxLength:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},placeholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},autoSize:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showCount:{"x-decorator":"FormItem","x-component":"Switch"}}};const gn={type:"object",properties:{content:{type:"string","x-decorator":"FormItem","x-component":"Input.TextArea"},mode:{type:"string","x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"normal"},enum:["h1","h2","h3","p","normal"]}}},Me={type:"object",properties:{labelCol:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},wrapperCol:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},labelWidth:{"x-decorator":"FormItem","x-component":"SizeInput"},wrapperWidth:{"x-decorator":"FormItem","x-component":"SizeInput"},colon:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},feedbackLayout:{type:"string",enum:["loose","terse","popover","none",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"loose"}},size:{type:"string",enum:["large","small","default",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"default"}},layout:{type:"string",enum:["vertical","horizontal","inline",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"horizontal"}},tooltipLayout:{type:"string",enum:["icon","text",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"icon"}},labelAlign:{type:"string",enum:["left","right",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"right"}},wrapperAlign:{type:"string",enum:["left","right",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"left"}},labelWrap:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},wrapperWrap:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},fullness:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},inset:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},shallow:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}}}},ge={type:"void",properties:{"style.width":{type:"string","x-decorator":"FormItem","x-component":"SizeInput"},"style.height":{type:"string","x-decorator":"FormItem","x-component":"SizeInput"},"style.display":{"x-component":"DisplayStyleSetter"},"style.background":{"x-component":"BackgroundStyleSetter"},"style.boxShadow":{"x-component":"BoxShadowStyleSetter"},"style.font":{"x-component":"FontStyleSetter"},"style.margin":{"x-component":"BoxStyleSetter"},"style.padding":{"x-component":"BoxStyleSetter"},"style.borderRadius":{"x-component":"BorderRadiusStyleSetter"},"style.border":{"x-component":"BorderStyleSetter"},"style.opacity":{"x-decorator":"FormItem","x-component":"Slider","x-component-props":{defaultValue:1,min:0,max:1,step:.01}}}},xi={type:"object",properties:{...Me.properties,style:ge}},ft={type:"object",properties:{className:{type:"string","x-component":"TailwindCSSPicker"},tooltip:{type:"string","x-decorator":"FormItem","x-component":"Input"},addonBefore:{type:"string","x-decorator":"FormItem","x-component":"Input"},addonAfter:{type:"string","x-decorator":"FormItem","x-component":"Input"},labelCol:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},wrapperCol:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},labelWidth:{"x-decorator":"FormItem","x-component":"SizeInput"},wrapperWidth:{"x-decorator":"FormItem","x-component":"SizeInput"},colon:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},asterisk:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},gridSpan:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},feedbackLayout:{type:"string",enum:["loose","terse","popover","none",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"loose"}},size:{type:"string",enum:["large","small","default",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"default"}},layout:{type:"string",enum:["vertical","horizontal","inline",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"horizontal"}},tooltipLayout:{type:"string",enum:["icon","text",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"icon"}},labelAlign:{type:"string",enum:["left","right",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"right"}},wrapperAlign:{type:"string",enum:["left","right",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"left"}},labelWrap:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},wrapperWrap:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},fullness:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},inset:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}}}},fn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/select-cn",properties:{mode:{type:"string",enum:["multiple","tags",{value:null}],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:null,optionType:"button"}},allowClear:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},autoClearSearchValue:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},dropdownMatchSelectWidth:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},defaultActiveFirstOption:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},defaultOpen:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},labelInValue:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showArrow:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showSearch:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},virtual:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!0}},filterOption:{type:"boolean","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["BOOLEAN","EXPRESSION"]}},filterSort:{type:"boolean","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},listHeight:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:256}},maxTagCount:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},maxTagPlaceholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},maxTagTextLength:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},notFoundContent:{type:"string","x-decorator":"FormItem","x-component":"Input","x-component-props":{defaultValue:"Not Found"}},placeholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},size:{type:"string",enum:["large","small","middle",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"middle"}}}},yt={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/card-cn",properties:{title:{type:"string","x-decorator":"FormItem","x-component":"Input"},extra:{type:"string","x-decorator":"FormItem","x-component":"Input"},type:{type:"boolean",enum:I.getDesignerMessage("settings.cardTypes"),"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"",optionType:"button"}},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}}}},yn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/cascader-cn",properties:{allowClear:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},changeOnSelect:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},displayRender:{type:"string","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},fieldNames:{type:"string","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},showSearch:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},notFoundContent:{type:"string","x-decorator":"FormItem","x-component":"Input","x-component-props":{defaultValue:"Not Found"}},placeholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},size:{type:"string",enum:["large","small","middle",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"middle"}}}},bn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/checkbox-cn",properties:{autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}},bt={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/radio-cn",properties:{autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}};bt.Group={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/radio-cn",properties:{optionType:{type:"string",enum:["default","button"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"default",optionType:"button"}},buttonStyle:{type:"string",enum:["outline","solid"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"outline",optionType:"button"}}}};const Sn={allowClear:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},disabledTime:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},disabledDate:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},inputReadOnly:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},placeholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},size:{type:"string",enum:["large","small","middle",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"middle"}},format:{type:"string","x-decorator":"FormItem","x-component":"Input","x-component-props":{placeholder:"YYYY-MM-DD"}}},Pe={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/date-picker-cn",properties:{picker:{type:"string",enum:["time","date","month","year","quarter","decade"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"date"}},...Sn,showNow:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showTime:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showToday:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}};Pe.RangePicker={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/date-picker-cn",properties:{picker:{type:"string",enum:["time","date","month","year","decade"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"date"}},...Sn,showTime:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}};const In={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/input-number-cn",properties:{decimalSeparator:{type:"string","x-decorator":"FormItem","x-component":"Input"},precision:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},max:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},min:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},step:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},placeholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},size:{type:"string",enum:["large","small","middle",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"middle"}},formatter:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},parser:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},stringMode:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},keyboard:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}}}},wn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/input-cn",properties:{...xe.properties,checkStrength:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}},Cn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/rate-cn",properties:{allowClear:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},count:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:5}},allowHalf:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},tooltips:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}},Fn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/slider-cn",properties:{allowClear:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},dots:{title:I.getDesignerMessage("settings.sliderDots"),type:"boolean","x-decorator":"FormItem","x-component":"Switch"},range:{title:I.getDesignerMessage("settings.sliderRange"),type:"boolean","x-decorator":"FormItem","x-component":"Switch"},reverse:{title:I.getDesignerMessage("settings.sliderReverse"),type:"boolean","x-decorator":"FormItem","x-component":"Switch"},vertical:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},tooltipVisible:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},tooltipPlacement:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},marks:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},max:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:100}},min:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:0}},step:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:1}}}},St={allowClear:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},clearText:{type:"string","x-decorator":"FormItem","x-component":"Input"},disabledHours:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},disabledMinutes:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},disabledSeconds:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},hideDisabledOptions:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},inputReadOnly:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showNow:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},use12Hours:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},hourStep:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:1}},minuteStep:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:1}},secondStep:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:1}},placeholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},size:{type:"string",enum:["large","small","middle",{value:null}],"x-decorator":"FormItem","x-component":"Select"},format:{type:"string","x-decorator":"FormItem","x-component":"Input","x-component-props":{placeholder:"YYYY-MM-DD"}}},Ne={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/time-picker-cn",properties:St};Ne.RangePicker={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/time-picker-cn",properties:St};const vn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/tree-select-cn",properties:{allowClear:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},autoClearSearchValue:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},labelInValue:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showArrow:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showSearch:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},virtual:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},treeCheckable:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},treeDefaultExpandAll:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},dropdownMatchSelectWidth:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},showCheckedStrategy:{type:"string",enum:["SHOW_ALL","SHOW_PARENT","SHOW_CHILD"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"SHOW_CHILD"}},treeDefaultExpandedKeys:{type:"boolean","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},treeNodeFilterProp:{type:"string","x-decorator":"FormItem","x-component":"Input"},treeNodeLabelProp:{type:"string","x-decorator":"FormItem","x-component":"Input"},filterTreeNode:{type:"boolean","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["BOOLEAN","EXPRESSION"]}},treeDataSimpleMode:{type:"boolean","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["BOOLEAN","EXPRESSION"]}},listHeight:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:256}},placeholder:{type:"string","x-decorator":"FormItem","x-component":"Input"},size:{type:"string",enum:["large","small","middle",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"middle"}}}},Tn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/transfer-cn",properties:{oneWay:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showSearch:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},showSearchAll:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},filterOption:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},operations:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},titles:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}}}},fe={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/upload-cn",properties:{textContent:{type:"string","x-decorator":"FormItem","x-component":"Input"},accept:{type:"string","x-decorator":"FormItem","x-component":"Input"},action:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["TEXT","EXPRESSION"]}},name:{type:"string","x-decorator":"FormItem","x-component":"Input","x-component-props":{defaultValue:"file"}},maxCount:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},method:{enum:["POST","PUT","GET"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"POST",optionType:"button"}},data:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},headers:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},listType:{enum:["text","picture","picture-card"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"text",optionType:"button"}},directory:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},multiple:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},openFileDialogOnClick:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},showUploadList:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},withCredentials:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}};fe.Dragger=fe;const An={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/switch-cn",properties:{autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},size:{type:"string",enum:["large","small","default",""],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"default"}}}},je={type:"object",properties:{minWidth:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:100}},maxWidth:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},minColumns:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:0}},maxColumns:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},breakpoints:{type:"number","x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["EXPRESSION"]}},columnGap:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:10}},rowGap:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:5}},colWrap:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},strictAutoFit:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}}}};je.GridColumn={type:"object",properties:{gridSpan:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:1}}}};const kn={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/space-cn",properties:{align:{type:"string",enum:["start","end","center","baseline"],"x-decorator":"FormItem","x-component":"Select"},direction:{type:"string",enum:["vertical","horizontal"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"horizontal",optionType:"button"}},size:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:8}},split:{type:"string","x-decorator":"FormItem","x-component":"Input"},wrap:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}},Re={type:"object",properties:{animated:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},centered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},size:{type:"string",enum:["large","small","default",{value:null}],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"default"}},type:{type:"string","x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"line",optionType:"button"}}}};Re.TabPane={type:"object",properties:{tab:{type:"string","x-decorator":"FormItem","x-component":"Input"}}};const De={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/collapse-cn",properties:{accordion:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},collapsible:{type:"string",enum:["header","disabled"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"header",optionType:"button"}},ghost:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}}}};De.CollapsePanel={type:"object",properties:{collapsible:{type:"string",enum:["header","disabled"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"header",optionType:"button"}},header:{type:"boolean","x-decorator":"FormItem","x-component":"Input"},extra:{type:"boolean","x-decorator":"FormItem","x-component":"Input"}}};const Se={type:"object",properties:{bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},showHeader:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},sticky:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},size:{type:"string",enum:["large","small","middle"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"small"}},tableLayout:{type:"string",enum:["auto","fixed"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"auto",optionType:"button"}}}},gi={type:"object",properties:{title:{type:"string","x-decorator":"FormItem","x-component":"Input"},align:{type:"string",enum:["left","right","center"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"left",optionType:"button"}},colSpan:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},width:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},fixed:{type:"string",enum:["left","right",!1],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{optionType:"button"}}}},fi={type:"object",properties:{method:{type:"string",enum:["push","unshift"],"x-decorator":"FormItem","x-component":"Radio.Group","x-component-props":{defaultValue:"push",optionType:"button"}},defaultValue:{type:"string","x-decorator":"FormItem","x-component":"ValueInput"}}};Se.Column=gi;Se.Addition=fi;const Pn=yt;Pn.Addition=Se.Addition;const yi={type:"object",properties:{children:{type:"string","x-decorator":"FormItem","x-component":"Input"}}},bi={type:"object",properties:{src:{type:"string","x-decorator":"FormItem","x-component":"Input"},alt:{type:"string","x-decorator":"FormItem","x-component":"Input"},objectFit:{type:"string",enum:["cover","contain","fill"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"cover"}}}},Si={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/qr-code-cn",properties:{content:{type:"string","x-decorator":"FormItem","x-component":"Input",default:"我是二维码的内容"},type:{type:"string",enum:["canvas","svg"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"canvas"}},icon:{type:"string","x-decorator":"FormItem","x-component":"Input"},size:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:160}},iconSize:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:40}},color:{type:"string","x-decorator":"FormItem","x-component":"ColorInput","x-component-props":{defaultValue:"#000"}},bgColor:{type:"string","x-decorator":"FormItem","x-component":"ColorInput","x-component-props":{defaultValue:"transparent"}},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!0}},errorLevel:{type:"string",enum:["L","M","Q","H"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"M"}}}},Ii=Object.keys(Ye).filter(e=>e.charAt(0)>="A"&&e.charAt(0)<="Z"),L={type:"string",enum:Ii,"x-decorator":"FormItem","x-component":"Select","x-component-props":{showSearch:!0,allowClear:!0}},wi={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/button-cn",properties:{children:{type:"string","x-decorator":"FormItem","x-component":"Input",default:"按钮"},type:{type:"string",enum:["primary","dashed","link","text","default"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"default"}},href:{type:"string","x-decorator":"FormItem","x-component":"Input"},danger:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!1}},shape:{type:"string",enum:["default","circle","round"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"default"}},size:{type:"string",enum:["large","middle","small"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"middle"}},target:{type:"string",enum:["_self","_blank","_parent","_top"],"x-decorator":"FormItem","x-component":"Select",default:"_blank"},icon:{...L},iconPosition:{type:"string",enum:["start","end"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"start"}},block:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!1}},autoInsertSpace:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!0}},ghost:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!1}},loading:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!1}},htmlType:{type:"string","x-decorator":"FormItem","x-component":"Input","x-component-props":{defaultValue:"button"}}}},It={icon:{...L},description:{type:"string","x-decorator":"FormItem","x-component":"Input"},tooltip:{type:"string","x-decorator":"FormItem","x-component":"Input"},type:{type:"string",enum:["primary","default"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"default"}},shape:{type:"string",enum:["circle","square"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"circle"}},insetInlineEnd:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},insetBlockEnd:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},badge:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"}},Ci={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/float-button-cn",properties:{...It,href:{type:"string","x-decorator":"FormItem","x-component":"Input"},target:{type:"string",enum:["_self","_blank","_parent","_top"],"x-decorator":"FormItem","x-component":"Select",default:"_blank"}}},Fi={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/float-button-cn",properties:{trigger:{type:"string",enum:["","click","hover"],"x-decorator":"FormItem","x-component":"Select"},...It}},vi={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/float-button-cn",properties:{duration:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:450}},visibilityHeight:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:400}},...It}},Ti={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/divider-cn",properties:{children:{type:"string","x-decorator":"FormItem","x-component":"Input",default:"分割线"},variant:{type:"string",enum:["dashed","dotted","solid"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"solid"}},orientation:{type:"string",enum:["left","right","center"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"center"}},orientationMargin:{type:"string","x-decorator":"FormItem","x-component":"Input"},plain:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!1}},type:{type:"string",enum:["horizontal","vertical"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"horizontal"}}}},Ai={type:"object",properties:{}},ki={type:"object",properties:{"x-link":{"x-component":H,"x-component-props":{block:!0,type:"primary",style:{marginBottom:10},children:"查看低代码区块模版市场",onClick:()=>{$editorContext.$ga.dynamicSchemaBlockTemplateMarket()}}},schema:{type:"object",title:"本地动态 schema","x-decorator":"FormItem","x-component":"JsonEditor"},schemaUrl:{type:"string",title:"远程 schema url","x-decorator":"FormItem","x-component":"Input"},cacheRemoteSchema:{type:"boolean",title:"缓存远程 schema","x-decorator":"FormItem","x-component":"Switch",default:!0},valueType:{type:"string",title:"值类型",enum:[{label:"对象包裹：以当前字段标识把动态区块里的字段包裹一层",value:"object"},{label:"展开：把动态区块里的多个字段平铺展开",value:"unfold"}],"x-decorator":"FormItem","x-component":"Select",default:"object"},reset:{type:"boolean",title:"切换动态 schema 时是否重置表单状态","x-decorator":"FormItem","x-component":"Switch",default:!0}}},Pi={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/drawer-cn",properties:{open:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},title:{type:"string","x-decorator":"FormItem","x-component":"Input"},extra:{type:"string","x-decorator":"FormItem","x-component":"Input"},footer:{type:"string","x-decorator":"FormItem","x-component":"Input"},placement:{type:"string",enum:["top","right","bottom","left"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"right"}},autoFocus:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},mask:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},maskClosable:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},size:{type:"string",enum:["default","large"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"default"}},width:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:378}},height:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:378}},rootStyle:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},styles:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},classNames:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},loading:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},closeIcon:{...L},destroyOnClose:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},keyboard:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},push:{"x-decorator":"FormItem","x-component":"ValueInput","x-component-props":{include:["BOOLEAN","JSON"]},default:{distance:180}},zIndex:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:1e3}},forceRender:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}}}},Oe={arrow:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},autoAdjustOverflow:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},color:{type:"string","x-decorator":"FormItem","x-component":"ColorInput"},defaultOpen:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},open:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},destroyTooltipOnHide:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},fresh:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},mouseEnterDelay:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:.1}},mouseLeaveDelay:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:.1}},overlayClassName:{type:"string","x-decorator":"FormItem","x-component":"TailwindCSSPicker"},overlayStyle:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},overlayInnerStyle:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},placement:{type:"string",enum:["top","left","right","bottom","topLeft","topRight","bottomLeft","bottomRight","leftTop","leftBottom","rightTop","rightBottom"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"top"}},trigger:{type:"string",enum:["hover","focus","click","contextMenu"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{mode:"tags"},default:["hover"]},zIndex:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"}},Ni={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/tooltip-cn",properties:{title:{type:"string","x-decorator":"FormItem","x-component":"Input"},...Oe}},ji={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/modal-cn",properties:{open:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"},title:{type:"string","x-decorator":"FormItem","x-component":"Input"},centered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!1}},closable:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},closeIcon:{...L},footer:{type:"string","x-decorator":"FormItem","x-component":"Input"},keyboard:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},mask:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},maskClosable:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},cancelButtonProps:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},cancelText:{type:"string","x-decorator":"FormItem","x-component":"Input",default:"取消"},okButtonProps:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},okText:{type:"string","x-decorator":"FormItem","x-component":"Input",default:"确定"},okType:{type:"string",enum:["primary","dashed","link","text","default"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"primary"}},width:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:520}},classNames:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},styles:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},wrapClassName:{type:"string","x-decorator":"FormItem","x-component":"TailwindCSSPicker"},confirmLoading:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},loading:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},zIndex:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker","x-component-props":{defaultValue:1e3}},destroyOnClose:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},focusTriggerAfterClose:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},forceRender:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}}}},Ri={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/popconfirm-cn",properties:{icon:{...L,default:"ExclamationCircleFilled"},title:{type:"string","x-decorator":"FormItem","x-component":"Input"},description:{type:"string","x-decorator":"FormItem","x-component":"Input"},okButtonProps:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},okText:{type:"string","x-decorator":"FormItem","x-component":"Input",default:"确定"},okType:{type:"string",enum:["primary","dashed","link","text","default"],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"primary"}},cancelButtonProps:{type:"object","x-decorator":"FormItem","x-component":"JsonEditor"},cancelText:{type:"string","x-decorator":"FormItem","x-component":"Input",default:"取消"},showCancel:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!0}},disabled:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!1}},...Oe}},Di={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/popover-cn",properties:{title:{type:"string","x-decorator":"FormItem","x-component":"Input"},content:{type:"string","x-decorator":"FormItem","x-component":"Input"},...Oe}},Ei={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/spin-cn",properties:{delay:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},fullscreen:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!1}},indicator:{...L},percent:{type:"number","x-decorator":"FormItem","x-component":"NumberPicker"},size:{type:"string",enum:["small","default","large"],"x-decorator":"FormItem","x-component":"Select",default:"small"},spinning:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultChecked:!0}},tip:{type:"string","x-decorator":"FormItem","x-component":"Input"},wrapperClassName:{type:"string","x-decorator":"FormItem","x-component":"TailwindCSSPicker"}}},Vi={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/tag-cn",properties:{children:{type:"string","x-decorator":"FormItem","x-component":"Input"},color:{type:"string","x-decorator":"FormItem","x-component":"ColorInput"},icon:{...L},closeIcon:{...L},bordered:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!0}}}},$i={type:"object","x-usage-href":"https://ant-design.antgroup.com/components/tag-cn",properties:{children:{type:"string","x-decorator":"FormItem","x-component":"Input"},checked:{type:"boolean","x-decorator":"FormItem","x-component":"Switch","x-component-props":{defaultValue:!1}}}},Mi={type:"object","x-usage-href":"https://developer.mozilla.org/zh-CN/docs/Web/HTML/Element/iframe",properties:{}},F=Object.freeze(Object.defineProperty({__proto__:null,ArrayCards:Pn,ArrayTable:Se,Button:wi,CSSStyle:ge,Card:yt,Cascader:yn,CheckableTag:$i,Checkbox:bn,CommonTimePickerAPI:St,CommonTooltipAPI:Oe,DatePicker:Pe,Div:yi,Divider:Ti,Drawer:Pi,DynamicSchemaBlock:ki,FloatButton:Ci,FloatButtonBackTop:vi,FloatButtonGroup:Fi,Form:xi,FormCollapse:De,FormGrid:je,FormItem:ft,FormLayout:Me,FormTab:Re,Iframe:Mi,Img:bi,Input:xe,IteratorLayout:Ai,Modal:ji,NumberPicker:In,Password:wn,Popconfirm:Ri,Popover:Di,QRCode:Si,Radio:bt,Rate:Cn,Select:fn,Slider:Fn,Space:kn,Spin:Ei,Switch:An,Tag:Vi,Text:gn,TimePicker:Ne,Tooltip:Ni,Transfer:Tn,TreeSelect:vn,Upload:fe},Symbol.toStringTag,{value:"Module"})),wt=(e,o)=>{const n=e==null?void 0:e["x-usage-href"],r=n?n.split("/").pop().replace("-cn",""):"",a=n?{"x-link":{"x-component":H,"x-component-props":{type:"link",href:n,target:"_blank",children:`${r} 使用文档`}}}:{};return{"component-group":e?{type:"void","x-component":"CollapseItem","x-reactions":{fulfill:{state:{visible:'{{!!$form.values["x-component"]}}'}}},properties:{...a,"x-component-props":{...e,properties:{className:{type:"string","x-component":"TailwindCSSPicker"},...e.properties}}}}:{},"decorator-group":o?{type:"void","x-component":"CollapseItem","x-component-props":{defaultExpand:!1},"x-reactions":{fulfill:{state:{visible:'{{!!$form.values["x-decorator"]}}'}}},properties:{"x-decorator-props":o}}:{},"component-style-group":{type:"void","x-component":"CollapseItem","x-component-props":{defaultExpand:!1},"x-reactions":{fulfill:{state:{visible:'{{!!$form.values["x-component"]}}'}}},properties:{"x-component-props.style":ge}},"decorator-style-group":{type:"void","x-component":"CollapseItem","x-component-props":{defaultExpand:!1},"x-reactions":{fulfill:{state:{visible:'{{!!$form.values["x-decorator"]}}'}}},properties:{"x-decorator-props.style":ge}}}},f=(e,o=ft)=>({type:"object",properties:{"field-group":{type:"void","x-component":"CollapseItem",properties:{name:{type:"string","x-decorator":"FormItem","x-component":"Input"},title:{type:"string","x-decorator":"FormItem","x-component":"Input"},description:{type:"string","x-decorator":"FormItem","x-component":"Input.TextArea"},"x-display":{type:"string",enum:["visible","hidden","none",""],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"visible"}},"x-pattern":{type:"string",enum:["editable","disabled","readOnly","readPretty",""],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"editable"}},default:{"x-decorator":"FormItem","x-component":"ValueInput"},enum:{"x-decorator":"FormItem","x-component":za},"x-reactions":{"x-decorator":"FormItem","x-component":gt},"x-validator":{type:"array","x-component":ui},required:{type:"boolean","x-decorator":"FormItem","x-component":"Switch"}}},...wt(e,o)}}),w=(e,o=ft)=>({type:"object",properties:{"field-group":{type:"void","x-component":"CollapseItem",properties:{name:{type:"string","x-decorator":"FormItem","x-component":"Input"},title:{type:"string","x-decorator":"FormItem","x-component":"Input","x-reactions":{fulfill:{state:{hidden:'{{$form.values["x-decorator"] !== "FormItem"}}'}}}},description:{type:"string","x-decorator":"FormItem","x-component":"Input.TextArea","x-reactions":{fulfill:{state:{hidden:'{{$form.values["x-decorator"] !== "FormItem"}}'}}}},"x-display":{type:"string",enum:["visible","hidden","none",""],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"visible"}},"x-pattern":{type:"string",enum:["editable","disabled","readOnly","readPretty",""],"x-decorator":"FormItem","x-component":"Select","x-component-props":{defaultValue:"editable"}},"x-reactions":{"x-decorator":"FormItem","x-component":gt},"x-decorator":{type:"string","x-decorator":"FormItem","x-component":hi}}},...wt(e,o)}}),Ct=y(e=>{const o=V("designable-form"),n=b.useMemo(()=>rt({designable:!0}),[]);return t.jsx(at,{...e,style:{...e.style},className:o,form:n,children:e.children})});Ct.Behavior=h({name:"Form",selector:e=>e.componentName==="Form",designerProps(e){return{draggable:!e.isRoot,cloneable:!e.isRoot,deletable:!e.isRoot,droppable:!0,propsSchema:{type:"object",properties:{"x-reactions":{"x-component":gt,"x-decorator":"FormItem"},...Me.properties,style:ge}},defaultProps:{labelCol:6,wrapperCol:12}}},designerLocales:Xo});Ct.Resource=x("Inputs",{title:{"zh-CN":"表单","en-US":"Form"},icon:"FormLayoutSource",elements:[{componentName:"Field",props:{type:"object","x-component":"Form"}}]});const Ft=it;Ft.Behavior=h({name:"Input",extends:["Field"],selector:e=>e.props["x-component"]==="Input",designerProps:{propsSchema:f(xe)},designerLocales:mt},{name:"Input.TextArea",extends:["Field"],selector:e=>e.props["x-component"]==="Input.TextArea",designerProps:{propsSchema:f(xe.TextArea)},designerLocales:Mo});Ft.Resource=x("Inputs",{icon:"InputSource",elements:[{componentName:"Field",props:{type:"string",title:"Input","x-decorator":"FormItem","x-component":"Input"}}]},{icon:"TextAreaSource",elements:[{componentName:"Field",props:{type:"string",title:"TextArea","x-decorator":"FormItem","x-component":"Input.TextArea"}}]});const vt=Ao;vt.Behavior=h({name:"Select",extends:["Field"],selector:e=>e.props["x-component"]==="Select",designerProps:{propsSchema:f(fn)},designerLocales:$o});vt.Resource=x("Inputs",{icon:"SelectSource",elements:[{componentName:"Field",props:{title:"Select","x-decorator":"FormItem","x-component":"Select"}}]});const Tt=Ar;Tt.Behavior=h({name:"TreeSelect",extends:["Field"],selector:e=>e.props["x-component"]==="TreeSelect",designerProps:{propsSchema:f(vn)},designerLocales:Oo});Tt.Resource=x("Inputs",{icon:"TreeSelectSource",elements:[{componentName:"Field",props:{title:"TreeSelect","x-decorator":"FormItem","x-component":"TreeSelect"}}]});const At=kr;At.Behavior=h({name:"Cascader",extends:["Field"],selector:e=>e.props["x-component"]==="Cascader",designerProps:{propsSchema:f(yn)},designerLocales:Lo});At.Resource=x("Inputs",{icon:"CascaderSource",elements:[{componentName:"Field",props:{title:"Cascader","x-decorator":"FormItem","x-component":"Cascader"}}]});const kt=nr;kt.Behavior=h({name:"Radio.Group",extends:["Field"],selector:e=>e.props["x-component"]==="Radio.Group",designerProps:{propsSchema:f(bt.Group)},designerLocales:zo});kt.Resource=x("Inputs",{icon:"RadioGroupSource",elements:[{componentName:"Field",props:{type:"string | number",title:"Radio Group","x-decorator":"FormItem","x-component":"Radio.Group",enum:[{label:"选项1",value:1},{label:"选项2",value:2}]}}]});const Pt=Pr;Pt.Behavior=h({name:"Checkbox.Group",extends:["Field"],selector:e=>e.props["x-component"]==="Checkbox.Group",designerProps:{propsSchema:f(bn.Group)},designerLocales:Uo});Pt.Resource=x("Inputs",{icon:"CheckboxGroupSource",elements:[{componentName:"Field",props:{type:"Array<string | number>",title:"Checkbox Group","x-decorator":"FormItem","x-component":"Checkbox.Group",enum:[{label:"选项1",value:1},{label:"选项2",value:2}]}}]});const Nt=rr;Nt.Behavior=h({name:"Slider",extends:["Field"],selector:e=>e.props["x-component"]==="Slider",designerProps:{propsSchema:f(Fn)},designerLocales:Bo});Nt.Resource=x("Inputs",{icon:"SliderSource",elements:[{componentName:"Field",props:{type:"number",title:"Slider","x-decorator":"FormItem","x-component":"Slider"}}]});const jt=Nr;jt.Behavior=h({name:"Rate",extends:["Field"],selector:e=>e.props["x-component"]==="Rate",designerProps:{propsSchema:f(Cn)},designerLocales:Wo});jt.Resource=x("Inputs",{icon:"RateSource",elements:[{componentName:"Field",props:{type:"number",title:"Rate","x-decorator":"FormItem","x-component":"Rate"}}]});const Rt=ar;Rt.Behavior=h({name:"NumberPicker",extends:["Field"],selector:e=>e.props["x-component"]==="NumberPicker",designerProps:{propsSchema:f(In)},designerLocales:Jo});Rt.Resource=x("Inputs",{icon:"NumberPickerSource",elements:[{componentName:"Field",props:{type:"number",title:"NumberPicker","x-decorator":"FormItem","x-component":"NumberPicker"}}]});const Dt=jr;Dt.Behavior=h({name:"Transfer",extends:["Field"],selector:e=>e.props["x-component"]==="Transfer",designerProps:{propsSchema:f(Tn)},designerLocales:qo});Dt.Resource=x("Inputs",{icon:"TransferSource",elements:[{componentName:"Field",props:{title:"Transfer","x-decorator":"FormItem","x-component":"Transfer"}}]});const Et=Rr;Et.Behavior=h({name:"Password",extends:["Field"],selector:e=>e.props["x-component"]==="Password",designerProps:{propsSchema:f(wn)},designerLocales:Qo});Et.Resource=x("Inputs",{icon:"PasswordSource",elements:[{componentName:"Field",props:{title:"Password","x-decorator":"FormItem","x-component":"Password"}}]});const Vt=ir;Vt.Behavior=h({name:"DatePicker",extends:["Field"],selector:e=>e.props["x-component"]==="DatePicker",designerProps:{propsSchema:f(Pe)},designerLocales:Ve},{name:"DatePicker.RangePicker",extends:["Field"],selector:e=>e.props["x-component"]==="DatePicker.RangePicker",designerProps:{propsSchema:f(Pe.RangePicker)},designerLocales:Ho});Vt.Resource=x("Inputs",{icon:"DatePickerSource",elements:[{componentName:"Field",props:{type:"string",title:"DatePicker","x-decorator":"FormItem","x-component":"DatePicker"}}]},{icon:"DateRangePickerSource",elements:[{componentName:"Field",props:{type:"string[]",title:"DateRangePicker","x-decorator":"FormItem","x-component":"DatePicker.RangePicker"}}]});const $t=sr;$t.Behavior=h({name:"TimePicker",extends:["Field"],selector:e=>e.props["x-component"]==="TimePicker",designerProps:{propsSchema:f(Ne)},designerLocales:ut},{name:"TimePicker.RangePicker",extends:["Field"],selector:e=>e.props["x-component"]==="TimePicker.RangePicker",designerProps:{propsSchema:f(Ne.RangePicker)},designerLocales:Go});$t.Resource=x("Inputs",{icon:"TimePickerSource",elements:[{componentName:"Field",props:{type:"string",title:"TimePicker","x-decorator":"FormItem","x-component":"TimePicker"}}]},{icon:"TimeRangePickerSource",elements:[{componentName:"Field",props:{type:"string[]",title:"TimeRangePicker","x-decorator":"FormItem","x-component":"TimePicker.RangePicker"}}]});const Mt=Dr;Mt.Behavior=h({name:"Upload",extends:["Field"],selector:e=>e.props["x-component"]==="Upload",designerProps:{propsSchema:f(fe)},designerLocales:ht},{name:"Upload.Dragger",extends:["Field"],selector:e=>e.props["x-component"]==="Upload.Dragger",designerProps:{propsSchema:f(fe.Dragger)},designerLocales:Ko});Mt.Resource=x("Inputs",{icon:"UploadSource",elements:[{componentName:"Field",props:{type:"Array<object>",title:"Upload","x-decorator":"FormItem","x-component":"Upload","x-component-props":{textContent:"Upload"}}}]},{icon:"UploadDraggerSource",elements:[{componentName:"Field",props:{type:"Array<object>",title:"Drag Upload","x-decorator":"FormItem","x-component":"Upload.Dragger","x-component-props":{textContent:"Click or drag file to this area to upload"}}}]});const Ot=ko;Ot.Behavior=h({name:"Switch",extends:["Field"],selector:e=>e.props["x-component"]==="Switch",designerProps:{propsSchema:f(An)},designerLocales:Zo});Ot.Resource=x("Inputs",{icon:"SwitchSource",elements:[{componentName:"Field",props:{type:"boolean",title:"Switch","x-decorator":"FormItem","x-component":"Switch"}}]});const Lt=y(({value:e,mode:o,content:n,...r})=>{const a=o==="normal"||!o?"div":o;return tt.createElement(a,{...r,className:B(r.className,"dn-text"),"data-content-editable":"x-component-props.content",dangerouslySetInnerHTML:{__html:e||n}})});Lt.Behavior=h({name:"Text",extends:["Field"],selector:e=>e.props["x-component"]==="Text",designerProps:{propsSchema:f(gn)},designerLocales:en});Lt.Resource=x("Displays",{icon:"TextSource",elements:[{componentName:"Field",props:{type:"string","x-component":"Text"}}]});const zt=e=>t.jsx(lt,{...e,title:t.jsx("span",{"data-content-editable":"x-component-props.title",children:e.title}),children:e.children});zt.Behavior=h({name:"Card",extends:["Field"],selector:e=>e.props["x-component"]==="Card",designerProps:{droppable:!0,propsSchema:w(yt)},designerLocales:xt});zt.Resource=x("Layouts",{icon:"CardSource",elements:[{componentName:"Field",props:{type:"void","x-component":"Card","x-component-props":{title:"Title"}}}]});const Ut=dt(lr);Ut.Behavior=h({name:"Space",extends:["Field"],selector:e=>e.props["x-component"]==="Space",designerProps:{droppable:!0,inlineChildrenLayout:!0,propsSchema:w(kn)},designerLocales:ln});Ut.Resource=x("Layouts",{icon:"SpaceSource",elements:[{componentName:"Field",props:{type:"void","x-component":"Space"}}]});const Bt=Do;Bt.Behavior=h({name:"Object",extends:["Field"],selector:e=>e.props.type==="object"&&!e.props["x-component"],designerProps:{droppable:!0,propsSchema:f()},designerLocales:Yo});Bt.Resource=x("Inputs",{icon:"ObjectSource",elements:[{componentName:"Field",props:{type:"object"}}]});const G=e=>{var o;return t.jsx(mo,{children:(o=e.actions)==null?void 0:o.map((n,r)=>b.createElement(mo.Action,{...n,key:r}))})},W=(e,o,n)=>{var a;if(o==="*")return!0;const r=(a=e==null?void 0:e.props)==null?void 0:a["x-component"];return typeof o=="function"?o(r||"",e,n):Array.isArray(o)?o.includes(r):r===o},Oi=(e,o,n)=>{var a;if(o==="*")return!0;const r=(a=e==null?void 0:e.props)==null?void 0:a["x-component"];return r?typeof o=="function"?o(r||"",e,n):Array.isArray(o)?o.includes(r):r.indexOf(`${o}.`)>-1:!1},z=(e,o)=>(o==null?void 0:o.length)===0?[]:(o==null?void 0:o.length)===1&&W(e,o[0])?[e]:W(e,o[0])?e.children.reduce((n,r)=>n.concat(z(r,o.slice(1))),[]):[],N=(e,o)=>{if((o==null?void 0:o.length)!==0){if((o==null?void 0:o.length)===1&&W(e,o[0]))return e;if(W(e,o[0]))for(let n=0;n<e.children.length;n++){const r=N(e.children[n],o.slice(1));if(r)return r}}},et=(e,o)=>!!N(e,o),Li=(e,o)=>({[e.props.nodeIdAttrName]:o}),Nn=e=>o=>{const n=o.children.find(r=>r.props.type===e);if(n)return n;{const r=new S({componentName:"Field",props:{type:e}});return o.prepend(r),r}},ye=(e,o)=>wo(n=>n.subscribeTo(pr,r=>{const{source:a,target:p}=r.data;if(!Array.isArray(p)&&Array.isArray(a)&&W(p,l=>l===e&&a.every(d=>!Oi(d,e)))&&p.children.length===0)return p.setChildren(...o(a)),!1})),jn=e=>h({name:e,extends:["Field"],selector:o=>o.props["x-component"]===e,designerProps:{droppable:!0,propsSchema:f(F[e])},designerLocales:T[e]},{name:`${e}.Addition`,extends:["Field"],selector:o=>o.props["x-component"]===`${e}.Addition`,designerProps:{allowDrop(o){return o.props["x-component"]===e},propsSchema:w(F[e].Addition)},designerLocales:tn},{name:`${e}.Remove`,extends:["Field"],selector:o=>o.props["x-component"]===`${e}.Remove`,designerProps:{allowDrop(o){return o.props["x-component"]===e},propsSchema:w()},designerLocales:on},{name:`${e}.Index`,extends:["Field"],selector:o=>o.props["x-component"]===`${e}.Index`,designerProps:{allowDrop(o){return o.props["x-component"]===e},propsSchema:w()},designerLocales:an},{name:`${e}.MoveUp`,extends:["Field"],selector:o=>o.props["x-component"]===`${e}.MoveUp`,designerProps:{allowDrop(o){return o.props["x-component"]===e},propsSchema:w()},designerLocales:nn},{name:`${e}.MoveDown`,extends:["Field"],selector:o=>o.props["x-component"]===`${e}.MoveDown`,designerProps:{allowDrop(o){return o.props["x-component"]==="ArrayCards"},propsSchema:w()},designerLocales:rn}),Q=Nn("object"),zi=e=>e==="ArrayCards.Remove"||e==="ArrayCards.MoveDown"||e==="ArrayCards.MoveUp",Le=y(e=>{const o=$(),n=M(),r=ye("ArrayCards",p=>{const l=new S({componentName:o.componentName,props:{type:"void","x-component":"ArrayCards.Index"}}),d=new S({componentName:o.componentName,props:{type:"void",title:"Addition","x-component":"ArrayCards.Addition"}}),s=new S({componentName:o.componentName,props:{type:"void",title:"Addition","x-component":"ArrayCards.Remove"}}),i=new S({componentName:o.componentName,props:{type:"void",title:"Addition","x-component":"ArrayCards.MoveDown"}}),c=new S({componentName:o.componentName,props:{type:"void",title:"Addition","x-component":"ArrayCards.MoveUp"}});return[new S({componentName:o.componentName,props:{type:"object"},children:[l,...p,s,i,c]}),d]}),a=()=>{if(o.children.length===0)return t.jsx(A,{});const p=z(o,["ArrayCards","ArrayCards.Addition"]),l=z(o,["ArrayCards","*","ArrayCards.Index"]),d=z(o,["ArrayCards","*",zi]),s=z(o,["ArrayCards","*",i=>i.indexOf("ArrayCards.")===-1]);return t.jsxs(me,{disabled:!0,children:[t.jsx(me.Item,{index:0,record:()=>null,children:t.jsx(lt,{...e,title:t.jsxs(b.Fragment,{children:[l.map((i,c)=>t.jsx(D,{node:i},c)),t.jsx("span",{"data-content-editable":"x-component-props.title",children:e.title})]}),className:B("ant-formily-array-cards-item",e.className),extra:t.jsxs(b.Fragment,{children:[d.map(i=>t.jsx(D,{node:i},i.id)),e.extra]}),children:t.jsx("div",{...Li(r,Q(o).id),children:s.length?s.map(i=>t.jsx(D,{node:i},i.id)):t.jsx(A,{hasChildren:!1})})})}),p.map(i=>t.jsx(D,{node:i},i.id))]})};return t.jsxs("div",{...n,className:"dn-array-cards",children:[a(),t.jsx(G,{actions:[{title:o.getMessage("addIndex"),icon:"AddIndex",onClick:()=>{if(et(o,["ArrayCards","*","ArrayCards.Index"]))return;const p=new S({componentName:o.componentName,props:{type:"void","x-component":"ArrayCards.Index"}});Q(o).append(p)}},{title:o.getMessage("addOperation"),icon:"AddOperation",onClick:()=>{if(!N(o,["ArrayCards","ArrayCards.Addition"])){const i=new S({componentName:o.componentName,props:{type:"void",title:"Addition","x-component":"ArrayCards.Addition"}});Q(o).insertAfter(i)}const l=N(o,["ArrayCards","*","ArrayCards.Remove"]),d=N(o,["ArrayCards","*","ArrayCards.MoveDown"]),s=N(o,["ArrayCards","*","ArrayCards.MoveUp"]);l||Q(o).append(new S({componentName:o.componentName,props:{type:"void","x-component":"ArrayCards.Remove"}})),d||Q(o).append(new S({componentName:o.componentName,props:{type:"void","x-component":"ArrayCards.MoveDown"}})),s||Q(o).append(new S({componentName:o.componentName,props:{type:"void","x-component":"ArrayCards.MoveUp"}}))}}]})]})});me.mixin(Le);Le.Behavior=jn("ArrayCards");Le.Resource=x("Arrays",{icon:"ArrayCardsSource",elements:[{componentName:"Field",props:{type:"array","x-decorator":"FormItem","x-component":"ArrayCards","x-component-props":{title:"Title"}}}]});const ue=Nn("object"),Ui=e=>{var o;return t.jsx("th",{...e,"data-designer-node-id":(o=e.className.match(/data-id\:([^\s]+)/))==null?void 0:o[1],children:e.children})},Bi=e=>{var o;return t.jsx("td",{...e,"data-designer-node-id":(o=e.className.match(/data-id\:([^\s]+)/))==null?void 0:o[1],children:e.children})},ze=y(e=>{const o=$(),n=M();ye("ArrayTable",d=>{const s=new S({componentName:"Field",props:{type:"void","x-component":"ArrayTable.Column","x-component-props":{title:"Title"}},children:[{componentName:"Field",props:{type:"void","x-component":"ArrayTable.SortHandle"}}]}),i=new S({componentName:"Field",props:{type:"void","x-component":"ArrayTable.Column","x-component-props":{title:"Title"}},children:[{componentName:"Field",props:{type:"void","x-component":"ArrayTable.Index"}}]}),c=new S({componentName:"Field",props:{type:"void","x-component":"ArrayTable.Column","x-component-props":{title:"Title"}},children:d.map(C=>(C.props.title=void 0,C))}),m=new S({componentName:"Field",props:{type:"void","x-component":"ArrayTable.Column","x-component-props":{title:"Title"}},children:[{componentName:"Field",props:{type:"void","x-component":"ArrayTable.Remove"}},{componentName:"Field",props:{type:"void","x-component":"ArrayTable.MoveDown"}},{componentName:"Field",props:{type:"void","x-component":"ArrayTable.MoveUp"}}]}),u=new S({componentName:"Field",props:{type:"object"},children:[s,i,c,m]}),g=new S({componentName:"Field",props:{type:"void",title:"Addition","x-component":"ArrayTable.Addition"}});return[u,g]});const r=z(o,["ArrayTable","*","ArrayTable.Column"]),a=z(o,["ArrayTable","ArrayTable.Addition"]),p=()=>o.id,l=()=>o.children.length===0?t.jsx(A,{}):t.jsxs(me,{disabled:!0,children:[t.jsxs(Qe,{size:"small",bordered:!0,...e,scroll:{x:"100%"},className:B("ant-formily-array-table",e.className),style:{marginBottom:10,...e.style},rowKey:p,dataSource:[{id:"1"}],pagination:!1,components:{header:{cell:Ui},body:{cell:Bi}},children:[r.map(d=>{const s=d.children.map(c=>t.jsx(D,{node:c},c.id)),i=d.props["x-component-props"];return b.createElement(Qe.Column,{...i,title:t.jsx("div",{"data-content-editable":"x-component-props.title",children:i.title}),dataIndex:d.id,className:`data-id:${d.id}`,key:d.id,render:(c,m,u)=>t.jsx(me.Item,{index:u,record:()=>null,children:s.length>0?s:"Droppable"},u)})}),r.length===0&&t.jsx(Qe.Column,{render:()=>t.jsx(A,{})})]}),a.map(d=>t.jsx(D,{node:d},d.id))]});return ye("ArrayTable.Column",d=>d.map(s=>(s.props.title=void 0,s))),t.jsxs("div",{...n,className:"dn-array-table",children:[l(),t.jsx(G,{actions:[{title:o.getMessage("addSortHandle"),icon:"AddSort",onClick:()=>{if(et(o,["ArrayTable","*","ArrayTable.Column","ArrayTable.SortHandle"]))return;const d=new S({componentName:"Field",props:{type:"void","x-component":"ArrayTable.Column","x-component-props":{title:"Title"}},children:[{componentName:"Field",props:{type:"void","x-component":"ArrayTable.SortHandle"}}]});ue(o).prepend(d)}},{title:o.getMessage("addIndex"),icon:"AddIndex",onClick:()=>{if(et(o,["ArrayTable","*","ArrayTable.Column","ArrayTable.Index"]))return;const d=new S({componentName:"Field",props:{type:"void","x-component":"ArrayTable.Column","x-component-props":{title:"Title"}},children:[{componentName:"Field",props:{type:"void","x-component":"ArrayTable.Index"}}]}),s=N(o,["ArrayTable","*","ArrayTable.Column","ArrayTable.SortHandle"]);s?s.parent.insertAfter(d):ue(o).prepend(d)}},{title:o.getMessage("addColumn"),icon:"AddColumn",onClick:()=>{const d=N(o,["ArrayTable","*","ArrayTable.Column",i=>i==="ArrayTable.Remove"||i==="ArrayTable.MoveDown"||i==="ArrayTable.MoveUp"]),s=new S({componentName:"Field",props:{type:"void","x-component":"ArrayTable.Column","x-component-props":{title:"Title"}}});d?d.parent.insertBefore(s):ue(o).append(s)}},{title:o.getMessage("addOperation"),icon:"AddOperation",onClick:()=>{const d=N(o,["ArrayTable","*","ArrayTable.Column",i=>i==="ArrayTable.Remove"||i==="ArrayTable.MoveDown"||i==="ArrayTable.MoveUp"]),s=N(o,["ArrayTable","ArrayTable.Addition"]);if(!d){const i=new S({componentName:"Field",props:{type:"void","x-component":"ArrayTable.Column","x-component-props":{title:"Title"}},children:[{componentName:"Field",props:{type:"void","x-component":"ArrayTable.Remove"}},{componentName:"Field",props:{type:"void","x-component":"ArrayTable.MoveDown"}},{componentName:"Field",props:{type:"void","x-component":"ArrayTable.MoveUp"}}]});ue(o).append(i)}if(!s){const i=new S({componentName:"Field",props:{type:"void",title:"Addition","x-component":"ArrayTable.Addition"}});ue(o).insertAfter(i)}}}]})]})});me.mixin(ze);ze.Behavior=h(jn("ArrayTable"),{name:"ArrayTable.Column",extends:["Field"],selector:e=>e.props["x-component"]==="ArrayTable.Column",designerProps:{droppable:!0,allowDrop:e=>{var o,n;return e.props.type==="object"&&((n=(o=e.parent)==null?void 0:o.props)==null?void 0:n["x-component"])==="ArrayTable"},propsSchema:w(Se.Column)},designerLocales:sn});ze.Resource=x("Arrays",{icon:"ArrayTableSource",elements:[{componentName:"Field",props:{type:"array","x-decorator":"FormItem","x-component":"ArrayTable"}}]});const Wi=e=>{const o=[];return e.children.forEach(n=>{W(n,"FormTab.TabPane")&&o.push(n)}),o},Hi=(e,o=[])=>{if(o.length!==0)return o.some(n=>n.id===e)?e:o[o.length-1].id},Ue=y(e=>{const[o,n]=b.useState(),r=M(),a=$(),p=ye("FormTab",s=>[new S({componentName:"Field",props:{type:"void","x-component":"FormTab.TabPane","x-component-props":{tab:"Unnamed Title"}},children:s})]),l=Wi(a),d=()=>{var s;return(s=a.children)!=null&&s.length?t.jsx(uo,{...e,activeKey:Hi(o,l),onChange:i=>{n(i)},children:l.map(i=>{const c=i.props["x-component-props"]||{};return b.createElement(uo.TabPane,{...c,style:{...c.style},tab:t.jsx("span",{"data-content-editable":"x-component-props.tab","data-content-editable-node-id":i.id,children:c.tab}),key:i.id},tt.createElement("div",{[p.props.nodeIdAttrName]:i.id,style:{padding:"20px 0"}},i.children.length?t.jsx(D,{node:i}):t.jsx(A,{node:i})))})}):t.jsx(A,{})};return t.jsxs("div",{...r,children:[d(),t.jsx(G,{actions:[{title:a.getMessage("addTabPane"),icon:"AddPanel",onClick:()=>{const s=new S({componentName:"Field",props:{type:"void","x-component":"FormTab.TabPane","x-component-props":{tab:"Unnamed Title"}}});a.append(s),n(s.id)}}]})]})});Ue.TabPane=e=>t.jsx(b.Fragment,{children:e.children});Ue.Behavior=h({name:"FormTab",extends:["Field"],selector:e=>e.props["x-component"]==="FormTab",designerProps:{droppable:!0,allowAppend:(e,o)=>e.children.length===0||(o==null?void 0:o.every(n=>n.props["x-component"]==="FormTab.TabPane"))||!1,propsSchema:w(Re)},designerLocales:pn},{name:"FormTab.TabPane",extends:["Field"],selector:e=>e.props["x-component"]==="FormTab.TabPane",designerProps:{droppable:!0,allowDrop:e=>e.props["x-component"]==="FormTab",propsSchema:w(Re.TabPane)},designerLocales:cn});Ue.Resource=x("Layouts",{icon:"TabSource",elements:[{componentName:"Field",props:{type:"void","x-component":"FormTab"}}]});const Gi=e=>{const o=[];return e.children.forEach(n=>{W(n,"FormCollapse.CollapsePanel")&&o.push(n)}),o},Be=y(e=>{const[o,n]=b.useState([]),r=$(),a=M(),p=ye("FormCollapse",s=>{const i=new S({componentName:"Field",props:{type:"void","x-component":"FormCollapse.CollapsePanel","x-component-props":{header:"Unnamed Title"}},children:s});return n(de(o).concat(i.id)),[i]}),l=Gi(r),d=()=>{var s;return(s=r.children)!=null&&s.length?t.jsx(ho,{...e,activeKey:l.map(i=>i.id),children:l.map(i=>{const c=i.props["x-component-props"]||{};return b.createElement(ho.Panel,{...c,style:{...c.style},header:t.jsx("span",{"data-content-editable":"x-component-props.header","data-content-editable-node-id":i.id,children:c.header}),key:i.id},tt.createElement("div",{[p.props.nodeIdAttrName]:i.id,style:{padding:"20px 0"}},i.children.length?t.jsx(D,{node:i}):t.jsx(A,{})))})}):t.jsx(A,{})};return t.jsxs("div",{...a,children:[d(),t.jsx(G,{actions:[{title:r.getMessage("addCollapsePanel"),icon:"AddPanel",onClick:()=>{const s=new S({componentName:"Field",props:{type:"void","x-component":"FormCollapse.CollapsePanel","x-component-props":{header:"Unnamed Title"}}});r.append(s);const i=de(o);n(i.concat(s.id))}}]})]})});Be.CollapsePanel=e=>t.jsx(b.Fragment,{children:e.children});Be.Behavior=h({name:"FormCollapse",extends:["Field"],selector:e=>e.props["x-component"]==="FormCollapse",designerProps:{droppable:!0,allowAppend:(e,o)=>e.children.length===0||!!(o!=null&&o.every(n=>n.props["x-component"]==="FormCollapse.CollapsePanel")),propsSchema:w(De)},designerLocales:dn},{name:"FormCollapse.CollapsePanel",extends:["Field"],selector:e=>e.props["x-component"]==="FormCollapse.CollapsePanel",designerProps:{droppable:!0,allowDrop:e=>e.props["x-component"]==="FormCollapse",propsSchema:w(De.CollapsePanel)},designerLocales:mn});Be.Resource=x("Layouts",{icon:"CollapseSource",elements:[{componentName:"Field",props:{type:"void","x-component":"FormCollapse"}}]});const We=y(e=>{const o=$(),n=M();return o.children.length===0?t.jsx(A,{...e}):t.jsxs("div",{...n,className:"dn-grid",children:[t.jsx(cr,{...e,children:e.children}),t.jsx(G,{actions:[{title:o.getMessage("addGridColumn"),icon:"AddColumn",onClick:()=>{const r=new S({componentName:"Field",props:{type:"void","x-component":"FormGrid.GridColumn"}});o.append(r)}}]})]})});We.GridColumn=y(({gridSpan:e,...o})=>t.jsx(A,{...o,"data-grid-span":e,children:o.children}));We.Behavior=h({name:"FormGrid",extends:["Field"],selector:e=>e.props["x-component"]==="FormGrid",designerProps:{droppable:!0,allowDrop:e=>e.props["x-component"]!=="FormGrid",propsSchema:f(je)},designerLocales:un},{name:"FormGrid.GridColumn",extends:["Field"],selector:e=>e.props["x-component"]==="FormGrid.GridColumn",designerProps:{droppable:!0,allowDrop:e=>e.props["x-component"]==="FormGrid",propsSchema:f(je.GridColumn)},designerLocales:hn});We.Resource=x("Layouts",{icon:"GridSource",elements:[{componentName:"Field",props:{type:"void","x-component":"FormGrid"},children:[{componentName:"Field",props:{type:"void","x-component":"FormGrid.GridColumn"}},{componentName:"Field",props:{type:"void","x-component":"FormGrid.GridColumn"}},{componentName:"Field",props:{type:"void","x-component":"FormGrid.GridColumn"}}]}]});const Wt=dt(dr);Wt.Behavior=h({name:"FormLayout",extends:["Field"],selector:e=>e.props["x-component"]==="FormLayout",designerProps:{droppable:!0,propsSchema:w(Me)},designerLocales:_o});Wt.Resource=x("Layouts",{icon:"FormLayoutSource",elements:[{componentName:"Field",props:{type:"void","x-component":"FormLayout"}}]});const Ht=y(e=>t.jsx(A,{children:t.jsx("div",{...e})})),q="Div";Ht.Behavior=h({name:q,extends:["Field"],selector:e=>e.props["x-component"]===q,designerProps:{droppable:!0,propsSchema:w(F[q])},designerLocales:T[q]});Ht.Resource=x("Layouts",{icon:q,elements:[{componentName:"Field",props:{type:"void","x-component":q}}]});const Ji="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAAFQ9JREFUeF7tnQuUJGV1x++t3sXZAbI8hPAKIQiaB68oShSCIARFHiIagugSFoRBwD3s0t+tnt2ojeLO1PfNji6KKA/l/RRUBI0CyxIhIj4QMALmRBcTUGKC5qCTxZ2pm/44vXGdrequ+rqqunrq1jl74Ox+9373/m79+1FddS+CHEJACMQSQGEjBIRAPAERiJwdQqADARGInB5CQAQi54AQcCMg7yBu3MSqIgREIBUptKTpRkAE4sZNrCpCQARSkUJLmm4ERCBu3MSqIgREIBUptKTpRkAE4sZNrCpCQARSkUJLmm4ERCBu3MSqIgREIBUptKTpRkAE4sZNrCpCQARSkUJLmm4ERCBu3MSqIgREIBUptKTpRkAE4sZNrCpCQARSkUJLmm4ERCBu3MSqIgREIBUptKTpRkAE4sZNrCpCQARSkUJLmm4ERCBu3MSqIgREIBUptKTpRkAE4sZNrCpCQARSkUJLmm4ERCBu3MSqIgREIBUptKTpRkAE4sZNrCpCQARSkUJLmm4ERCBu3MSqIgREIBUptKTpRkAE4sZNrCpCQARSkUJLmm4ESimQSy65ZKsXX3xxp+np6Z0BYCf7h5m3d0tRrAaFACL+AhGfnZmZec7zvOcQ8edKqd/0M/5SCURrfRQivoeZF/UTiuxdHgKIeG0Yhtf6vn93P6IqhUCCIFhkhQEAR/UDguw5EAS+bsWilLquyGj7KpCxsbE9a7XaJwDgrUUmLXsNNIE1zOz7vv+dIrLom0CMMUcy8x0AsKCIRGWPuUOAmX+LiOcT0aV5Z9UXgRhjLmLmFXknJ/7nPIHPEtEZeWZZuECMMbcy8zvTJMXM9orGE2lsZO3gEUDEhcz8cgCwVyyHE2ZwBRGdmXBt6mWFCiQIAh8RxxNE+XUAeAwRH2XmbxLRvyWwkSVziMCqVav+MgzD05nZvkN0+xh+HBHdmUf6hQnEGPMmZr63SxLPMfNFvu9/Mo9kxefgEQiCYLf2i+q7O0Xved5f1Ov1H2adYSECCYJga0RcCwCv7pDA9dPT0xctX778yayTFH+DT0BrbV80z+2QyZoddtjhmMWLF6/PMttCBKK1Xg4AH+0Q+GIiuirLxMTX3COgtbY/B9wVlxkiLldKjWWZee4CaTabWwwPD38fAP4sJvAVRLQyy6TE19wlYIw5hZmvj8nwiYULF+4/MjKyISsCuQtEa306AFwZFTAiXqmUem9WyYifahAwxnyCmc+LyfYMIvpsViSKEMh9AHBYRMAveJ63b71efzqrZMRPNQiMjY3t4Xne44i4VUTGa4no8KxI5CqQIAiOQMR7ooJl5st93z8rq0TET7UIaK0vB4DITx+IeIRSak0WRHIVSKfPi1kmkQUI8TFYBDr9bICIi7K6qTFXgWitlwLAZAT6Z4lo18EqiURbNgJa658DwB/OjgsRSSllsog3b4EEAEARCTyglPrrLBIQH9UloLV+CAAOiiDwMSJalgWZvAVi792P+gX0GiL6+ywSEB/VJWCMuZGZT55NgJlv8n3/XVmQyVsgkVewmPlC3/ebWSQgPqpLIAiCJiJ+KM8rWSKQ6p5fA5+5CGTgSygJ5ElABJInXfE98AREIANfQkkgTwIikDzpiu+BJyACGfgSSgJ5EhCB5ElXfA88ARHIwJdQEsiTgAgkT7rie+AJiEAGvoSSQJ4ERCB50hXfA09ABDLwJZQE8iQgAsmJ7tjY2Lbz58/fMwzDPZl5TzuXYmZm5scAsG50dHRdTtuK24wJiEAyBmqMOYyZ7W32p3Vw/X1mvnqLLba4aunSpb/KOARxlyEBEUhGMLXWB7Rc2dvr35bC5TorFLktPwWxgpeKQDIA3n7XsGMWtnZ0dycRHedoK2Y5EhCB9AjXGHNea7ahHdDT62Gfod8NALhXR2KfHQERSA8sgyBYgoire3Ax2/RJIorrDpnhNuIqKQERSFJSs9Zprf8WAG5xNO9ktpqIzs/Br7h0ICACcYCmtbZjox8EgD07mP8jANh5Ej9g5u8h4o6IuB8A7MfMHZ+VR8SmUupCh9DEJGMCIhAHoFrrBgDEdvhuzd4+Wyn1mTjXExMTh4ZheCMA7BKz5smpqal9m83mtEN4YpIhARFISpjNZnNoyy23fKTV9uVPY0x9ItJJ3BpjnmXmnaPWZtm5L0kssiaagAgk5ZkRBMHZiBg3+fReIjoyqUuttW1s909R65n5rtYY4mOT+pJ1+RAQgaTk2ppktQoRIzvqIeJfKaW+lcZlEAS3ImLUwNGfEFGn7zhptpG1jgREICnBaa0/F3MbyToi+pOU7sAYs4yZV0XZTU1Nbd1sNn+d1qesz46ACCQlS621Hc9lx3TNPq4iosUp3UEQBK9CxMiZiYi4v1LqsbQ+ZX12BEQgKVkaY25j5hMjzJwGzncSSBiGBzQajUdThijLMyQgAkkJU2sd2U0eAJ4iorgrW7G7dPqIFYbhNo1G439ShijLMyQgAkkJU2v9PgD4VJQZM/+57/tPpHFpjLmVmTf7ko6Izyil7L1ZcvSRgAgkJXxjzDHMbH8h3+xIO/ItCIIDEfHbMSF8g4gOTRmeLM+YgAgkJdDJyckF09PTjwPAK6JMPc97a71e/2oSt1rrBwDg4Ji1y4joY0n8yJr8CIhAHNgGQXARIq6IMw3DcL9Go2FFFHtore0c7lNiFjw/f/78fZYuXfozh/DEJEMCIhAHmMaYfQDgsdaQntjZJ8w8hoifV0o90hrA8tIzHvYmR8/z3hCGoX1n2D1ua2b+lO/75zqEJiYZExCBOALVWtu5iPaKVrfjfwHAfnHfHgD+uNtiALhnaGjo2CVLlryYYK0syZmACKQHwEEQ3IyIJ/XgYjPTDRs27LRixYrnsvQpvtwJiEDc2b1k2boSdWfrStQxPbp5ydzzvNfV6/W4q1pZbJGZj5UrV25fq9X29jxvrzAM90LEp2q12k/Wr1//9IoVK+bMdycRSAanjNbafl/4ZA+unmbmo9P+htLDfk6m9grehg0bTvQ878SYuwk2+l2DiDeFYWgnwb7gtFlJjEQgGRUiCIJ3I6J9iOqP0rhsPWV4+7x5884oe3+s9otAHQD2SJHfTxHRKKV6efFIsV32S0UgGTJtf+w4DRFt47h9O7lGxGvDMLQ9se7NMITMXRljdgSAcWZOfSPmxmAQ8QalVNQs+8zjzdqhCCRroraTwy231NatW3cEIm7HzNsCwLbMPIWIzyPiLxHx2Xq9/t0cts7UZeu3mr0B4PP2OfoMHN9PRIdl4KdQFyKQQnEPzmaTk5O7Tk9PfwkAXpNh1PcR0Zsy9Je7KxFI7ogHbwPbeLtWq1lx2EeCsz5SPZac9eZp/YlA0hKb4+svvvjil61fv/5rAPDGLqnaB7mutXcUDA0NPWR/v5mZmbHvNm8BgFO72N5NREcNAkoRyCBUqcAYtdZru4mDmZdvs802q0dGRqaiQkty2RsRv6aUsmIq9SECKXV5ig0uiThajfDeSUS3dYssSedJRPyqUirq8eVu7gv7dxFIYajLvVEScTDzO3zfvz1pJglFcpdSqrTtjUQgSas9h9clFMfbfd//YloMSUTSulL2ZSI6Pq3vItaLQIqgXOI9kogDEU9QStmrWk5HQpF8iYhOcNogRyMRSI5wy+46oTiOV0p9uddcEorkC0QU1TGm1+2d7UUgzugG2zChOI5VStk+YJkcCUVyGxFFdZrMJIa0TkQgaYnNgfVJxAEAxxDRV7JON6FIbiWiTJ+zcc1DBOJKbkDtgiC4HxG7dUs5mojsfJNcjoQiuZmITs4lgBRORSApYA360iTiCMPwLY1Gw/6SnuuRUCQ3ElFcY4tc49voXARSCOb+b5JEHMx8lO/7dxcVbUKR3EBEfbtVXgRS1NnQx32MMfczc8ePVcx8ZD+eTUkokuuIaFE/EIpA+kG9wD2NMQ8y8xs6bYmIRyil1hQY1u9tlVAk1xCRfRCt0EMEUijuYjfTWj8CAAd0EcfhSil7g2Jfj4QicRox0UtiIpBe6JXYVmv9IwCwTwR2Og4jovvLkkZCkTiNmXDNUQTiSm6W3eTk5HYbNmywlyVfjYh72ZOTmf8AER9uDdx5OAxD24r08Uaj8QMAeKnTYl6H1vo/AGDXLv4PJaJv5BWDq9+EIrmCiM503SONnQgkDa2ItePj4/sj4qmtKVFWHHFjnf/fkpnt0M6L8rpapLV+3j4D3yWtQ4jIznkv5ZFQJJcR0UjeCYhAeiCstT7ddvwAgB3SukFE27b0I0qp36S1jVvfmt++vjW//WWd/IVheHCj0fjnrPbMy08SkaQdN+ESqwjEhRqAHb55CTOf42j+khki2s4mViTOd8paP7aJtjFmQ8tXrVM8zPx63/cf6iXmIm2TiAQAcv24JQJxqLjW+qZWQ+q/czCNNGHmU33ft893pz7a4vjPVmfHl3cydhlRnTqYHAySiAQRr1RKvTeH7W1r2WarO/+HInyvbV3gODyLPWNHBGThXGt9HwBs1m+pdeJc6Pt+M4s9NvWhtb4OADL/ZZeZD/J9336hT3w0m01vwYIFT7UvCsTaDVLP36gkkoiEmT/n+779yJvpIQJJgVNrfXW3jh2I+Gtm/qHt9gEA9mOPbbpm/2zdbas0nd2tOIaHh78FAAd28ut53oGD0KSuG5skImm1Rc38dxIRSLfKtP9da30lAHR7hfp0GIZjjUbjp5u6HR8f393zvOUA0O2qy8MLFy48ZGRkxAor9miLw95t+zddwn9N61HW7yVMsfTLkogEEa9WSp2WVTIikAQktdafAYCzuiw9iYhu7bTGGHMSM9/cxc8diLhSKWXfHTY7jDEH2bY7ANDxGW5mfq3v+99JkN5ALUkiEgDI7LYUEUiX00NrbUc+29HPnY5TiOjGJGda60c8+2Xy8i5rf2tFEobhLzzPe4aZZxBxZ/s7S1scW3Syd/k+kyT2sqxJIhLbHFwp1a2BXdeURCAdEGmtLwaA93eiiIiLlFL2i3viY3x8/OjWF+fMn9azAQzapdzE0GYtTCKS1t0M1xPRe1z3sHYikBh6WutJAFjaBe5iIrrKpQBaa9tVMNG46BT+S/0LeYo8Ei1NKJKenicRgUSUwhijmVl1qdKZRHRFokrGi9AOpDG9+NjEtpT3VmWUW6ybhCJxfjJRBDILfRAEKxFxtMtn/Pf5vv/pLIqvtbZdBT8AAK9z8YeIP6vVam9etmxZx7nsLr4HxSaJSOxIOKXUu9LmJALZhFgQBB9GRHuyxh7M/H7f9zMdKdZsNoeGh4ftvvbqVJrjC57nnVWv1/8rjdFcXDs+Pn6S53kdrxAy8y2tOZCp7oAQgbTPFq21fXW5odPJg4hLlVIfz+sEM8bYOwLezsyvbD/L8YqIvRgRJ6anp28cHR21D0TJ0SaQRCQAcCkRJb6HTgTyO4HY2zxe2+FsU0Q0UeTZaN9ZhoaG9m7d+bsAEf97Zmbm+dHR0V8WGcOg7ZVEJJ7n7VGv159OkpsIBAAmJyf3mp6e/tc4YIjYUErZ29PlGAACCUSS+A4DEcjv3kHuAIDjZtcfEf9BKfXRATgvJMRNCMSJpNW95YFW95bEo+VEIJtA1VrbK0H7bPwrRGwqpS6UM28wCUSIxH5/e1uaZtwikFm1t0DsX4VhuHZ0dLTv3T4G89QsT9RWJLVa7R12DHfrUvpXut0vNztyEUh5aimRlJCACKSERZGQykNABFKeWkgkJSQgAilhUSSk8hAQgZSnFhJJCQmIQEpYFAmpPAREIOWphURSQgIikBIWRUIqDwERSHlqIZGUkIAIpIRFkZDKQ0AEUp5aSCQlJCACKWFRJKTyEJgLAom8TT3vrt/lKaFEkicBY8xVzBw1G/FOItrs8QiXWPJuXn0pAJw9OzBEXKuUyqT7tkvSYjM3CGitHwCAgyPOr8uVUt26bSaCkKtAgiD4ACJ+OCKSZ1pteXZLFKEsEgIxBIwxzzKz7Wr5ewczf8T3/Q9mAS5XgRhjzmTmy6IC7fd44yzgiY/+EQiC4AhEvCcmgnOIyH566fnIVSBBEByPiJETmooY0dUzHXFQWgJaa9tDOXIwDyKe0OtksI2J5yqQycnJXaenp22L/x0jSL/ged6+STtYlLZSEljhBMbGxvbwPO/xVoulrSI2f56Z9/d9304T7vnIVSA2OmPMODP7MR+zchvP1TMZcVBaAsaYVcy8LCbA1UR0flbB5y6QIAhehYj2XWQ4RiQXKKVsM2o5hEBXAhMTE28Ow9AOKIo8sp69krtAbBZaa9sO9Ny4pJRSXmsYI3elIwsqTaA9vWsmDoJrj99OUAsRyPj4+P6e560BgO06BJN40E2lz5KKJh8EwQW2rWun9MMwPLbRaNyVJaJCBGIDnpiYOCcMw0u6BH9HGIYfbDQaj2aZpPgaXAL2C3mtVrPNwzvOoGTmuu/7q7LOtDCBtD9q2QbUXdvc2zHRdhLtvHnzvn3BBRf8e9ZJi7/yE2j/znEyM58cc7Vq0ySuI6JFeWRVqEDaIrGNiXdPmgwz/xgRv9se35zUTNYNIAFE3LXdOX+v1qxI+/+JjqmpqVqz2QwTLU65qHCBtEXyozaIlOHKciGwGYHEza5d2PVFIDZQY8xqZl7iErTYCAEA+JepqalDms3mr/Kk0TeBtEWyhJlX55mg+J6TBC4jopEiMuurQNoisV/Ezou6bbkIALLHQBF4sDWP3orjmqKi7rtANiYaBMEJnuctYuYTi0pe9hkMAsx8OwBc6/v+F4uOuDQC2Zi4Meb1zHwsIu4chuEu9r+tV41dAGD7ouHIfoUTsANPn2HmZ+yEYER8rjV67y6l1DcLj6S9YekE0i8Qsq8QiCIgApHzQgh0ICACkdNDCIhA5BwQAm4E5B3EjZtYVYSACKQihZY03QiIQNy4iVVFCIhAKlJoSdONgAjEjZtYVYSACKQihZY03QiIQNy4iVVFCIhAKlJoSdONgAjEjZtYVYSACKQihZY03QiIQNy4iVVFCIhAKlJoSdONgAjEjZtYVYSACKQihZY03QiIQNy4iVVFCIhAKlJoSdONgAjEjZtYVYSACKQihZY03QiIQNy4iVVFCIhAKlJoSdONgAjEjZtYVYSACKQihZY03QiIQNy4iVVFCIhAKlJoSdONgAjEjZtYVYSACKQihZY03QiIQNy4iVVFCIhAKlJoSdONgAjEjZtYVYTA/wGdDK9fVdsc3wAAAABJRU5ErkJggg==",Gt=y(({src:e,value:o,...n})=>t.jsx("img",{...n,src:o||e||Ji})),K="Img";Gt.Behavior=h({name:K,extends:["Field"],selector:e=>e.props["x-component"]===K,designerProps:{propsSchema:f(F[K])},designerLocales:T[K]});Gt.Resource=x("Displays",{icon:K,elements:[{componentName:"Field",props:{type:"string","x-component":K}}]});const Jt=y(({value:e,content:o,...n})=>t.jsx(Er,{value:e||o,...n})),Z="QRCode";Jt.Behavior=h({name:Z,extends:["Field"],selector:e=>e.props["x-component"]===Z,designerProps:{propsSchema:f(F[Z])},designerLocales:T[Z]});Jt.Resource=x("Displays",{icon:Z,elements:[{componentName:"Field",props:{type:"string","x-component":Z}}]});const j=({icon:e,...o})=>{const n=e,r=Ye[n]?Ye[n]:void 0;return r?t.jsx(r,{...o}):void 0},Qt=y(({icon:e,value:o,children:n,href:r,...a})=>{const p=j({icon:e});let l=o||n;return!p&&!l&&(l="按钮"),t.jsx(H,{...a,icon:p,children:l})}),Y="Button";Qt.Behavior=h({name:Y,extends:["Field"],selector:e=>e.props["x-component"]===Y,designerProps:{propsSchema:f(F[Y])},designerLocales:T[Y]});Qt.Resource=x("Displays",{icon:Y,elements:[{componentName:"Field",props:{type:"string","x-component":Y,"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})
`}}}}]});const Qi=305,qt=({style:e,insetInlineEnd:o,insetBlockEnd:n})=>{let r=o!==void 0?o||0:e!=null&&e.insetInlineEnd?+(e==null?void 0:e.insetInlineEnd):0,a=n!==void 0?n||0:e!=null&&e.insetBlockEnd?+(e==null?void 0:e.insetInlineEnd):void 0;return{...e,insetInlineEnd:Qi+r,insetBlockEnd:a}},Kt=y(({icon:e,style:o,href:n,...r})=>t.jsx(pt.Group,{...r,icon:j({icon:e}),style:qt(r)})),Zt=y(({icon:e,style:o,href:n,...r})=>{const a=()=>{var p;return((p=document.querySelector(".dn-pc-simulator"))==null?void 0:p.firstChild)||window};return t.jsx(pt.BackTop,{...r,icon:j({icon:e}),style:qt(r),target:a})}),Yt=y(({icon:e,value:o,description:n,style:r,href:a,...p})=>t.jsx(pt,{...p,icon:j({icon:e}),description:o||n,style:qt(p)})),P="FloatButton";Yt.Behavior=h({name:P,extends:["Field"],selector:e=>e.props["x-component"]===P,designerProps:{propsSchema:w(F[P])},designerLocales:T[P]});Yt.Resource=x("Displays",{icon:P,elements:[{componentName:"Field",props:{type:"string","x-component":P,"x-component-props":{description:"按钮",type:"primary",insetInlineEnd:24,insetBlockEnd:48},"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})
`}}}}]});const X=`${P}Group`;Kt.Behavior=h({name:X,extends:["Field"],selector:e=>e.props["x-component"]===X,designerProps:{droppable:!0,allowAppend:(e,o)=>!!(o!=null&&o.every(n=>n.props["x-component"]===P)),propsSchema:w(F[X])},designerLocales:T[X]});Kt.Resource=x("Displays",{icon:X,elements:[{componentName:"Field",props:{type:"void","x-component":X,"x-component-props":{icon:"MoreOutlined",type:"primary",trigger:"hover",insetInlineEnd:24,insetBlockEnd:48}},children:[{componentName:"Field",props:{"x-component":P,"x-component-props":{description:"按钮1",type:"primary"},"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})
`}}}},{componentName:"Field",props:{"x-component":P,"x-component-props":{description:"按钮2",type:"primary",insetInlineEnd:24,insetBlockEnd:48},"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})
`}}}}]}]});const _=`${P}BackTop`;Zt.Behavior=h({name:_,extends:["Field"],selector:e=>e.props["x-component"]===_,designerProps:{propsSchema:w(F[_])},designerLocales:T[_]});Zt.Resource=x("Displays",{icon:_,elements:[{componentName:"Field",props:{type:"void","x-component":_,"x-component-props":{type:"primary"}}}]});const Xt=y(({value:e,children:o,...n})=>t.jsx(mr,{...n,children:e||o})),ee="Divider";Xt.Behavior=h({name:ee,extends:["Field"],selector:e=>e.props["x-component"]===ee,designerProps:{propsSchema:f(F[ee])},designerLocales:T[ee]});Xt.Resource=x("Displays",{icon:ee,elements:[{componentName:"Field",props:{type:"string","x-component":ee}}]});const _t=y(({style:e,className:o,...n})=>{const r=M(),a=$();return t.jsx("div",{...r,style:e,className:o,children:a.children.length===0?t.jsx(A,{}):t.jsx(D,{node:a.children[0]})})}),te="IteratorLayout";_t.Behavior=h({name:te,extends:["Field"],selector:e=>e.props["x-component"]===te,designerProps:{inlineChildrenLayout:!0,droppable:!0,allowAppend:(e,o)=>e.children.length===0,propsSchema:f(F[te])},designerLocales:T[te]});_t.Resource=x("Arrays",{icon:te,elements:[{componentName:"Field",props:{type:"array","x-component":te,"x-component-props":{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill, 120px)",justifyContent:"space-between",gap:"10px"}},default:[{title:"React",url:"https://zh-hans.react.dev/learn"},{title:"ReactRouter",url:"https://reactrouter.com/en/main/start/tutorial"},{title:"Zustand",url:"https://docs.pmnd.rs/zustand/getting-started/introduction"},{title:"Redux",url:"https://redux.js.org/introduction/getting-started"},{title:"Redux-Toolkit",url:"https://redux-toolkit.js.org/introduction/getting-started"},{title:"Next.js",url:"https://www.nextjs.cn"},{title:"Vue",url:"https://cn.vuejs.org/v2/guide/index.html"},{title:"VueRouter",url:"https://router.vuejs.org/zh/guide"},{title:"Vuex",url:"https://vuex.vuejs.org/zh/guide"},{title:"Pinia",url:"https://pinia.vuejs.org/zh/introduction.html"},{title:"Nuxt",url:"https://nuxt.com/docs/getting-started/installation"},{title:"Electron",url:"https://www.electronjs.org/zh/docs/latest/tutorial/quick-start"},{title:"Tauri",url:"https://tauri.app/zh-cn/v1/guides/"}]},children:[{componentName:"Field",props:{type:"object"},children:[{componentName:"Field",props:{type:"void","x-component":"Div","x-component-props":{style:{cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",padding:"8px 0px 8px 0px"}},"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    // 处理点击指定的循环类组件的条目链接，默认就是取的条目的 url 字段来打开
    $utils.clickArrayFieldUrlItem($self)
  },
})
`}}},children:[{componentName:"Field",props:{type:"string","x-component":"Img","x-component-props":{style:{width:"40px",height:"40px"},objectFit:"contain"},name:"icon","x-reactions":{fulfill:{run:`$effect(() => {
  // 获取迭代器布局中当前点击的条目数据
  const row = $utils.getArrayFieldRow($self)
  // 获取书签的图标地址
  $utils.getBookmarkIconUrl(row.url, row.icon).then((iconUrl) => {
    $props({
      src: iconUrl,
    })
  })
}, [])
`}}}},{componentName:"Field",props:{type:"string","x-component":"Text",name:"title"}}]}]}]}]});const eo=()=>{const e=M();return t.jsx("div",{className:"dn-droppable-placeholder",...e,children:"动态 schema 区块"})},oe="DynamicSchemaBlock";eo.Behavior=h({name:oe,extends:["Field"],selector:e=>e.props["x-component"]===oe,designerProps:{propsSchema:w(F[oe])},designerLocales:T[oe]});eo.Resource=x("Layouts",{icon:oe,elements:[{componentName:"Field",props:{type:"void","x-component":oe}}]});const to=y(e=>{const[o,n]=b.useState(e.open),r=M(),a=$(),p=b.useCallback(()=>{n(!1)},[]);return t.jsxs(t.Fragment,{children:[!o&&t.jsx("div",{...r,children:t.jsx(G,{actions:[{title:`打开抽屉 ${a.props.title||a.props.name||""}`,icon:"AddOperation",onClick:()=>{n(!0)}}]})}),o&&t.jsx(qr,{...e,rootStyle:{position:"absolute"},getContainer:()=>document.querySelector(".dn-component-tree"),closeIcon:j({icon:e.closeIcon}),open:o,onClose:p,children:t.jsx("div",{...o?r:{},children:a.children.length?e.children:t.jsx(A,{})})})]})}),ne="Drawer";to.Behavior=h({name:ne,extends:["Field"],selector:e=>e.props["x-component"]===ne,designerProps:{droppable:!0,propsSchema:w(F[ne])},designerLocales:T[ne]});to.Resource=x("Layouts",{icon:ne,elements:[{componentName:"Field",props:{type:"object","x-component":ne,"x-reactions":{fulfill:{run:`$props({
  // 点击遮罩层或左上角叉或取消按钮的回调
  onClose: () => {
    $self.componentProps.open = false
  },
})
`}}}}]});const oo=y(({title:e,...o})=>t.jsx(A,{children:t.jsx(Ro,{...o,title:e||"Tooltip"})})),re="Tooltip";oo.Behavior=h({name:re,extends:["Field"],selector:e=>e.props["x-component"]===re,designerProps:{droppable:!0,propsSchema:f(F[re])},designerLocales:T[re]});oo.Resource=x("Layouts",{icon:re,elements:[{componentName:"Field",props:{type:"void","x-component":re}}]});const no=y(e=>{const[o,n]=b.useState(e.open),r=M(),a=$(),p=b.useCallback(()=>{n(!1)},[]);return t.jsxs(t.Fragment,{children:[!o&&t.jsx("div",{...r,children:t.jsx(G,{actions:[{title:`打开对话框 ${a.props.title||a.props.name||""}`,icon:"AddOperation",onClick:()=>{n(!0)}}]})}),o&&t.jsx(st,{...e,getContainer:()=>document.querySelector(".dn-component-tree"),styles:{mask:{position:"absolute"},wrapper:{position:"absolute"}},closeIcon:j({icon:e.closeIcon}),open:o,onCancel:p,onOk:p,children:t.jsx("div",{...o?r:{},children:a.children.length?e.children:t.jsx(A,{})})})]})}),ae="Modal";no.Behavior=h({name:ae,extends:["Field"],selector:e=>e.props["x-component"]===ae,designerProps:{droppable:!0,propsSchema:w(F[ae])},designerLocales:T[ae]});no.Resource=x("Layouts",{icon:ae,elements:[{componentName:"Field",props:{type:"object","x-component":ae,"x-reactions":{fulfill:{run:`$props({
  // 点击取消按钮
  onCancel: () => {
    $self.componentProps.open = false
  },
  // 点击确认按钮
  onOk: () => {
    $self.componentProps.open = false
  },
})
`}}}}]});const ro=y(({icon:e,...o})=>t.jsx(A,{children:t.jsx(Kr,{...o,icon:j({icon:e})})})),ie="Popconfirm";ro.Behavior=h({name:ie,extends:["Field"],selector:e=>e.props["x-component"]===ie,designerProps:{droppable:!0,propsSchema:w(F[ie])},designerLocales:T[ie]});ro.Resource=x("Layouts",{icon:ie,elements:[{componentName:"Field",props:{type:"void","x-component":ie,"x-reactions":{fulfill:{run:`$props({
  // 点击取消按钮
  onCancel: () => {
    $message.info('点击了取消')
  },
  // 点击确认按钮
  onConfirm: () => {
    $message.info('点击了确认')
  },
})`}}}}]});const ao=dt(Zr),se="Popover";ao.Behavior=h({name:se,extends:["Field"],selector:e=>e.props["x-component"]===se,designerProps:{droppable:!0,propsSchema:w(F[se])},designerLocales:T[se]});ao.Resource=x("Layouts",{icon:se,elements:[{componentName:"Field",props:{type:"void","x-component":se}}]});const io=y(({value:e,indicator:o,spinning:n,...r})=>t.jsx(A,{children:t.jsx(En,{...r,spinning:e||n,indicator:j({icon:o,spin:!0})})})),le="Spin";io.Behavior=h({name:le,extends:["Field"],selector:e=>e.props["x-component"]===le,designerProps:{droppable:!0,propsSchema:f(F[le])},designerLocales:T[le]});io.Resource=x("Layouts",{icon:le,elements:[{componentName:"Field",props:{type:"void","x-component":le}}]});const so=y(({value:e,children:o,icon:n,closeIcon:r,...a})=>t.jsx(ke,{...a,icon:j({icon:n}),closeIcon:j({icon:r}),children:e||o||"Tag"})),lo=y(({value:e,children:o,onChange:n,onCheckedChange:r,...a})=>t.jsx(ke.CheckableTag,{...a,onChange:r,children:e||o||"CheckableTag"})),U="Tag";so.Behavior=h({name:U,extends:["Field"],selector:e=>e.props["x-component"]===U,designerProps:{propsSchema:f(F[U])},designerLocales:T[U]});so.Resource=x("Displays",{icon:U,elements:[{componentName:"Field",props:{type:"string","x-component":U}}]});const pe=`Checkable${U}`;lo.Behavior=h({name:pe,extends:["Field"],selector:e=>e.props["x-component"]===pe,designerProps:{propsSchema:f(F[pe])},designerLocales:T[pe]});lo.Resource=x("Displays",{icon:pe,elements:[{componentName:"Field",props:{type:"string","x-component":pe,"x-reactions":{fulfill:{run:`$props({
  onCheckedChange: (checked) => {
    $self.componentProps.checked = checked
  },
})
`}}}}]});const po=y(({value:e,src:o,...n})=>t.jsx("iframe",{...n,src:e||o})),ce="Iframe";po.Behavior=h({name:ce,extends:["Field"],selector:e=>e.props["x-component"]===ce,designerProps:{propsSchema:f(F[ce])},designerLocales:T[ce]});po.Resource=x("Displays",{icon:ce,elements:[{componentName:"Field",props:{type:"string","x-component":ce,"x-component-props":{style:{width:"100%",height:"100%",borderStyle:"none"}},default:"https://www.baidu.com"}}]});const Io=Object.freeze(Object.defineProperty({__proto__:null,ArrayCards:Le,ArrayTable:ze,Button:Qt,Card:zt,Cascader:At,CheckableTag:lo,Checkbox:Pt,DatePicker:Vt,Div:Ht,Divider:Xt,Drawer:to,DynamicSchemaBlock:eo,Field:xn,FloatButton:Yt,FloatButtonBackTop:Zt,FloatButtonGroup:Kt,Form:Ct,FormCollapse:Be,FormGrid:We,FormLayout:Wt,FormTab:Ue,Iframe:po,Img:Gt,Input:Ft,IteratorLayout:_t,Modal:no,NumberPicker:Rt,ObjectContainer:Bt,Password:Et,Popconfirm:ro,Popover:ao,QRCode:Jt,Radio:kt,Rate:jt,Select:vt,Slider:Nt,Space:Ut,Spin:io,Switch:Ot,Tag:so,Text:Lt,TimePicker:$t,Tooltip:oo,Transfer:Dt,TreeSelect:Tt,Upload:Mt,createComponentSchema:wt,createFieldSchema:f,createVoidFieldSchema:w},Symbol.toStringTag,{value:"Module"})),qi=t.jsxs("svg",{children:[t.jsx("path",{d:"M122.88 165.888h778.24c-9.216 0-16.384-7.168-16.384-16.384v713.728c0-9.216 7.168-16.384 16.384-16.384H122.88c9.216 0 16.384 7.168 16.384 16.384V150.016c0 8.192-6.656 15.872-16.384 15.872z m-32.768 684.544c0 26.112 20.992 47.104 47.104 47.104h750.08c26.112 0 47.104-20.992 47.104-47.104V162.304c0-26.112-20.992-47.104-47.104-47.104H137.216c-26.112 0-47.104 20.992-47.104 47.104v688.128z","p-id":"16224",fill:"#bfbfbf"}),t.jsx("path",{d:"M336.384 651.264H243.2V344.576h91.648c92.672 2.048 140.288 53.248 142.336 154.112 1.024 103.424-46.08 154.624-140.8 152.576z m1.536-257.536h-43.008v211.456h44.544c59.392 2.048 88.064-33.28 87.552-106.496 0-70.144-29.696-104.96-89.088-104.96zM517.12 344.576h51.712v59.392H517.12V344.576z m0 78.848h51.712v227.84H517.12V423.424zM748.032 423.424h53.248l-81.408 227.84h-43.008l-76.8-227.84h53.248l46.08 162.816 48.64-162.816z","p-id":"16225",fill:"#bfbfbf"})]}),Ki=t.jsx("svg",{children:t.jsx("path",{d:"M937.814 41.726 86.28736 41.726c-44.7304 0-81.3199 33.2452-81.3199 78.0483l0 782.5664c0 44.802 36.5885 81.4653 81.3199 81.4653l858.312704 0c44.7304 0 77.951-36.6633 77.951-81.4653L1022.551064 119.774208C1022.55 74.9711 982.5454 41.726 937.814 41.726zM332.7898 157.5496c68.8886 0 124.7416 55.8049 124.7416 124.6454 0 68.8404-55.852 124.6454-124.7416 124.6454s-124.7416-55.8049-124.7416-124.6454C208.0481 213.3535 263.9002 157.5496 332.7898 157.5496zM119.508 885.0156c-9.3532 0-18.7791-3.2225-26.4356-9.815-17.0588-14.635-19.0454-40.3425-4.4104-57.4269l186.9906-281.855c13.8854-16.2345 37.9218-18.9491 55.1014-6.2269l164.9889 122.5349 295.6196-335.8177c14.0052-17.5677 88.2739-100.3162 131.7437-6.4686 0.0481-0.1454 0.0973 124.0873 0.1454 250.9363 0.0481 132.3039 0.0727 324.0182 0.0727 324.0182C922.4284 884.6746 119.895 885.0156 119.508 885.0156z",fill:"#bfbfbf","p-id":"6777"})}),Zi=t.jsx("svg",{children:t.jsx("path",{d:"M85.312 85.312V384H384V85.312H85.312zM0 0h469.248v469.248H0V0z m170.624 170.624h128v128h-128v-128zM0 554.624h469.248v469.248H0V554.624z m85.312 85.312v298.624H384V639.936H85.312z m85.312 85.312h128v128h-128v-128zM554.624 0h469.248v469.248H554.624V0z m85.312 85.312V384h298.624V85.312H639.936z m383.936 682.56H1024v85.376h-298.752V639.936H639.936V1023.872H554.624V554.624h255.936v213.248h128V554.624h85.312v213.248z m-298.624-597.248h128v128h-128v-128z m298.624 853.248h-85.312v-85.312h85.312v85.312z m-213.312 0h-85.312v-85.312h85.312v85.312z",fill:"#bfbfbf","p-id":"17311"})}),Yi=t.jsxs("svg",{children:[t.jsx("path",{d:"M992 928H32c-19.2 0-32-12.8-32-32V128c0-19.2 12.8-32 32-32h960c19.2 0 32 12.8 32 32v768c0 19.2-12.8 32-32 32zM64 864h896v-704H64v704z",fill:"#bfbfbf","p-id":"6437"}),t.jsx("path",{d:"M294.4 499.2c6.4 0 6.4-6.4 6.4-12.8 12.8-12.8 19.2-25.6 19.2-44.8 0-19.2-6.4-38.4-25.6-51.2-19.2-12.8-38.4-19.2-64-19.2H140.8v281.6h89.6c25.6 0 51.2-6.4 70.4-25.6 19.2-19.2 32-38.4 32-64 0-19.2-6.4-38.4-19.2-51.2-6.4-6.4-12.8-6.4-19.2-12.8z m-51.2-32c-6.4 6.4-12.8 12.8-25.6 12.8h-12.8v-51.2h19.2c32 0 32 12.8 32 19.2 0 12.8-6.4 19.2-12.8 19.2z m-38.4 70.4h19.2c44.8 0 44.8 19.2 44.8 25.6-6.4 12.8-6.4 19.2-12.8 25.6-6.4 0-12.8 6.4-25.6 6.4h-25.6v-57.6zM371.2 428.8H448v224h64V428.8h70.4v-57.6H371.2zM819.2 371.2v172.8l-108.8-172.8h-64v281.6h64V480l108.8 172.8h64V371.2z",fill:"#bfbfbf","p-id":"6438"})]}),Xi=t.jsxs("svg",{children:[t.jsx("path",{d:"M307.746548 456.898031c10.026354-2.306532 16.3422-12.229532 14.133905-22.35924-4.710278-21.153786-5.51255-42.813085-2.105964-64.467267 14.638395-94.449115 103.374392-159.523203 197.926861-144.885832 22.255887 3.40761 43.313481 11.030218 62.465681 22.461571 8.92016 5.313006 20.351514 2.403746 25.566282-6.418176 5.316076-8.821923 2.407839-20.351514-6.4192-25.66759-23.356964-13.938454-48.825009-23.162536-75.898621-27.372417-114.806769-17.747199-222.792179 61.163011-240.534261 176.065971-4.01443 26.270317-3.212158 52.638871 2.604314 78.406744 1.905396 8.724709 9.625218 14.638395 18.246573 14.638395 1.307785 0.102331 2.707668-0.099261 4.01443-0.402159z m0 0",fill:"#bfbfbf","p-id":"5183"}),t.jsx("path",{d:"M827.618842 596.167958c0-26.671453-10.526751-50.230008-28.073382-66.577324 17.643845-40.805358 27.572986-85.724407 27.572986-133.052319 0-185.290053-150.696164-335.987241-335.991334-335.987241-185.290053 0-335.987241 150.696164-335.987241 335.987241 0 110.997 54.244438 209.358215 137.365554 270.618441 0.596588 3.310396 1.302669 6.618744 2.304486 9.92914 3.207042 10.824533 7.520277 20.448728 13.032828 28.875654 30.182416 45.922912 64.271816 97.959056 98.159623 148.694577 34.290991 51.332109 84.020602 83.315544 147.5935 94.947466 8.018627 1.404999 15.338337 2.408863 22.35924 3.310395 3.406586 0.49835 6.814196 0.901533 10.226923 1.405a53.918004 53.918004 0 0 0 8.018627 0.602727h37.899168c3.010567 0 6.016017-0.201591 8.925277-0.706081 3.308349-0.49835 6.716982-1.101077 10.026354-1.600451 5.713119-0.905626 11.529591-1.807159 17.246803-2.809999 80.414471-13.836123 141.071969-74.299193 154.706501-154.10889 2.809999-15.941064 4.209882-32.082696 4.312212-47.828308 0.200568-59.854203 0.200568-67.37448 0.200568-91.639117 0.101307-12.332886 0.101307-29.178553 0.101307-60.060911zM211.187375 396.640646c0-154.608264 125.331473-279.939737 280.042067-279.939737 154.609287 0 279.94076 125.331473 279.940761 279.939737 0 39.204907-8.220219 76.501348-22.7614 110.389156-2.604314-0.200568-5.213745-0.396019-7.921413-0.39602-8.121981 0-16.043395 1.102101-23.563672 3.206019-8.719592-8.219195-19.147082-14.740726-30.877242-18.75004a127.332037 127.332037 0 0 0-5.816472-1.704828c9.223059-18.647709 15.941064-38.902008 19.249413-60.560284 7.216355-46.524616-1.00284-92.945879-23.76424-134.056182-5.013177-9.022491-16.3422-12.332886-25.364691-7.319709-9.022491 5.013177-12.332886 16.3422-7.319709 25.369807 18.745946 33.888831 25.469068 71.987544 19.549242 110.291942-3.706415 24.161283-12.4301 46.318932-24.762987 65.672722-1.106194 0.302899-2.306532 0.401136-3.310395 0.698918-7.720845-7.014764-16.943904-12.831236-27.473725-17.346063-8.019651-4.209882-17.042141-6.516414-26.266224-6.516414h-1.910512v-65.172325c0-45.520753-30.1773-80.81356-75.19868-87.932702-4.209882-0.700965-8.420787-1.003863-12.533454-1.003863-44.0124 0-82.616626 35.396161-86.126566 78.811973-0.401136 5.615904-0.401136 10.226922-0.401136 14.035668v142.276401c-17.443277-10.026354-33.187867-22.960944-46.324049-38.701441-6.613628-7.921413-18.34481-8.925277-26.266223-2.306532-7.921413 6.613628-8.925277 18.349927-2.306532 26.266223 9.121751 10.933003 19.348674 20.655436 30.27963 29.380145-22.662139 5.815449-42.612517 20.253276-54.94438 40.609906-0.505513 0.798179-0.803295 1.600451-1.306762 2.403747-56.94392-51.230802-92.540649-125.328403-92.540649-207.646224zM771.474125 747.769748c0 12.83226-1.306762 25.967418-3.510964 38.701441-9.625218 56.350402-52.237735 98.561783-108.788705 108.290355-8.925277 1.503237-17.844413 2.804882-26.872021 4.308119h-37.899168c-10.129708-1.503237-20.453844-2.604314-30.583553-4.41045-46.62183-8.524141-84.519975-31.083949-111.090121-70.886467-32.889061-49.329499-65.476247-98.762351-97.959055-148.292418-2.706645-4.210905-4.713348-9.023514-6.120395-13.835099-6.113231-20.959358 6.217608-42.515303 26.874068-46.52564 3.00545-0.601704 5.91471-0.899486 8.621354-0.899486 12.533454 0 23.161512 5.609765 31.386848 16.238846 13.634532 17.648962 26.466792 35.797297 39.704281 53.746088l4.210905 5.713118c0.298805-0.200568 0.698918-0.297782 1.1021-0.401136V404.562059c0-3.206018 0-6.315846 0.200568-9.526981 1.204431-14.736633 15.641235-27.270087 30.280654-27.270087 1.302669 0 2.604314 0.098237 3.911076 0.298806 17.443277 2.708692 27.871791 14.838963 27.871791 32.586162 0 49.833989 0 133.25391 0.102331 183.086875 0 2.605338 0.201591 5.313006 0.901533 7.721869 1.302669 4.009314 4.314259 6.212492 8.621354 6.516414h0.905626c4.107551 0 7.216355-2.105964 8.821923-5.719258 1.003863-2.306532 1.102101-5.111414 1.102101-7.720846V555.361577c0-11.230786 3.808746-21.056572 13.335726-27.675316 3.510964-2.403746 7.720845-3.906983 11.632945-5.816473h12.630668c0.49835 0.302899 0.802272 0.706081 1.302669 0.905626 16.347317 5.614881 23.964808 16.243963 23.964808 33.487696v22.259979-16.44453 22.261003c0 1.600451-0.098237 3.206018 0.102331 4.710278 0.698918 5.414313 4.812609 8.925277 10.026354 8.925277h0.998747c5.516644-0.505513 8.724709-4.210905 9.027607-11.128455v-12.034081c0.195451-7.319709 2.00261-14.236236 6.716982-20.253276 6.212492-7.818059 15.240099-12.132318 24.665773-12.132318 3.40761 0 6.91755 0.602727 10.226922 1.704828 12.93459 4.41045 21.252023 17.046235 21.252023 31.983435V604.193749c0 1.90335 0 3.906983 0.200568 5.810332 0.602727 5.116531 3.9121 7.721869 8.626471 8.626471 0.500397 0.098237 1.003863 0.098237 1.503237 0.098238 3.711532 0 7.720845-2.604314 8.925277-6.315846 0.798179-2.408863 0.998747-5.116531 0.998746-7.720845v-5.91471 11.329023s0.102331-3.406586 0.102331-13.232373c0-5.414313 1.003863-11.334139 3.207042-16.347316 4.715395-11.128455 16.043395-17.844413 27.773553-17.844414 2.208295 0 4.312212 0.200568 6.418177 0.698919 15.137769 3.310396 24.665773 16.141632 24.665772 32.78673-0.002047 90.543156 0.101307 60.962443-0.09926 151.60179z m0 0",fill:"#bfbfbf","p-id":"5184"})]}),_i=t.jsxs("svg",{children:[t.jsx("path",{d:"M71.68 828.416V297.984c0-39.936 32.768-72.704 72.704-72.704H901.12c0-39.936-32.768-71.68-72.704-71.68H72.704C32.768 153.6 0 186.368 0 226.304v530.432c0 39.936 31.744 72.704 71.68 71.68 0 1.024 0 0 0 0z",fill:"#bfbfbf","p-id":"6241"}),t.jsx("path",{d:"M353.28 598.016h-32.768v83.968H358.4c16.384 0 28.672-4.096 37.888-11.264 9.216-7.168 13.312-18.432 13.312-31.744 0-27.648-18.432-40.96-56.32-40.96zM385.024 560.128c8.192-7.168 13.312-17.408 13.312-30.72 0-22.528-15.36-33.792-46.08-33.792h-31.744v75.776h28.672c15.36-1.024 26.624-4.096 35.84-11.264z",fill:"#bfbfbf","p-id":"6242"}),t.jsx("path",{d:"M950.272 275.456H194.56c-39.936 0-72.704 32.768-72.704 72.704v530.432c0 39.936 32.768 72.704 72.704 72.704h755.712c39.936 0 72.704-32.768 72.704-72.704V348.16c0-39.936-32.768-72.704-72.704-72.704zM419.84 690.176c-15.36 13.312-33.792 19.456-57.344 19.456h-72.704V467.968h70.656c21.504 0 37.888 5.12 51.2 15.36 12.288 10.24 19.456 23.552 19.456 39.936 0 13.312-4.096 25.6-11.264 34.816-7.168 10.24-18.432 17.408-30.72 21.504v1.024c16.384 2.048 29.696 8.192 39.936 18.432s14.336 23.552 14.336 39.936c-1.024 21.504-8.192 37.888-23.552 51.2z m201.728-194.56h-69.632v214.016h-31.744V495.616H450.56v-27.648h171.008v27.648z m234.496 214.016H819.2L697.344 521.216c-3.072-5.12-6.144-10.24-8.192-15.36h-1.024c1.024 5.12 1.024 16.384 1.024 33.792v169.984h-30.72V467.968h38.912l118.784 185.344c5.12 9.216 9.216 14.336 10.24 16.384h1.024c-1.024-7.168-2.048-18.432-2.048-34.816V467.968h30.72v241.664z",fill:"#bfbfbf","p-id":"6243"})]}),es=t.jsx("svg",{children:t.jsx("path",{d:"M512 0C230.4 0 0 230.4 0 512S230.4 1024 512 1024 1024 793.6 1024 512 793.6 0 512 0z m185.606564 582.393436h-70.393436c-12.813128 0-19.219692 6.406564-19.219692 19.219692v108.780308c0 6.406564-6.380308 12.813128-12.786872 12.813128H428.767179c-6.406564 0-12.786872-6.406564-12.786871-12.813128V595.232821c0-6.406564-6.406564-19.219692-19.193436-19.219693H326.367179c-6.380308 6.406564-6.380308 0-6.380307 0l179.173743-172.767179c6.406564-6.406564 12.813128-6.406564 19.219693 0l185.606564 172.767179s0 6.406564-6.406564 6.406564z m6.406564-217.586872H320.013128c-19.219692 0-32.032821-12.813128-32.03282-32.006564 0-19.193436 12.813128-32.006564 32.03282-32.006564h383.973744c19.219692 0 32.032821 12.813128 32.03282 32.006564 0 19.193436-12.813128 32.006564-32.03282 32.006564z","p-id":"7468",fill:"#bfbfbf"})}),ts=t.jsx("svg",{children:t.jsx("path",{d:"M213.333333 245.333333A32 32 0 0 0 181.333333 277.333333a32 32 0 0 0 32 32h85.333334a32 32 0 0 0 32-32 32 32 0 0 0-32-32z m256 0a32 32 0 0 0-32 32 32 32 0 0 0 32 32h85.333334a32 32 0 0 0 32-32 32 32 0 0 0-32-32z m256 0a32 32 0 0 0-32 32 32 32 0 0 0 32 32h85.333334a32 32 0 0 0 32-32 32 32 0 0 0-32-32z m-512 469.333334A32 32 0 0 0 181.333333 746.666667a32 32 0 0 0 32 32h85.333334a32 32 0 0 0 32-32 32 32 0 0 0-32-32z m256 0a32 32 0 0 0-32 32 32 32 0 0 0 32 32h85.333334a32 32 0 0 0 32-32 32 32 0 0 0-32-32z m256 0a32 32 0 0 0-32 32 32 32 0 0 0 32 32h85.333334a32 32 0 0 0 32-32 32 32 0 0 0-32-32z m-576-234.666667A32 32 0 0 0 117.333333 512 32 32 0 0 0 149.333333 544h725.333334a32 32 0 0 0 32-32 32 32 0 0 0-32-32z","p-id":"6803",fill:"#bfbfbf"})}),os=t.jsxs("svg",{children:[t.jsx("path",{d:"M928.028444 64H96.028444c-19.228444 0-32.028444 12.8-32.028444 32.028444v831.943112c0 19.228444 12.8 32.028444 32.028444 32.028444h831.943112c19.228444 0 32.028444-12.8 32.028444-32.028444V96.028444c0-19.171556-12.8-31.971556-32.028444-31.971555zM896 896H128V128h768v768z",fill:"#bfbfbf","p-id":"11004"}),t.jsx("path",{d:"M769.080889 536.803556v191.829333H349.582222l74.638222 66.104889-44.145777 47.217778-150.414223-143.416889 0.512-0.568889-0.568888-0.568889L380.131556 537.6l46.876444 43.235556-77.368889 82.659555h354.133333V536.803556h65.365334z m-213.504-100.124445v150.641778H487.537778V436.622222h68.039111z m95.288889-264.419555l147.683555 151.324444-0.568889 0.512 0.568889 0.568889-147.683555 155.306667-45.852445-45.795556 72.476445-74.126222H315.960889V485.262222H247.580444V293.432889h429.909334l-74.922667-75.264 48.298667-45.909333z",fill:"#bfbfbf","p-id":"11005"})]}),ns=t.jsx("svg",{children:t.jsx("path",{d:"M583.232 493.76a23.68 23.68 0 0 1 23.232 0l212.992 119.936a23.68 23.68 0 0 1 12.032 20.608v246.144a23.68 23.68 0 0 1-12.032 20.608l-212.992 119.936a23.68 23.68 0 0 1-23.232 0l-212.992-119.936a23.68 23.68 0 0 1-12.032-20.608V634.304a23.68 23.68 0 0 1 12.032-20.608z m11.584 47.808l-189.312 106.56v218.496l189.312 106.56 189.312-106.56v-218.496z m143.936 110.976a19.2 19.2 0 0 1 25.088 7.616l0.32 0.64a19.2 19.2 0 0 1-7.616 25.088l-141.248 79.104v164.608a19.2 19.2 0 0 1-19.2 18.24h-1.6a19.2 19.2 0 0 1-19.2-18.24v-164.608l-141.248-79.104a19.2 19.2 0 0 1-7.616-25.088l0.32-0.64a19.2 19.2 0 0 1 25.088-7.616l0.64 0.32 142.464 79.808 142.464-79.808zM620.8 0a356.608 356.608 0 0 1 354.88 321.536l0.448 5.12h1.984a277.76 277.76 0 0 1 245.888 271.296v4.608a277.696 277.696 0 0 1-273.088 277.632h-44.8a41.024 41.024 0 0 1-0.96-82.048h40.96a195.648 195.648 0 0 0 3.264-391.296h-13.312a41.024 41.024 0 0 1-41.024-40.32V358.4v-1.792a274.56 274.56 0 0 0-270.016-274.496H595.2a274.56 274.56 0 0 0-274.496 270.016v14.144a41.024 41.024 0 0 1-40.064 41.024h-2.944a195.648 195.648 0 0 0-3.264 391.296h10.496a41.024 41.024 0 0 1 0.96 82.048h-8.192a277.696 277.696 0 0 1-40.64-552.448l2.752-0.384v-0.384A356.608 356.608 0 0 1 589.312 0h32z",fill:"#bfbfbf","p-id":"4282"})}),rs=t.jsxs("svg",{children:[t.jsx("path",{d:"M1016.992 652l-256-320c-6.08-7.584-15.264-12-24.992-12l-448 0c-9.728 0-18.912 4.416-24.992 12l-256 320c-4.544 5.664-7.008 12.736-7.008 20l0 288c0 35.36 28.64 64 64 64l896 0c35.36 0 64-28.64 64-64l0-288c0-7.264-2.464-14.304-7.008-20zM960 704l-224 0-128 128-192 0-128-128-224 0 0-20.768 239.392-299.232 417.248 0 239.392 299.232 0 20.768z",fill:"#bfbfbf","p-id":"4269"}),t.jsx("path",{d:"M736 512l-448 0c-17.664 0-32-14.336-32-32s14.336-32 32-32l448 0c17.664 0 32 14.336 32 32s-14.336 32-32 32z",fill:"#bfbfbf","p-id":"4270"}),t.jsx("path",{d:"M800 640l-576 0c-17.664 0-32-14.336-32-32s14.336-32 32-32l576 0c17.664 0 32 14.336 32 32s-14.336 32-32 32z",fill:"#bfbfbf","p-id":"4271"})]}),as=t.jsxs("svg",{children:[t.jsx("path",{d:"M0 320m64 0l896 0q64 0 64 64l0 384q0 64-64 64l-896 0q-64 0-64-64l0-384q0-64 64-64Z",fill:"#ABD0FF","p-id":"15681"}),t.jsx("path",{d:"M172.416 640v-105.6h40.32v-28.992H97.344v28.992H137.28V640h35.136z m118.656 1.536c41.664 0 72.768-29.568 72.768-68.928 0-38.976-31.104-68.16-72.768-68.16s-72.768 28.992-72.768 68.16c0 39.36 31.104 68.928 72.768 68.928z m0.384-29.952c-19.968 0-37.056-16.896-37.056-38.784 0-21.888 16.896-38.4 37.056-38.4 20.16 0 36.288 16.512 36.288 38.4 0 21.888-16.128 38.784-36.288 38.784z m153.984 29.952c41.664 0 72.768-29.568 72.768-68.928 0-38.976-31.104-68.16-72.768-68.16s-72.768 28.992-72.768 68.16c0 39.36 31.104 68.928 72.768 68.928z m0.384-29.952c-19.968 0-37.056-16.896-37.056-38.784 0-21.888 16.896-38.4 37.056-38.4 20.16 0 36.288 16.512 36.288 38.4 0 21.888-16.128 38.784-36.288 38.784zM627.84 640v-29.952h-57.024v-104.64H535.68V640h92.16z m79.296 0v-105.6h40.32v-28.992h-115.392v28.992H672V640h35.136z m89.664 0v-134.592h-35.136V640H796.8z m61.248 0v-37.248h24c34.368 0 54.144-18.432 54.144-50.112 0-29.952-19.776-47.232-54.144-47.232h-59.136V640h35.136z m22.272-65.28h-22.272v-41.28h22.272c14.208 0 22.464 7.104 22.464 20.352 0 13.632-8.256 20.928-22.464 20.928z",fill:"#FFFFFF","p-id":"15682"}),t.jsx("path",{d:"M352 381.568l125.28-133.76a32 32 0 0 1 47.808 1.248l111.84 132.48H352z",fill:"#ABD0FF","p-id":"15683"})]}),is=t.jsxs("svg",{children:[t.jsx("path",{d:"M917.333 85.333H106.667C47.85 85.333 0 133.184 0 192v597.333C0 848.15 47.85 896 106.667 896h810.666C976.15 896 1024 848.15 1024 789.333V192c0-58.816-47.85-106.667-106.667-106.667zM106.667 128h810.666c35.286 0 64 28.715 64 64v106.667H42.667V192c0-35.285 28.714-64 64-64z m810.666 725.333H106.667c-35.286 0-64-28.714-64-64v-448h938.666v448c0 35.286-28.714 64-64 64z","p-id":"7124",fill:"#bfbfbf"}),t.jsx("path",{d:"M128 213.333a42.667 42.667 0 1 0 85.333 0 42.667 42.667 0 1 0-85.333 0z m128 0a42.667 42.667 0 1 0 85.333 0 42.667 42.667 0 1 0-85.333 0z m128 0a42.667 42.667 0 1 0 85.333 0 42.667 42.667 0 1 0-85.333 0z","p-id":"7125",fill:"#bfbfbf"})]}),ss=t.jsx("svg",{children:t.jsx("path",{d:"M64 192h896v576H621.248L512 877.248 402.752 768H64V192z m64 64v448h301.248L512 786.752 594.752 704H896V256H128z m512 256h192v96h-192v-96z m-96 64v-32h-128v32h128z m-160 32v-96h192v96h-192z m-64-256h512v64H320v-64z m-64 0H192v64h64v-64z","p-id":"8201",fill:"#bfbfbf"})}),ls=t.jsxs("svg",{children:[t.jsx("path",{d:"M234.88 179.328L349.653333 85.333333l115.2 93.994667 375.68 0.042667a72.533333 72.533333 0 0 1 72.533334 72.533333v597.333333a72.533333 72.533333 0 0 1-72.533334 72.533334h-682.666666a72.533333 72.533333 0 0 1-72.533334-72.533334v-597.333333l0.256-6.229333A72.533333 72.533333 0 0 1 157.866667 179.370667h77.013333z m208.64 59.776L349.738667 162.474667 256.170667 239.104H157.866667a12.8 12.8 0 0 0-12.8 12.8v597.333333a12.8 12.8 0 0 0 12.8 12.8h682.666666a12.8 12.8 0 0 0 12.8-12.8v-597.333333a12.8 12.8 0 0 0-12.8-12.8h-397.013333z",fill:"#333333","p-id":"23327"}),t.jsx("path",{d:"M712.533333 425.386667v59.733333h-426.666666v-59.733333z",fill:"#333333","p-id":"23328"}),t.jsx("path",{d:"M712.533333 638.72v59.733333h-426.666666v-59.733333z",fill:"#52BF63","p-id":"23329"})]}),ps=t.jsxs("svg",{children:[t.jsx("path",{d:"M256 529.066667H85.333333a17.066667 17.066667 0 1 1 0-34.133334h170.666667a17.066667 17.066667 0 0 1 0 34.133334z",opacity:".278","p-id":"29819",fill:"#bfbfbf"}),t.jsx("path",{d:"M99.84 640a17.066667 17.066667 0 0 1-4.437333-33.553067l164.693333-44.373333a17.066667 17.066667 0 1 1 8.891733 32.9728l-164.693333 44.373333a17.544533 17.544533 0 0 1-4.4544 0.580267z",opacity:".322","p-id":"29820",fill:"#bfbfbf"}),t.jsx("path",{d:"M264.533333 462.523733a16.896 16.896 0 0 1-4.369066-0.580266l-164.693334-43.52a17.0496 17.0496 0 1 1 8.721067-32.989867l164.693333 43.52a17.066667 17.066667 0 1 1-4.352 33.570133z",opacity:".239","p-id":"29821",fill:"#bfbfbf"}),t.jsx("path",{d:"M384.017067 307.2a17.032533 17.032533 0 0 1-14.7968-8.533333l-85.333334-147.626667a17.066667 17.066667 0 0 1 29.559467-17.083733l85.333333 147.626666A17.066667 17.066667 0 0 1 384.017067 307.2z",opacity:".122","p-id":"29822",fill:"#bfbfbf"}),t.jsx("path",{d:"M639.982933 307.2a17.0496 17.0496 0 0 1-14.762666-25.6l85.333333-147.626667a17.066667 17.066667 0 1 1 29.559467 17.066667l-85.333334 147.626667a17.032533 17.032533 0 0 1-14.7968 8.533333z",opacity:".922","p-id":"29823",fill:"#bfbfbf"}),t.jsx("path",{d:"M692.906667 347.306667a17.066667 17.066667 0 0 1-12.117334-29.098667l120.337067-121.173333a17.066667 17.066667 0 1 1 24.234667 24.046933l-120.337067 121.173333a17.1008 17.1008 0 0 1-12.117333 5.051734z",opacity:".878","p-id":"29824",fill:"#bfbfbf"}),t.jsx("path",{d:"M733.883733 401.066667a17.066667 17.066667 0 0 1-8.5504-31.8464l147.626667-85.333334a17.0496 17.0496 0 1 1 17.066667 29.5424l-147.626667 85.333334a16.776533 16.776533 0 0 1-8.516267 2.304z",opacity:".839","p-id":"29825",fill:"#bfbfbf"}),t.jsx("path",{d:"M512 273.066667a17.066667 17.066667 0 0 1-17.066667-17.066667V85.333333a17.066667 17.066667 0 0 1 34.133334 0v170.666667a17.066667 17.066667 0 0 1-17.066667 17.066667z","p-id":"29826",fill:"#bfbfbf"}),t.jsx("path",{d:"M578.577067 281.6a17.066667 17.066667 0 0 1-16.520534-21.418667l43.52-164.693333a17.066667 17.066667 0 0 1 33.006934 8.721067l-43.52 164.693333a17.066667 17.066667 0 0 1-16.4864 12.6976z",opacity:".961","p-id":"29827",fill:"#bfbfbf"}),t.jsx("path",{d:"M445.44 282.453333a17.066667 17.066667 0 0 1-16.469333-12.629333l-44.373334-164.693333a17.066667 17.066667 0 0 1 32.955734-8.891734l44.373333 164.693334a17.066667 17.066667 0 0 1-16.4864 21.521066z",opacity:".078","p-id":"29828",fill:"#bfbfbf"}),t.jsx("path",{d:"M924.177067 640c-1.4848 0-2.9696-0.187733-4.4544-0.580267l-164.693334-44.373333a17.066667 17.066667 0 0 1 8.874667-32.9728l164.693333 44.373333a17.066667 17.066667 0 0 1-4.420266 33.553067z",opacity:".722","p-id":"29829",fill:"#bfbfbf"}),t.jsx("path",{d:"M881.476267 742.4a17.015467 17.015467 0 0 1-8.482134-2.269867l-148.48-85.333333a17.0496 17.0496 0 1 1 16.9984-29.5936l148.48 85.333333a17.0496 17.0496 0 0 1-8.516266 31.863467z",opacity:".678","p-id":"29830",fill:"#bfbfbf"}),t.jsx("path",{d:"M813.226667 830.293333a17.015467 17.015467 0 0 1-12.066134-5.000533l-120.337066-120.337067a17.0496 17.0496 0 1 1 24.132266-24.132266l120.337067 120.337066a17.0496 17.0496 0 0 1-12.066133 29.1328z",opacity:".639","p-id":"29831",fill:"#bfbfbf"}),t.jsx("path",{d:"M938.666667 529.066667H768a17.066667 17.066667 0 1 1 0-34.133334h170.666667a17.066667 17.066667 0 1 1 0 34.133334z",opacity:".761","p-id":"29832",fill:"#bfbfbf"}),t.jsx("path",{d:"M401.066667 941.226667a17.066667 17.066667 0 0 1-16.4864-21.504l44.373333-164.693334a17.066667 17.066667 0 1 1 32.955733 8.874667l-44.373333 164.693333a17.066667 17.066667 0 0 1-16.469333 12.629334z",opacity:".478","p-id":"29833",fill:"#bfbfbf"}),t.jsx("path",{d:"M298.6496 898.56a17.066667 17.066667 0 0 1-14.779733-25.565867l85.333333-148.48a17.083733 17.083733 0 0 1 29.5936 16.9984l-85.333333 148.48a17.032533 17.032533 0 0 1-14.813867 8.567467z",opacity:".439","p-id":"29834",fill:"#bfbfbf"}),t.jsx("path",{d:"M512 955.733333a17.066667 17.066667 0 0 1-17.066667-17.066666V768a17.066667 17.066667 0 1 1 34.133334 0v170.666667a17.066667 17.066667 0 0 1-17.066667 17.066666z",opacity:".522","p-id":"29835",fill:"#bfbfbf"}),t.jsx("path",{d:"M725.3504 898.56a17.032533 17.032533 0 0 1-14.7968-8.533333l-85.333333-147.626667a17.066667 17.066667 0 0 1 29.559466-17.066667l85.333334 147.626667a17.066667 17.066667 0 0 1-14.762667 25.6z",opacity:".6","p-id":"29836",fill:"#bfbfbf"}),t.jsx("path",{d:"M622.062933 942.08c-7.509333 0-14.421333-5.0176-16.469333-12.629333l-44.3904-164.693334a17.066667 17.066667 0 1 1 32.9728-8.874666l44.3904 164.693333a17.066667 17.066667 0 0 1-16.503467 21.504z",opacity:".561","p-id":"29837",fill:"#bfbfbf"}),t.jsx("path",{d:"M759.4496 463.36a17.083733 17.083733 0 0 1-4.420267-33.553067l164.693334-44.373333a17.066667 17.066667 0 0 1 8.874666 32.955733l-164.693333 44.373334a16.657067 16.657067 0 0 1-4.4544 0.597333z",opacity:".702","p-id":"29838",fill:"#bfbfbf"}),t.jsx("path",{d:"M330.24 347.306667a17.015467 17.015467 0 0 1-12.066133-5.000534l-120.32-120.32a17.0496 17.0496 0 1 1 24.132266-24.132266l120.32 120.32a17.0496 17.0496 0 0 1-12.066133 29.1328z",opacity:".161","p-id":"29839",fill:"#bfbfbf"}),t.jsx("path",{d:"M290.116267 401.066667a17.032533 17.032533 0 0 1-8.533334-2.286934l-147.626666-85.333333a17.066667 17.066667 0 1 1 17.083733-29.5424l147.626667 85.333333a17.066667 17.066667 0 0 1-8.5504 31.829334z",opacity:".2","p-id":"29840",fill:"#bfbfbf"}),t.jsx("path",{d:"M142.523733 742.4a17.066667 17.066667 0 0 1-8.567466-31.8464l147.626666-85.333333a17.066667 17.066667 0 1 1 17.083734 29.559466l-147.626667 85.333334a16.930133 16.930133 0 0 1-8.516267 2.286933z",opacity:".361","p-id":"29841",fill:"#bfbfbf"}),t.jsx("path",{d:"M209.92 830.293333a17.066667 17.066667 0 0 1-12.117333-29.098666l120.32-121.173334a17.066667 17.066667 0 0 1 24.2176 24.029867l-120.32 121.1904a16.896 16.896 0 0 1-12.100267 5.051733z",opacity:".4","p-id":"29842",fill:"#bfbfbf"})]}),cs=t.jsx("svg",{children:t.jsx("path",{d:"M1006.933333 0H614.4c-3.413333 0-10.24 3.413333-13.653333 3.413333L3.413333 600.746667c-6.826667 6.826667-6.826667 17.066667 0 23.893333l392.533334 392.533333c3.413333 3.413333 6.826667 3.413333 13.653333 3.413334 3.413333 0 10.24-3.413333 13.653333-6.826667l597.333334-614.4c3.413333-3.413333 3.413333-6.826667 3.413333-10.24V13.653333c0-6.826667-6.826667-13.653333-17.066667-13.653333zM785.066667 341.333333c-58.026667 0-102.4-44.373333-102.4-102.4s44.373333-102.4 102.4-102.4 102.4 44.373333 102.4 102.4-44.373333 102.4-102.4 102.4z",fill:"#bfbfbf","p-id":"34485"})}),ds=t.jsx("svg",{children:t.jsx("path",{d:"M992 64 768 64c-52.8 0-126.56 30.56-163.872 67.872L227.872 508.128c-37.344 37.344-37.344 98.432 0 135.776l280.224 280.224c37.344 37.344 98.432 37.344 135.776 0l376.224-376.224C1057.44 510.56 1088 436.8 1088 384L1088 160C1088 107.2 1044.8 64 992 64zM864 384c-53.024 0-96-42.976-96-96s42.976-96 96-96 96 42.976 96 96S917.024 384 864 384zM86.624 598.624 428.992 940.992C392.736 960.16 346.528 954.528 316.128 924.128L35.872 643.872C-1.44 606.56-1.44 545.44 35.872 508.128L412.128 131.872C449.44 94.56 523.2 64 576 64L86.624 553.376C74.176 565.824 74.176 586.176 86.624 598.624Z",fill:"#bfbfbf","p-id":"34275"})}),ms=t.jsxs("svg",{children:[t.jsx("path",{d:"M928 2H98c-52.944 0-96 43.056-96 96V928c0 52.944 43.056 96 96 96H928c52.944 0 96-43.056 96-96V98c0-52.944-43.056-96-96-96zM960 928c0 17.648-14.352 32-32 32H98c-17.648 0-32-14.352-32-32V98c0-17.648 14.352-32 32-32H928c17.648 0 32 14.352 32 32V928z",fill:"#bfbfbf","p-id":"35536"}),t.jsx("path",{d:"M102 651.344h40.96v166.64h-40.96zM176.656 818h40.96v-64.368h61.792v-36.528h-61.792v-29.248h72.32v-36.512h-113.28zM439.056 704.944c0-27.392-19.92-53.6-56.88-53.6H316.16v166.64h40.96v-62.032h13.808l29.488 62.032h47.52l-36.048-69.52c13.104-6.544 27.168-20.816 27.168-43.52z m-58.768 16.848H357.12v-33.712h23.168c11.232 0 17.792 8.208 17.792 16.864s-6.544 16.848-17.792 16.848zM512.528 651.344l-60.624 166.64h42.848l8.192-24.8h51.248l7.728 24.8h42.848l-60.64-166.64h-31.6z m1.888 107.664l14.976-44.464 14.048 44.464h-29.024zM699.328 724.832l-37.456-73.488H621.6v166.656h40.976v-79.824l23.616 41.2h26.24l23.616-41.2v79.824h40.976V651.344h-40.256zM810.704 818h113.296v-36.512h-72.32v-29.264h61.792v-36.512H851.68v-27.856h72.32v-36.512h-113.296zM337.68 526.432c6.24 6.256 14.432 9.376 22.624 9.376s16.384-3.12 22.624-9.376a32 32 0 0 0 0-45.248l-102.656-102.656 102.656-102.656a32 32 0 1 0-45.248-45.248l-114.496 114.496a47.312 47.312 0 0 0 0 66.816l114.496 114.496zM802.816 345.12l-114.48-114.496a32 32 0 1 0-45.248 45.264l102.64 102.656-102.64 102.656a32 32 0 0 0 45.248 45.248l114.448-114.464c8.96-8.928 13.872-20.8 13.872-33.44s-4.928-24.528-13.84-33.424zM485.76 580.608a31.968 31.968 0 0 0 36.88-26.208l57.792-341.056a32 32 0 0 0-26.208-36.896 31.888 31.888 0 0 0-36.896 26.208l-57.792 341.056a32.032 32.032 0 0 0 26.224 36.896z",fill:"#bfbfbf","p-id":"35537"})]}),us=Object.freeze(Object.defineProperty({__proto__:null,Button:Yi,CheckableTag:ds,Div:qi,Divider:ts,Drawer:rs,DynamicSchemaBlock:ns,FloatButton:Xi,FloatButtonBackTop:es,FloatButtonGroup:_i,Iframe:ms,Img:Ki,IteratorLayout:os,Modal:is,Popconfirm:ss,Popover:ls,QRCode:Zi,Spin:ps,Tag:cs,Tooltip:as},Symbol.toStringTag,{value:"Module"}));vr("https://gitee.com/bingoogolapple/bga-god-assistant-config/raw/master/npmCDNRegistry");const{ErrorBoundary:Ze}=Or;I.registerDesignerIcons(us);I.registerDesignerLocales({"zh-CN":{sources:{Inputs:"输入控件",Layouts:"布局组件",Arrays:"自增组件",Displays:"展示组件"}},"en-US":{sources:{Inputs:"Inputs",Layouts:"Layouts",Arrays:"Arrays",Displays:"Displays"}}});const hs=()=>{const e=b.useMemo(()=>ur({shortcuts:[new hr({codes:[[we.Meta,we.S],[we.Control,we.S]],handler(n){Vr(n.engine)}})],rootComponentName:"Form"}),[]),o=b.useCallback(async()=>{try{await Ge.init(),window.$editorContext={$utils:$n,$ga:Ge,$chrome:Ge.chrome};const n=await Yr();e.setCurrentTree(n)}catch(n){Dn.error("lowcode-editor init error",n)}},[]);return b.useEffect(()=>{o()},[]),t.jsx(Mn,{theme:{token:{colorPrimary:On}},children:t.jsx(Ln,{children:t.jsx(xr,{engine:e,children:t.jsxs(ea,{logo:t.jsx(na,{}),actions:t.jsx($r,{}),children:[t.jsxs(Ce,{children:[t.jsx(Ce.Item,{title:"panels.Component",icon:"Component",children:t.jsx(gr,{sources:Object.values({...Io})})}),t.jsx(Ce.Item,{title:"panels.OutlinedTree",icon:"Outline",children:t.jsx(fr,{})}),t.jsx(Ce.Item,{title:"panels.History",icon:"History",children:t.jsx(yr,{})})]}),t.jsx(br,{id:"form",children:t.jsx(ot,{children:t.jsxs(Ze,{children:[t.jsxs(ta,{children:[t.jsx(Sr,{}),t.jsx(Ir,{use:["DESIGNABLE","JSONTREE","MARKUP","PREVIEW"]})]}),t.jsxs(oa,{style:{height:"100%"},children:[t.jsx(Fe,{type:"DESIGNABLE",children:()=>t.jsx(wr,{components:{...Io}})}),t.jsx(Fe,{type:"JSONTREE",scrollable:!1,children:(n,r)=>t.jsx(ra,{tree:n,onChange:r})}),t.jsx(Fe,{type:"MARKUP",scrollable:!1,children:n=>t.jsx(ia,{tree:n})}),t.jsx(Fe,{type:"PREVIEW",children:n=>t.jsx(Ze,{children:t.jsx(Mr,{tree:n})})})]})]})})}),t.jsx(Cr,{title:"panels.PropertySettings",children:t.jsx(Ze,{children:t.jsx(Fr,{uploadAction:"https://www.mocky.io/v2/5cc8019d300000980a055e76"})})})]})})})})};Vn.createRoot(document.getElementById("root")).render(t.jsx(hs,{}));
