import{i as e,n as t}from"./rolldown-runtime.js";import{n}from"./logger.js";import{$ as r,A as i,D as a,N as o,d as s,j as c,kt as l,n as ee,t as te,vi as ne,wn as re,xi as ie,xt as u,y as ae,yi as oe}from"./i18n.js";import{M as se,y as ce}from"./image.js";import{$ as le,$n as ue,$t as de,A as fe,An as pe,At as me,B as he,Bn as ge,Bt as d,C as _e,Cn as ve,D as ye,Dn as be,Dt as xe,E as f,En as Se,F as Ce,Fn as we,Ft as Te,G as Ee,Gt as p,H as De,Hn as Oe,Ht as m,I as ke,In as Ae,It as je,J as Me,Jn as Ne,Jt as Pe,K as Fe,Kt as Ie,L as Le,Ln as Re,Lt as ze,M as Be,Mn as Ve,Mt as He,N as Ue,Nn as We,Nt as Ge,O as Ke,On as qe,Ot as Je,P as Ye,Pn as Xe,Pt as Ze,Q as h,Qn as Qe,Qt as g,R as $e,Rn as et,Rt as tt,S as nt,Sn as rt,T as it,Tn as at,Tt as ot,U as st,Un as ct,Ut as lt,V as ut,Vn as dt,Vt as ft,W as pt,Wn as mt,Wt as ht,X as gt,Xn as _t,Xt as _,Y as vt,Yn as yt,Yt as bt,Z as xt,Zn as St,Zt as v,_n as Ct,a as wt,an as y,at as Tt,b as Et,bn as Dt,cn as b,dn as Ot,en as kt,er as At,et as jt,fn as Mt,gn as Nt,hn as Pt,i as Ft,in as x,it as It,j as Lt,jn as Rt,jt as zt,k as Bt,kn as Vt,kt as Ht,ln as S,mn as Ut,n as Wt,nn as Gt,nt as Kt,o as qt,on as Jt,ot as Yt,pn as Xt,q as Zt,qn as Qt,qt as $t,r as en,rn as tn,rt as nn,s as rn,sn as C,st as an,t as on,tn as sn,tt as cn,un as w,vn as ln,w as un,wn as dn,wt as fn,x as pn,xn as mn,yn as hn,z as gn,zn as _n,zt as vn}from"./widgets.js";import{A as T,B as yn,E as bn,F as xn,I as Sn,J as Cn,O as wn,P as Tn,U as En,_ as Dn,f as On,g as kn,i as An,j as jn,k as Mn,r as Nn,s as Pn,u as Fn}from"./lowCodeApi.js";var E=e(ie(),1),In=e(oe(),1),D=a(),Ln=x(e=>(0,D.jsx)(d,{children:e.children})),Rn=e=>t=>(0,D.jsx)(d,{children:(0,D.jsx)(e,{...t})}),zn={"zh-CN":{settings:{style:{width:`宽度`,height:`高度`,display:`展示`,background:`背景`,boxShadow:`阴影`,font:`字体`,margin:`外边距`,padding:`内边距`,borderRadius:`圆角`,border:`边框`,opacity:`透明度`}}},"en-US":{settings:{style:{width:`Width`,height:`Height`,display:`Display`,background:`Background`,boxShadow:`Box Shadow`,font:`Font`,margin:`Margin`,padding:`Padding`,borderRadius:`Radius`,border:`Border`,opacity:`Opacity`}}}},Bn={"zh-CN":{settings:{name:`字段标识`,title:`标题`,required:`必填`,description:`描述`,default:`默认值`,enum:`可选项`,"x-display":{title:`展示状态`,tooltip:`半隐藏只会隐藏UI，全隐藏会删除数据`,dataSource:[`显示`,`半隐藏`,`全隐藏`,`继承`]},"x-pattern":{title:`UI形态`,dataSource:[`可编辑`,`禁用`,`只读`,`阅读`,`继承`]},"x-validator":`校验规则`,"x-decorator":`容器组件`,"x-reactions":`响应器规则`,"field-group":`字段属性`,"component-group":`组件属性`,"decorator-group":`容器属性`,"component-style-group":`组件样式`,"decorator-style-group":`容器样式`,"x-component-props":{size:{title:`尺寸`,dataSource:[`大`,`小`,`默认`,`继承`]},allowClear:`允许清除内容`,autoFocus:`自动获取焦点`,showSearch:`支持搜索`,notFoundContent:`空状态内容`,bordered:`是否有边框`,placeholder:`占位提示`,style:{width:`宽度`,height:`高度`,display:`展示`,background:`背景`,boxShadow:`阴影`,font:`字体`,margin:`外边距`,padding:`内边距`,borderRadius:`圆角`,border:`边框`,opacity:`透明度`}},"x-decorator-props":{addonAfter:`后缀标签`,addonBefore:`前缀标签`,tooltip:`提示`,asterisk:`星号`,gridSpan:`网格跨列`,labelCol:`标签网格宽度`,wrapperCol:`组件网格宽度`,colon:`是否有冒号`,labelAlign:{title:`标签对齐`,dataSource:[`左对齐`,`右对齐`,`继承`]},wrapperAlign:{title:`组件对齐`,dataSource:[`左对齐`,`右对齐`,`继承`]},labelWrap:`标签换行`,wrapperWrap:`组件换行`,labelWidth:`标签宽度`,wrapperWidth:`组件宽度`,fullness:`组件占满`,inset:`内联布局`,shallow:`是否浅传递`,bordered:`是否有边框`,size:{title:`尺寸`,dataSource:[`大`,`小`,`默认`,`继承`]},layout:{title:`布局`,dataSource:[`垂直`,`水平`,`内联`,`继承`]},feedbackLayout:{title:`反馈布局`,dataSource:[`宽松`,`紧凑`,`弹层`,`无`,`继承`]},tooltipLayout:{title:`提示布局`,dataSource:[`图标`,`文本`,`继承`]},style:{width:`宽度`,height:`高度`,display:`展示`,background:`背景`,boxShadow:`阴影`,font:`字体`,margin:`外边距`,padding:`内边距`,borderRadius:`圆角`,border:`边框`,opacity:`透明度`}}}},"en-US":{settings:{name:`Name`,title:`Title`,required:`Required`,description:`Description`,default:`Default`,enum:`Options`,"x-display":{title:`Display State`,tooltip:`When the display value is "None", the data will be "Hidden" and deleted. When the display value is hidden, only the UI will be hidden`,dataSource:[`Visible`,`Hidden`,`None`,`Inherit`]},"x-pattern":{title:`UI Pattern`,dataSource:[`Editable`,`Disabled`,`ReadOnly`,`ReadPretty`,`Inherit`]},"x-validator":`Validator`,"x-decorator":`Decorator`,"x-reactions":`Reactions`,"field-group":`Field Properties`,"component-group":`Component Properties`,"decorator-group":`Decorator Properties`,"component-style-group":`Component Style`,"decorator-style-group":`Decorator Style`,"x-component-props":{size:{title:`Size`,dataSource:[`Large`,`Small`,`Default`,`Inherit`]},allowClear:`Allow Clear`,autoFocus:`Auto Focus`,showSearch:`Show Search`,notFoundContent:`Not Found Content`,bordered:`Bordered`,placeholder:`Placeholder`,style:{width:`Width`,height:`Height`,display:`Display`,background:`Background`,boxShadow:`Box Shadow`,font:`Font`,margin:`Margin`,padding:`Padding`,borderRadius:`Radius`,border:`Border`,opacity:`Opacity`}},"x-decorator-props":{addonAfter:`Addon After`,addonBefore:`Addon Before`,tooltip:`Tooltip`,asterisk:`Asterisk`,gridSpan:`Grid Span`,labelCol:`Label Col`,wrapperCol:`Wrapper Col`,colon:`Colon`,labelAlign:{title:`Label Align`,dataSource:[`Left`,`Right`,`Inherit`]},wrapperAlign:{title:`Wrapper Align`,dataSource:[`Left`,`Right`,`Inherit`]},labelWrap:`Label Wrap`,wrapperWrap:`Wrapper Wrap`,labelWidth:`Label Width`,wrapperWidth:`Wrapper Width`,fullness:`Fullness`,inset:`Inset`,shallow:`Shallow`,bordered:`Bordered`,size:{title:`Size`,dataSource:[`Large`,`Small`,`Default`,`Inherit`]},layout:{title:`Layout`,dataSource:[`Vertical`,`Horizontal`,`Inline`,`Inherit`]},feedbackLayout:{title:`Feedback Layout`,dataSource:[`Loose`,`Terse`,`Popup`,`None`,`Inherit`]},tooltipLayout:{title:`Tooltip Layout`,dataSource:[`Icon`,`Text`,`Inherit`]},style:{width:`Width`,height:`Height`,display:`Display`,background:`Background`,boxShadow:`Box Shadow`,font:`Font`,margin:`Margin`,padding:`Padding`,borderRadius:`Radius`,border:`Border`,opacity:`Opacity`}}}}},Vn={"zh-CN":{title:`输入框`,settings:{"x-component-props":{addonAfter:`后缀标签`,addonBefore:`前缀标签`,maxLength:`最大长度`,prefix:`前缀`,suffix:`后缀`,autoSize:{title:`自适应高度`,tooltip:`可设置为 true | false 或对象：{ minRows: 2, maxRows: 6 }`},showCount:`是否展示字数`,checkStrength:`检测强度`}}},"en-US":{title:`Input`,settings:{"x-component-props":{addonAfter:`Addon After`,addonBefore:`Addon Before`,maxLength:`Max Length`,prefix:`Prefix`,suffix:`Suffix`,autoSize:`Auto Size`,showCount:`Show Count`,checkStrength:`Check Strength`}}}},Hn={"zh-CN":{title:`选择框`,settings:{"x-component-props":{mode:{title:`模式`,dataSource:[`多选`,`标签`,`单选`]},autoClearSearchValue:{title:`选中自动清除`,tooltip:`仅在多选或者标签模式下支持`},defaultActiveFirstOption:`默认高亮第一个选项`,dropdownMatchSelectWidth:{title:`下拉菜单和选择器同宽`,tooltip:`默认将设置 min-width，当值小于选择框宽度时会被忽略。false 时会关闭虚拟滚动`},defaultOpen:`默认展开`,filterOption:`选项筛选器`,filterSort:`选项排序器`,labelInValue:{title:`标签值`,tooltip:`是否把每个选项的 label 包装到 value 中，会把 Select 的 value 类型从 string 变为 { value: string, label: ReactNode } 的格式`},listHeight:`弹窗滚动高度`,maxTagCount:{title:`最多标签数量`,tooltip:`最多显示多少个 tag，响应式模式会对性能产生损耗`},maxTagPlaceholder:{title:`最多标签占位`,tooltip:`隐藏 tag 时显示的内容`},maxTagTextLength:`最多标签文本长度`,showArrow:`显示箭头`,virtual:`开启虚拟滚动`}}},"en-US":{title:`Select`,settings:{"x-component-props":{mode:{title:`Mode`,dataSource:[`Multiple`,`Tags`,`Single`]},autoClearSearchValue:{title:`Auto Clear Search Value`,tooltip:`Only used to multiple and tags mode`},defaultActiveFirstOption:`Default Active First Option`,dropdownMatchSelectWidth:`Dropdown Match Select Width`,defaultOpen:`Default Open`,filterOption:`Filter Option`,filterSort:`Filter Sort`,labelInValue:`label InValue`,listHeight:`List Height`,maxTagCount:`Max Tag Count`,maxTagPlaceholder:{title:`Max Tag Placeholder`,tooltip:`Content displayed when tag is hidden`},maxTagTextLength:`Max Tag Text Length`,showArrow:`Show Arrow`,virtual:`Use Virtual Scroll`}}}},Un={"zh-CN":{title:`多行输入`,settings:{"x-component-props":{maxLength:`最大长度`,autoSize:{title:`自适应高度`,tooltip:`可设置为 true | false 或对象：{ minRows: 2, maxRows: 6 }`},showCount:`是否展示字数`}}},"en-US":{title:`TextArea`,settings:{"x-component-props":{maxLength:`Max Length`,autoSize:`Auto Size`,showCount:`Show Count`}}}},Wn={"zh-CN":{title:`树选择`,settings:{"x-component-props":{mode:{title:`模式`,dataSource:[`多选`,`标签`,`单选`]},autoClearSearchValue:{title:`选中自动清除`,tooltip:`仅在多选或者标签模式下支持`},defaultActiveFirstOption:`默认高亮第一个选项`,defaultOpen:`默认展开`,filterOption:`选项筛选器`,filterSort:`选项排序器`,labelInValue:{title:`标签值`,tooltip:`是否把每个选项的 label 包装到 value 中，会把 Select 的 value 类型从 string 变为 { value: string, label: ReactNode } 的格式`},listHeight:`弹窗滚动高度`,maxTagCount:{title:`最多标签数量`,tooltip:`最多显示多少个 tag，响应式模式会对性能产生损耗`},maxTagPlaceholder:{title:`最多标签占位`,tooltip:`隐藏 tag 时显示的内容`},maxTagTextLength:`最多标签文本长度`,showArrow:`显示箭头`,virtual:`开启虚拟滚动`,dropdownMatchSelectWidth:{title:`下拉选择器同宽`,tooltip:`默认将设置 min-width，当值小于选择框宽度时会被忽略。false 时会关闭虚拟滚动`},showCheckedStrategy:{title:`复选回显策略`,tooltip:`配置 treeCheckable 时，定义选中项回填的方式。TreeSelect.SHOW_ALL: 显示所有选中节点(包括父节点)。TreeSelect.SHOW_PARENT: 只显示父节点(当父节点下所有子节点都选中时)。 默认只显示子节点`,dataSource:[`显示所有`,`显示父节点`,`显示子节点`]},treeCheckable:`开启复选`,treeDefaultExpandAll:`默认展开所有`,treeDefaultExpandedKeys:{title:`默认展开选项`,tooltip:`格式：Array<string | number>`},treeNodeFilterProp:{title:`节点过滤属性`,tooltip:`输入项过滤对应的 treeNode 属性`},treeDataSimpleMode:{title:`使用简单数据结构`,tooltip:`使用简单格式的 treeData，具体设置参考可设置的类型 (此时 treeData 应变为这样的数据结构: [{id:1, pId:0, value:'1', title:"test1",...},...]， pId 是父节点的 id)`},treeNodeLabelProp:{title:`标签显示名称`,tooltip:`默认为title`},filterTreeNode:`节点过滤器`}}},"en-US":{title:`TreeSelect`,settings:{"x-component-props":{mode:{title:`Mode`,dataSource:[`Multiple`,`Tags`,`Single`]},autoClearSearchValue:{title:`Auto Clear Search Value`,tooltip:`Only used to multiple and tags mode`},defaultActiveFirstOption:`Default Active First Option`,defaultOpen:`Default Open`,filterOption:`Filter Option`,filterSort:`Filter Sort`,labelInValue:`Label In Value`,listHeight:`List Height`,maxTagCount:`Max Tag Count`,maxTagPlaceholder:{title:`Max Tag Placeholder`,tooltip:`Content displayed when tag is hidden`},maxTagTextLength:`Max Tag Text Length`,notFoundContent:`Not Found Content`,showArrow:`Show Arrow`,virtual:`Use Virtual Scroll`,dropdownMatchSelectWidth:{title:`Dropdown Match Select Width`,tooltip:`By default, min-width will be set, and it will be ignored when the value is less than the width of the selection box. false will turn off virtual scrolling`},showCheckedStrategy:{title:`Show Checked Strategy`,tooltip:`When configuring treeCheckable, define how to backfill the selected item. TreeSelect.SHOW_ALL: Show all selected nodes (including parent nodes). TreeSelect.SHOW_PARENT: Only display the parent node (when all child nodes under the parent node are selected). Only show child nodes by default`,dataSource:[`Show All`,`Show Parent Node`,`Show Child Nodes`]},treeCheckable:`Tree Checkable`,treeDefaultExpandAll:`Tree Default Expand All`,treeDefaultExpandedKeys:{title:`Tree Default Expanded Keys`,tooltip:`Format：Array<string | number>`},treeNodeFilterProp:{title:`Tree Node Filter Properties`,tooltip:`The treeNode attribute corresponding to the input item filter`},treeDataSimpleMode:{title:`Tree Data Simple Mode`,tooltip:`Use treeData in a simple format. For specific settings, refer to the settable type (the treeData should be a data structure like this: [{id:1, pId:0, value:'1', title:"test1",...} ,...], pId is the id of the parent node)`},treeNodeLabelProp:{title:`Tree Node Label Properties`,tooltip:`The default is title`},filterTreeNode:`Filter Tree Node`}}}},Gn={"zh-CN":{title:`联级选择`,settings:{"x-component-props":{changeOnSelect:{title:`选择时触发`,tooltip:`点选每级菜单选项值都会发生变化`},displayRender:{title:`渲染函数`,tooltip:`选择后展示的渲染函数，默认为label => label.join("/")	`},fieldNames:{title:`自定义字段名`,tooltip:`默认值：{ label: "label", value: "value", children: "children" }`}}}},"en-US":{title:`Cascader`,settings:{"x-component-props":{changeOnSelect:{title:`Change On Select`,tooltip:`Click on each level of menu option value will change`},displayRender:{title:`Display Render`,tooltip:`The rendering function displayed after selection, the default is label => label.join("/")	`},fieldNames:{title:`Field Names`,tooltip:`Defaults：{ label: "label", value: "value", children: "children" }`}}}}},Kn={"zh-CN":{title:`单选框组`,settings:{"x-component-props":{buttonStyle:{title:`按钮风格`,dataSource:[`空心`,`实心`]},optionType:{title:`选项类型`,dataSource:[`默认`,`按钮`]}}}},"en-US":{title:`Radio`,settings:{"x-component-props":{buttonStyle:{title:`Button style`,dataSource:[`Hollow`,`Solid`]},optionType:{title:`Option type`,dataSource:[`Default`,`Button`]}}}}},qn={"zh-CN":{title:`复选框组`},"en-US":{title:`Checkbox`}},Jn={"zh-CN":{title:`滑动条`,settings:{"x-component-props":{dots:`刻度固定`,range:`双滑块`,reverse:`反向坐标系`,vertical:`垂直布局`,tooltipPlacement:{title:`提示位置`,tooltip:`设置 提示 展示位置。参考 Tooltip`},tooltipVisible:{title:`提示显示`,tooltip:`开启时，提示 将会始终显示；否则始终不显示，哪怕在拖拽及移入时`},max:`最大值`,min:`最小值`,step:`步长`,marks:`刻度标签`}}},"en-US":{title:`Slider`,settings:{"x-component-props":{dots:`Fixed Scale`,range:`Double Slider`,reverse:`Reverse Coordinate System`,vertical:`Vertical`,tooltipPlacement:{title:`Tooltip Placement`,tooltip:`Set up prompt placement. Reference Tooltip`},tooltipVisible:{title:`Tooltip Visible`,tooltip:`When turned on, the prompt will always be displayed; otherwise, it will always not be displayed, even when dragging and moving in`},max:`Max`,min:`Min`,step:`Step`,marks:`Marks`}}}},Yn={"zh-CN":{title:`评分器`,settings:{"x-component-props":{allowHalf:`允许半选`,tooltips:{title:`提示信息`,tooltip:`格式：string[]`},count:`总数`}}},"en-US":{title:`Rate`,settings:{"x-component-props":{allowHalf:`Allow Half`,tooltips:{title:`Tooltips`,tooltip:`Format：string[]`},count:`Count`}}}},Xn={"zh-CN":{title:`日期选择`,settings:{"x-component-props":{disabledDate:{title:`不可选日期`,tooltip:`格式 (currentDate: dayjs, info: { from?: dayjs }) => boolean`},disabledTime:{title:`不可选时间`,tooltip:`格式 (currentDate: dayjs, info: { from?: dayjs }) => boolean`},inputReadOnly:`输入框只读`,format:`格式`,picker:{title:`选择器类型`,dataSource:[`时间`,`日期`,`月份`,`年`,`季度`,`财年`]},showNow:`显示此刻`,showTime:`时间选择`,showToday:`显示今天`}}},"en-US":{title:`DatePicker`,settings:{"x-component-props":{disabledDate:{title:`Disabled Date`,tooltip:`Format (currentDate: dayjs, info: { from?: dayjs }) => boolean`},disabledTime:{title:`Disabled Time`,tooltip:`Format (currentDate: dayjs, info: { from?: dayjs }) => boolean`},inputReadOnly:`Input ReadOnly`,format:`Format`,picker:{title:`Picker Type`,dataSource:[`Time`,`Date`,`Month`,`Year`,`Quarter`,`Decade`]},showNow:`Show Now`,showTime:`Show Time`,showToday:`Show Today`}}}},Zn=C(Xn,{"zh-CN":{title:`日期范围`},"en-US":{title:`DateRange`}}),Qn=C(Xn,{"zh-CN":{title:`时间选择`,settings:{"x-component-props":{clearText:`清除提示`,disabledHours:`禁止小时`,disabledMinutes:`禁止分钟`,disabledSeconds:`禁止秒`,hideDisabledOptions:`隐藏禁止选项`,hourStep:`小时间隔`,minuteStep:`分钟间隔`,secondStep:`秒间隔`,use12Hours:`12小时制`,inputReadOnly:`输入框只读`,showNow:`显示此刻`,format:`格式`}}},"en-US":{title:`Time Picker`,settings:{"x-component-props":{clearText:`Clear Text`,disabledHours:`Disbaled Hours`,disabledMinutes:`Disabled Minutes`,disabledSeconds:`Disabled Seconds`,hideDisabledOptions:`Hide Disabled Options`,hourStep:`Hour Step`,minuteStep:`Minute Step`,secondStep:`Second Step`,use12Hours:`Use 12-hour`,inputReadOnly:`Input ReadOnly`,showNow:`Show Now`,format:`Format`}}}}),$n=C(Qn,{"zh-CN":{title:`时间范围`},"en-US":{title:`Time Range`}}),er={"zh-CN":{title:`数字输入`,settings:{"x-component-props":{formatter:{title:`格式转换器`,tooltip:`格式：function(value: number | string): string`},keyboard:`启用快捷键`,parser:{title:`格式解析器`,tooltip:`指定从 格式转换器 里转换回数字的方式，和 格式转换器 搭配使用,格式：function(string): number`},decimalSeparator:`小数点`,precision:`数字精度`,max:`最大值`,min:`最小值`,step:`步长`,stringMode:{title:`字符串格式`,tooltip:`开启后支持高精度小数。同时 onChange 将返回 string 类型`}}}},"en-US":{title:`NumberInput`,settings:{"x-component-props":{formatter:{title:`Format Converter`,tooltip:`Format：function(value: number | string): string`},keyboard:`Enable Shortcut Keys`,parser:{title:`Format Parser`,tooltip:`Specify the method of converting back to numbers from the format converter, and use it with the format converter, the format:function(string): number`},decimalSeparator:`Decimal Separator`,precision:`Precision`,max:`Max`,min:`Min`,step:`Step`,stringMode:{title:`String Format`,tooltip:`Support high-precision decimals after opening. At the same time onChange will return string type`}}}}},tr=C(Vn,{"zh-CN":{title:`密码输入`},"en-US":{title:`Password`}}),nr={"zh-CN":{title:`穿梭框`,settings:{"x-component-props":{oneWay:`单向展示`,operations:{title:`操作文案集合`,tooltip:`格式：string[]`},titles:{title:`标题集合`,tooltip:`格式：string[]`},showSearchAll:`支持全选`,filterOption:`选项筛选器`}}},"en-US":{title:`Transfer`,settings:{"x-component-props":{oneWay:`One Way`,operations:{title:`Operations`,tooltip:`Format：string[]`},titles:{title:`Titles`,tooltip:`Format：string[]`},showSearchAll:`Show Search All`,filterOption:`Filter Option`}}}},rr={"zh-CN":{title:`上传`,settings:{"x-component-props":{accept:`可接受类型`,action:`上传地址`,data:`数据/参数`,directory:`支持上传目录`,headers:`请求头`,listType:{title:`列表类型`,dataSource:[`文本`,`图片`,`卡片`]},multiple:`多选模式`,name:`字段标识`,openFileDialogOnClick:{title:`点击打开文件对话框`,tooltip:`点击打开文件对话框`},showUploadList:`是否展示文件列表`,withCredentials:`携带Cookie`,maxCount:`最大数量`,method:`方法`,textContent:`上传文案`}}},"en-US":{title:`Upload`,settings:{"x-component-props":{accept:`Accept`,action:`Upload Address`,data:`Data`,directory:`Support Upload Directory`,headers:`Headers`,listType:{title:`List Type`,dataSource:[`Text`,`Image`,`Card`]},multiple:`Multiple`,name:`Name`,openFileDialogOnClick:`Open File Dialog On Click`,showUploadList:`Show Upload List`,withCredentials:`withCredentials`,maxCount:`Max Count`,method:`Method`,textContent:`Text Content`}}}},ir=C(rr,{"zh-CN":{title:`拖拽上传`,settings:{"x-component-props":{}}},"en-US":{title:`UploadDragger`,settings:{"x-component-props":{}}}}),ar={"zh-CN":{title:`开关`},"en-US":{title:`Switch`}},or={"zh-CN":{title:`对象容器`},"en-US":{title:`Object`}},sr=C(zn,{"zh-CN":{title:`表单`,settings:{"x-reactions":`响应器规则`,labelCol:`标签网格宽度`,wrapperCol:`组件网格宽度`,colon:`是否有冒号`,labelAlign:{title:`标签对齐`,dataSource:[`左对齐`,`右对齐`,`继承`]},wrapperAlign:{title:`组件对齐`,dataSource:[`左对齐`,`右对齐`,`继承`]},labelWrap:`标签换行`,wrapperWrap:`组件换行`,labelWidth:`标签宽度`,wrapperWidth:`组件宽度`,fullness:`组件占满`,inset:`内联布局`,shallow:`是否浅传递`,bordered:`是否有边框`,size:{title:`尺寸`,dataSource:[`大`,`小`,`默认`,`继承`]},layout:{title:`布局`,dataSource:[`垂直`,`水平`,`内联`,`继承`]},feedbackLayout:{title:`反馈布局`,dataSource:[`宽松`,`紧凑`,`弹层`,`无`,`继承`]},tooltipLayout:{title:`提示布局`,dataSource:[`图标`,`文本`,`继承`]}}},"en-US":{title:`Form`,settings:{"x-reactions":`Reactions`,labelCol:`Label Col`,wrapperCol:`Wrapper Col`,colon:`Colon`,labelAlign:{title:`Label Align`,dataSource:[`Left`,`Right`,`Inherit`]},wrapperAlign:{title:`Wrapper Align`,dataSource:[`Left`,`Right`,`Inherit`]},labelWrap:`Label Wrap`,wrapperWrap:`Wrapper Wrap`,labelWidth:`Label Width`,wrapperWidth:`Wrapper Width`,fullness:`Fullness`,inset:`Inset`,shallow:`Shallow`,bordered:`Bordered`,size:{title:`Size`,dataSource:[`Large`,`Small`,`Default`,`Inherit`]},layout:{title:`Layout`,dataSource:[`Vertical`,`Horizontal`,`Inline`,`Inherit`]},feedbackLayout:{title:`Feedback Layout`,dataSource:[`Loose`,`Terse`,`Popup`,`None`,`Inherit`]},tooltipLayout:{title:`Tooltip Layout`,dataSource:[`Icon`,`Text`,`Inherit`]}}}}),cr={"zh-CN":{title:`表单布局`,settings:{"x-component-props":{labelCol:`标签网格宽度`,wrapperCol:`组件网格宽度`,colon:`是否有冒号`,labelAlign:{title:`标签对齐`,dataSource:[`左对齐`,`右对齐`,`继承`]},wrapperAlign:{title:`组件对齐`,dataSource:[`左对齐`,`右对齐`,`继承`]},labelWrap:`标签换行`,wrapperWrap:`组件换行`,labelWidth:`标签宽度`,wrapperWidth:`组件宽度`,fullness:`组件占满`,inset:`内联布局`,shallow:`是否浅传递`,bordered:`是否有边框`,size:{title:`尺寸`,dataSource:[`大`,`小`,`默认`,`继承`]},layout:{title:`布局`,dataSource:[`水平`,`垂直`,`内联`,`继承`]},feedbackLayout:{title:`反馈布局`,dataSource:[`宽松`,`紧凑`,`弹层`,`无`,`继承`]},tooltipLayout:{title:`提示布局`,dataSource:[`图标`,`文本`,`继承`]}}}},"en-US":{title:`Form Layout`,settings:{"x-component-props":{labelCol:`Label Col`,wrapperCol:`Wrapper Col`,colon:`Colon`,labelAlign:{title:`Label Align`,dataSource:[`Left`,`Right`,`Inherit`]},wrapperAlign:{title:`Wrapper Align`,dataSource:[`Left`,`Right`,`Inherit`]},labelWrap:`Label Wrap`,wrapperWrap:`Wrapper Wrap`,labelWidth:`Label Width`,wrapperWidth:`Wrapper Width`,fullness:`Fullness`,inset:`Inset`,shallow:`Shallow`,bordered:`Bordered`,size:{title:`Size`,dataSource:[`Large`,`Small`,`Default`,`Inherit`]},layout:{title:`Layout`,dataSource:[`Horizontal`,`Vertical`,`Inline`,`Inherit`]},feedbackLayout:{title:`Feedback Layout`,dataSource:[`Loose`,`Terse`,`Popup`,`None`,`Inherit`]},tooltipLayout:{title:`Tooltip Layout`,dataSource:[`Icon`,`Text`,`Inherit`]}}}}},lr={"zh-CN":{title:`文本`,settings:{"x-component-props":{content:`文本内容`,mode:{title:`文本类型`,dataSource:[`H1`,`H2`,`H3`,`Paragraph`,`Normal`]}}}},"en-US":{title:`Text`,settings:{"x-component-props":{content:`Text Content`,mode:{title:`Text Mode`,dataSource:[`H1`,`H2`,`H3`,`Paragraph`,`Normal`]}}}}},ur={"zh-CN":{title:`卡片`,settings:{"x-component-props":{type:`类型`,title:`标题`,extra:`右侧扩展`,cardTypes:[{label:`内置`,value:`inner`},{label:`默认`,value:``}]}}},"en-US":{title:`Card`,settings:{"x-component-props":{type:`Type`,title:`Title`,extra:`Extra`,cardTypes:[{label:`Inner`,value:`inner`},{label:`Default`,value:``}]}}}};w.registerDesignerLocales({"zh-CN":{Previews:{droppable:`可以拖入组件`,addTabPane:`添加选项卡`,addCollapsePanel:`添加手风琴卡片`,addTableColumn:`添加表格列`,addTableSortHandle:`添加排序`,addIndex:`添加索引`,addOperation:`添加操作`}}});var dr={"zh-CN":{title:`添加按钮`,settings:{"x-component-props":{method:`方法`,defaultValue:`默认值`}}}},fr={"zh-CN":{title:`删除按钮`},"en-US":{title:`Remove`}},pr={"zh-CN":{title:`上移按钮`},"en-US":{title:`Move Up`}},mr={"zh-CN":{title:`下移按钮`},"en-US":{title:`Move Down`}},hr={"zh-CN":{title:`索引标识`},"en-US":{title:`Index`}},gr={"zh-CN":{title:`排序标识`},"en-US":{title:`Sort Handle`}},_r=C(ur,{"zh-CN":{title:`自增卡片`,addIndex:`添加索引`,addOperation:`添加操作`},"en-US":{title:`Array Cards`,addIndex:`Add Index`,addOperation:`Add Operations`}}),vr={"zh-CN":{title:`自增表格`,addSortHandle:`添加排序`,addColumn:`添加列`,addIndex:`添加索引`,addOperation:`添加操作`,settings:{"x-component-props":{showHeader:`显示头部`,sticky:`吸顶`,align:{title:`对齐`,dataSource:[`左`,`右`,`居中`]},colSpan:`跨列`,fixed:{title:`固定列`,dataSource:[`左`,`右`,`无`]},width:`宽度`,defaultValue:`默认值`,tableLayout:{title:`表格布局`,dataSource:[`自动`,`固定`]}}}},"en-US":{title:`Array Table`,addSortHandle:`Add Sort Handle`,addColumn:`Add Column`,addIndex:`Add Index`,addOperation:`Add Operations`,settings:{"x-component-props":{showHeader:`Show Header`,sticky:`Sticky`,align:{title:`Align`,dataSource:[`Left`,`Right`,`Center`]},colSpan:`Col Span`,fixed:{title:`Fixed`,dataSource:[`Left`,`Right`,`None`]},width:`Width`,defaultValue:`Default Value`,tableLayout:{title:`Table Layout`,dataSource:[`Auto`,`Fixed`]}}}}},yr={"zh-CN":{title:`表格列`,settings:{"x-component-props":{title:`标题`,align:{title:`内容对齐`,dataSource:[`左`,`右`,`居中`]},colSpan:`跨列`,width:`宽度`,fixed:{title:`固定`,dataSource:[`左`,`右`,`无`]}}}},"en-US":{title:`Column`,settings:{"x-component-props":{title:`Title`,align:{title:`Align`,dataSource:[`Left`,`Right`,`Center`]},colSpan:`Col Span`,width:`Width`,fixed:{title:`Fixed`,dataSource:[`Left`,`Right`,`None`]}}}}},br={"zh-CN":{title:`虚拟容器`},"en-US":{title:`Void`}},xr={"zh-CN":{title:`弹性间距`,settings:{"x-component-props":{direction:{title:`方向`,dataSource:[`垂直`,`水平`]},split:`分割内容`,wrap:`自动换行`,align:{title:`对齐`,dataSource:[`头部`,`尾部`,`居中`,`基准线`]}}}},"en-US":{title:`Space`,settings:{"x-component-props":{direction:{title:`Direction`,dataSource:[`Vertical`,`Horizontal`]},split:`Split`,wrap:`Word Wrap`,align:{title:`Align`,dataSource:[`Start`,`End`,`Center`,`Baseline`]}}}}},Sr={"zh-CN":{title:`选项卡`,addTabPane:`添加选项卡`,settings:{"x-component-props":{animated:`启用动画过渡`,centered:`标签居中`,tab:`选项名称`,type:{title:`类型`,dataSource:[{label:`线框`,value:`line`},{label:`卡片`,value:`card`}]}}}},"en-US":{title:`Tabs`,addTabPane:`Add Panel`,settings:{"x-component-props":{animated:`Enable Animated`,centered:`Label Centered`,tab:`Tab Title`,type:{title:`Type`,dataSource:[{label:`Line`,value:`line`},{label:`Card`,value:`card`}]}}}}},Cr={"zh-CN":{title:`选项卡面板`,settings:{"x-component-props":{tab:`面板标题`}}},"en-US":{title:`Tab Panel`,settings:{"x-component-props":{tab:`Panel Title`}}}},wr={"zh-CN":{title:`折叠面板`,addCollapsePanel:`添加面板`,settings:{"x-component-props":{accordion:`手风琴模式`,collapsible:{title:`可折叠区域`,dataSource:[`头部`,`禁用`]},ghost:`幽灵模式`,bordered:`是否有边框`}}},"en-US":{title:`Collapse`,addCollapsePanel:`Add Panel`,settings:{"x-component-props":{accordion:`Accordion Mode`,collapsible:{title:`Collapsible`,dataSource:[`Header`,`Disable`]},ghost:`Ghost Mode`,bordered:`Bordered`}}}},Tr={"zh-CN":{title:`面板`,settings:{"x-component-props":{collapsible:{title:`是否可折叠`,dataSource:[`头部`,`禁用`]},header:`标题`,extra:`扩展内容`}}},"en-US":{title:`Panel`,settings:{"x-component-props":{collapsible:{title:`Collapsible`,dataSource:[`Header`,`Disable`]},header:`Header Title`,extra:`Extra Content`}}}},Er={"zh-CN":{title:`网格布局`,addGridColumn:`添加网格列`,settings:{"x-component-props":{minWidth:`最小宽度`,minColumns:`最小列数`,maxWidth:`最大宽度`,maxColumns:`最大列数`,breakpoints:`响应式断点`,columnGap:`列间距`,rowGap:`行间距`,colWrap:`自动换行`,strictAutoFit:`自动占满`}}},"en-US":{title:`Grid`,addGridColumn:`Add Grid Column`,settings:{"x-component-props":{minWidth:`Min Width`,minColumns:`Min Columns`,maxWidth:`Max Width`,maxColumns:`Max Columns`,breakpoints:`Breakpoints`,columnGap:`Column Gap`,rowGap:`Row Gap`,colWrap:`Col Wrap`,strictAutoFit:`Auto Fit`}}}},Dr={"zh-CN":{title:`网格列`,settings:{"x-component-props":{gridSpan:`跨列栏数`}}},"en-US":{title:`Grid Column`,settings:{"x-component-props":{gridSpan:`Grid Span`}}}},Or={"zh-CN":{title:`Div`,settings:{"x-component-props":{children:`children`}}},"en-US":{title:`Div`,settings:{"x-component-props":{children:`children`}}}},kr={"zh-CN":{title:`二维码`,settings:{"x-component-props":{content:`二维码内容`,type:`渲染类型`,icon:`二维码中图片的地址（目前只支持图片地址）`,size:`二维码大小`,iconSize:`二维码中图片的大小`,color:`二维码颜色`,bgColor:`二维码背景颜色`,bordered:`是否有边框`,errorLevel:`二维码纠错等级`}}},"en-US":{title:`QRCode`,settings:{"x-component-props":{content:`content`,type:`type`,icon:`icon`,size:`size`,iconSize:`icon size`,color:`color`,bgColor:`bg color`,bordered:`bordered`,errorLevel:`error level`}}}},Ar={"zh-CN":{title:`按钮`,settings:{"x-component-props":{children:`按钮文字`,href:`点击跳转的地址，指定此属性 button 的行为和 a 链接一致`,type:`设置按钮类型`,danger:`设置危险按钮`,shape:`设置按钮形状`,size:`设置按钮大小`,target:`相当于 a 链接的 target 属性，href 存在时生效`,icon:`设置按钮的图标组件`,iconPosition:`设置按钮图标组件的位置`,block:`将按钮宽度调整为其父宽度的选项`,autoInsertSpace:`提供两个汉字之间的空格`,ghost:`幽灵属性，使按钮背景透明`,loading:`设置按钮载入状态`,disabled:`设置按钮禁用状态`,htmlType:`设置 button 原生的 type 值`}}},"en-US":{title:`Button`,settings:{"x-component-props":{children:`Button text`,href:`Click the address to jump, specify the behavior of the button and the a link is consistent`,type:`Set the type of the button`,danger:`Set the danger button`,shape:`Set the shape of the button`,size:`Set the size of the button`,block:`Option to adjust the width of the button to that of its parent`,autoInsertSpace:`Provide space between two Chinese characters`,ghost:`Ghost attribute, making the button background transparent`,loading:`Set the loading status of the button`,disabled:`Set the disabled status of the button`,icon:`Set the icon component of the button`,iconPosition:`Set the position of the icon component of the button`,htmlType:`Set the native type value of the button`,target:`Equivalent to the target attribute of a link, effective when href exists`}}}},jr={"zh-CN":{title:`悬浮按钮`,settings:{"x-component-props":{icon:`设置按钮的图标组件`,description:`文字及其它内容`,tooltip:`气泡卡片的内容`,type:`设置按钮类型`,shape:`设置按钮形状`,href:`点击跳转的地址，指定此属性 button 的行为和 a 链接一致`,target:`相当于 a 链接的 target 属性，href 存在时生效`,insetInlineEnd:`到右侧的距离`,insetBlockEnd:`到底部的距离`,disabled:`设置按钮禁用状态`,badge:`设置徽标`}}},"en-US":{title:`Float Button`,settings:{"x-component-props":{icon:`Set the icon component of the button`,description:`Text and other content`,tooltip:`Tooltip content`,type:`Set the type of the button`,shape:`Set the shape of the button`,href:`Click the address to jump, specify the behavior of the button and the a link is consistent`,target:`Equivalent to the target attribute of a link, effective when href exists`,insetInlineEnd:`Right distance`,insetBlockEnd:`Bottom distance`,disabled:`Set the disabled status of the button`,badge:`Set the badge`}}}},Mr={"zh-CN":{title:`悬浮按钮组`,settings:{"x-component-props":{...jr[`zh-CN`].settings[`x-component-props`],shape:`设置包含的 FloatButton 按钮形状`,trigger:`触发方式（有触发方式为菜单模式）`}}},"en-US":{title:`Float Button Group`,settings:{"x-component-props":{...jr[`en-US`].settings[`x-component-props`],shape:`Set the shape of the contained FloatButton button`,trigger:`Trigger mode (with trigger mode is menu mode)`}}}},Nr={"zh-CN":{title:`回到顶部`,settings:{"x-component-props":{...jr[`zh-CN`].settings[`x-component-props`],duration:`回到顶部所需时间(ms)`,visibilityHeight:`滚动高度达到此参数值才出现 BackTop`}}},"en-US":{title:`Back to Top`,settings:{"x-component-props":{...jr[`en-US`].settings[`x-component-props`],duration:`Time required to go back to the top (ms)`,visibilityHeight:`Scroll height reaches this parameter value to appear BackTop`}}}},Pr={"zh-CN":{title:`分割线`,settings:{"x-component-props":{children:`嵌套的标题`,variant:`分割线是虚线、点线还是实线`,orientation:`分割线标题的位置`,orientationMargin:`标题和最近 left/right 边框之间的距离，去除了分割线，同时 orientation 必须为 left 或 right。如果传入 string 类型的数字且不带单位，默认单位是 px`,plain:`文字是否显示为普通正文样式`,type:`水平还是垂直类型`}}},"en-US":{title:`Divider`,settings:{"x-component-props":{children:`Nested title`,variant:`Line style`,orientation:`Title position`,orientationMargin:`Margin between the title and the closest left/right border, without the divider, and orientation must be left or right. If a string type number is passed without a unit, the default unit is px`,plain:`Whether to display the text as plain body style`,type:`Horizontal or vertical type`}}}},Fr={"zh-CN":{title:`循环布局`,settings:{"x-component-props":{}}},"en-US":{title:`IteratorLayout`,settings:{"x-component-props":{}}}},Ir={"zh-CN":{title:`动态 schema 区块`,settings:{"x-component-props":{}}},"en-US":{title:`DynamicSchemaBlock`,settings:{"x-component-props":{}}}},Lr={"zh-CN":{title:`抽屉`,settings:{"x-component-props":{autoFocus:`抽屉展开后是否将焦点切换至其 DOM 节点`,afterOpenChange:`切换抽屉时动画结束后的回调`,classNames:`语义化结构 className`,closeIcon:`自定义关闭图标`,destroyOnClose:`关闭时销毁 Drawer 里的子元素`,extra:`抽屉右上角的操作区域`,footer:`抽屉的页脚`,forceRender:`预渲染 Drawer 内元素`,getContainer:`指定 Drawer 挂载的节点，并在容器内展现，false 为挂载在当前位置`,height:`高度，在 placement 为 top 或 bottom 时使用`,keyboard:`是否支持键盘 esc 关闭`,mask:`是否展示遮罩`,maskClosable:`点击蒙层是否允许关闭`,placement:`抽屉的方向`,push:`用于设置多层 Drawer 的推动行为`,rootStyle:`可用于设置 Drawer 最外层容器的样式，和 style 的区别是作用节点包括 mask`,styles:`语义化结构 style`,size:`预设抽屉宽度（或高度），default 378px 和 large 736px`,title:`标题`,loading:`显示骨架屏`,open:`Drawer 是否可见`,width:`宽度`,zIndex:`设置 Drawer 的 z-index`,onClose:`点击遮罩层或左上角叉或取消按钮的回调`,drawerRender:`自定义渲染抽屉`}}},"en-US":{title:`Drawer`,settings:{"x-component-props":{autoFocus:`Whether Drawer should get focused after open`,afterOpenChange:`Callback after the animation ends when switching drawers`,classNames:`Semantic structure className`,closeIcon:`Custom close icon`,destroyOnClose:`Whether to unmount child components on closing drawer or not`,extra:`Extra actions area at corner`,footer:`The footer for Drawer`,forceRender:`Pre-render Drawer component forcibly`,getContainer:`mounted node and display window for Drawer`,height:`Placement is top or bottom, height of the Drawer dialog`,keyboard:`Whether support press esc to close`,mask:`Whether to show mask or not`,maskClosable:`Clicking on the mask (area outside the Drawer) to close the Drawer or not`,placement:`The placement of the Drawer`,push:`Nested drawers push behavior`,rootStyle:`Style of wrapper element which contains mask compare to style`,styles:`Semantic structure style`,size:`preset size of drawer, default 378px and large 736px`,title:`The title for Drawer`,loading:`Show the Skeleton`,open:`Whether the Drawer dialog is visible or not`,width:`Width of the Drawer dialog`,zIndex:`The z-index of the Drawer`,onClose:`Specify a callback that will be called when a user clicks mask, close button or Cancel button`,drawerRender:`Custom drawer content render`}}}},Rr={"zh-CN":{settings:{"x-component-props":{arrow:`修改箭头的显示状态以及修改箭头是否指向目标元素中心`,autoAdjustOverflow:`气泡被遮挡时自动调整位置`,color:`背景颜色`,defaultOpen:`默认是否显隐`,destroyTooltipOnHide:`关闭后是否销毁 Tooltip`,fresh:`默认情况下，Tooltip 在关闭时会缓存内容。设置该属性后会始终保持更新`,getPopupContainer:`浮层渲染父节点，默认渲染到 body 上`,mouseEnterDelay:`鼠标移入后延时多少才显示 Tooltip，单位：秒`,mouseLeaveDelay:`鼠标移出后延时多少才隐藏 Tooltip，单位：秒`,overlayClassName:`卡片类名`,overlayStyle:`卡片样式`,overlayInnerStyle:`卡片内容区域的样式对象`,placement:`气泡框位置`,trigger:`触发行为，可使用数组设置多个触发行为`,open:`用于手动控制浮层显隐`,zIndex:`设置 Tooltip 的 z-index`,onOpenChange:`显示隐藏的回调`}}},"en-US":{settings:{"x-component-props":{arrow:`Change arrow's visible state and change whether the arrow is pointed at the center of target`,autoAdjustOverflow:`Whether to adjust popup placement automatically when popup is off screen`,color:`The background color`,defaultOpen:`Whether the floating tooltip card is open by default`,destroyTooltipOnHide:`Whether destroy tooltip when hidden`,fresh:`Tooltip will cache content when it is closed by default. Setting this property will always keep updating`,getPopupContainer:`The DOM container of the tip, the default behavior is to create a div element in body`,mouseEnterDelay:`Delay in seconds, before tooltip is shown on mouse enter`,mouseLeaveDelay:`Delay in seconds, before tooltip is hidden on mouse leave`,overlayClassName:`Class name of the tooltip card`,overlayStyle:`Style of the tooltip card`,overlayInnerStyle:`Style of the tooltip inner content`,placement:`The position of the tooltip relative to the target`,trigger:`Tooltip trigger mode. Could be multiple by passing an array`,open:`Whether the floating tooltip card is open or not`,zIndex:`Config z-index of Tooltip`,onOpenChange:`Callback executed when visibility of the tooltip card is changed`}}}},zr=C(Rr,{"zh-CN":{title:`文字提示`,settings:{"x-component-props":{title:`提示文字`}}},"en-US":{title:`Tooltip`,settings:{"x-component-props":{title:`The text shown in the tooltip`}}}}),Br={"zh-CN":{title:`对话框`,settings:{"x-component-props":{afterClose:`Modal 完全关闭后的回调`,classNames:`配置弹窗内置模块的 className`,styles:`配置弹窗内置模块的 style`,cancelButtonProps:`cancel 按钮 props`,cancelText:`取消按钮文字`,centered:`垂直居中展示 Modal`,closable:`是否显示右上角的关闭按钮`,closeIcon:`自定义关闭图标`,confirmLoading:`确定按钮 loading`,destroyOnClose:`关闭时销毁 Modal 里的子元素`,focusTriggerAfterClose:`对话框关闭后是否需要聚焦触发元素`,footer:`底部内容，当不需要默认底部按钮时，可以设为 footer={null}`,forceRender:`强制渲染 Modal`,getContainer:`指定 Modal 挂载的节点，但依旧为全屏展示，false 为挂载在当前位置`,keyboard:`是否支持键盘 esc 关闭`,mask:`是否展示遮罩`,maskClosable:`点击蒙层是否允许关闭`,modalRender:`自定义渲染对话框`,okButtonProps:`ok 按钮 props`,okText:`确认按钮文字`,okType:`确认按钮类型`,loading:`限时骨架屏`,title:`标题`,open:`对话框是否可见`,width:`宽度`,wrapClassName:`对话框外层容器的类名`,zIndex:`设置 Modal 的 z-index`,onCancel:`点击遮罩层或右上角叉或取消按钮的回调`,onOk:`点击确定回调`,afterOpenChange:`打开和关闭 Modal 时动画结束后的回调`}}},"en-US":{title:`Modal`,settings:{"x-component-props":{afterClose:`Specify a function that will be called when modal is closed completely`,classNames:`Config Modal build-in module's className`,styles:`Config Modal build-in module's style`,cancelButtonProps:`The cancel button props`,cancelText:`Text of the Cancel button`,centered:`Centered Modal`,closable:`Whether a close (x) button is visible on top right or not`,closeIcon:`Custom close icon`,confirmLoading:`Whether to apply loading visual effect for OK button or not`,destroyOnClose:`Whether to unmount child components on onClose`,focusTriggerAfterClose:`Whether need to focus trigger element after dialog is closed`,footer:`Footer content, set as footer={null} when you don't need default buttons`,forceRender:`Force render Modal`,getContainer:`The mounted node for Modal but still display at fullscreen`,keyboard:`Whether support press esc to close`,mask:`Whether show mask or not`,maskClosable:`Whether to close the modal dialog when the mask (area outside the modal) is clicked`,modalRender:`Custom modal content render`,okButtonProps:`The ok button props`,okText:`Text of the OK button`,okType:`Button type of the OK button`,loading:`Show the skeleton`,title:`The modal dialog's title`,open:`Whether the modal dialog is visible or not`,width:`Width of the modal dialog`,wrapClassName:`The class name of the container of the modal dialog`,zIndex:`The z-index of the Modal`,onCancel:`Specify a function that will be called when a user clicks mask, close button on top right or Cancel button`,onOk:`Specify a function that will be called when a user clicks the OK button`,afterOpenChange:`Callback when the animation ends when Modal is turned on and off`}}}},Vr=C(Rr,{"zh-CN":{title:`气泡确认框`,settings:{"x-component-props":{icon:`自定义弹出气泡 Icon 图标`,title:`确认框标题`,description:`确认内容的详细描述`,okButtonProps:`确认按钮属性`,okText:`确认按钮文字`,okType:`确认按钮类型`,cancelButtonProps:`取消按钮属性`,cancelText:`取消按钮文字`,showCancel:`是否显示取消按钮`,disabled:`阻止点击 Popconfirm 子元素时弹出确认框`,onCancel:`点击取消的回调`,onConfirm:`点击确认的回调`,onPopupClick:`弹出气泡点击事件`}}},"en-US":{title:`Popconfirm`,settings:{"x-component-props":{icon:`Customize icon of confirmation`,title:`The title of the confirmation box`,description:`The description of the confirmation box title`,okButtonProps:`The ok button props`,okText:`The text of the Confirm button`,okType:`Button type of the Confirm button`,cancelButtonProps:`The cancel button props`,cancelText:`The ok button props`,showCancel:`Show cancel button`,disabled:`Whether show popconfirm when click its childrenNode`,onCancel:`A callback of cancel`,onConfirm:`A callback of confirmation`,onPopupClick:`A callback of popup click`}}}}),Hr=C(Rr,{"zh-CN":{title:`气泡卡片`,settings:{"x-component-props":{title:`卡片标题`,content:`卡片内容`}}},"en-US":{title:`Popover`,settings:{"x-component-props":{title:`Title of the card`,content:`Content of the card`}}}}),Ur={"zh-CN":{title:`加载中`,settings:{"x-component-props":{delay:`延迟显示加载效果的时间（防止闪烁）`,fullscreen:`显示带有 Spin 组件的背景`,indicator:`加载指示符`,percent:`展示进度，当设置 percent="auto" 时会预估一个永远不会停止的进度`,size:`组件大小`,spinning:`是否为加载中状态`,tip:`当作为包裹元素时，可以自定义描述文案`,wrapperClassName:`包装器的类属性`}}},"en-US":{title:`Spin`,settings:{"x-component-props":{delay:`Specifies a delay in milliseconds for loading state (prevent flush)`,fullscreen:`Display a backdrop with the Spin component`,indicator:`React node of the spinning indicator`,percent:`The progress percentage, when set to auto, it will be an indeterminate progress`,size:`The size of Spin`,spinning:`Whether Spin is visible`,tip:`Customize description content when Spin has children`,wrapperClassName:`The className of wrapper when Spin has children`}}}},Wr={"zh-CN":{title:`标签`,settings:{"x-component-props":{children:`标签内容`,color:`标签颜色`,icon:`设置标签图标`,closeIcon:`关闭按钮图标`,bordered:`是否有边框`,onClose:`关闭时的回调`}}},"en-US":{title:`Tag`,settings:{"x-component-props":{children:`Tag content`,color:`Color of the Tag`,icon:`Set the icon of tag`,closeIcon:`Custom close icon`,bordered:`Whether has border style`,onClose:`Callback executed when tag is closed`}}}},Gr={"zh-CN":{title:`可选择标签`,settings:{"x-component-props":{children:`标签内容`,checked:`设置标签的选中状态`,onChange:`点击标签时触发的回调`}}},"en-US":{title:`CheckableTag`,settings:{"x-component-props":{children:`Tag content`,checked:`Checked status of Tag`,onCheckedChange:`Callback executed when Tag is checked/unchecked`}}}},Kr={"zh-CN":{title:`警告提示`,settings:{"x-component-props":{message:`提示内容`,description:`辅助描述文字`,type:`提示类型`,showIcon:`是否显示图标`,closable:`是否可关闭`,banner:`是否用作顶部公告`,action:`自定义操作项`}}},"en-US":{title:`Alert`,settings:{"x-component-props":{message:`message`,description:`description`,type:`type`,showIcon:`show icon`,closable:`closable`,banner:`banner`,action:`action`}}}},qr={"zh-CN":{title:`iframe`,settings:{"x-component-props":{sandbox:`沙箱限制`,loading:`加载策略`}}},"en-US":{title:`iframe`,settings:{"x-component-props":{sandbox:`sandbox`,loading:`loading`}}}},Jr={"zh-CN":{title:`代码编辑器`,settings:{"x-component-props":{language:`语言`,theme:`主题`,height:`高度(px)`,width:`宽度`,fontSize:`字号`,tabSize:`缩进空格数`,minimap:`显示缩略图`,wordWrap:`自动换行`,readOnly:`只读`,placeholder:`加载占位文案`}}},"en-US":{title:`CodeEditor`,settings:{"x-component-props":{language:`Language`,theme:`Theme`,height:`Height(px)`,width:`Width`,fontSize:`Font Size`,tabSize:`Tab Size`,minimap:`Minimap`,wordWrap:`Word Wrap`,readOnly:`Read Only`,placeholder:`Loading Placeholder`}}}},Yr={"zh-CN":{title:`描述列表`,settings:{"x-component-props":{title:`列表标题`,items:`描述项配置（JSON）`,column:`每行项数`,bordered:`展示边框`,size:`尺寸`,layout:`布局方向`}}},"en-US":{title:`Descriptions`,settings:{"x-component-props":{title:`title`,items:`items (JSON)`,column:`column`,bordered:`bordered`,size:`size`,layout:`layout`}}}},Xr={"zh-CN":{title:`步骤条`,settings:{"x-component-props":{items:`步骤项配置（JSON）`,current:`当前步骤`,direction:`方向`,status:`当前步骤状态`,size:`尺寸`,progressDot:`点状步骤条`,type:`步骤条类型`}}},"en-US":{title:`Steps`,settings:{"x-component-props":{items:`items (JSON)`,current:`current`,direction:`direction`,status:`status`,size:`size`,progressDot:`progress dot`,type:`type`}}}},Zr={"zh-CN":{title:`结果页`,settings:{"x-component-props":{status:`结果状态`,title:`标题文字`,subTitle:`补充文字`,icon:`自定义图标`,extra:`操作区`}}},"en-US":{title:`Result`,settings:{"x-component-props":{status:`status`,title:`title`,subTitle:`sub title`,icon:`icon`,extra:`extra`}}}},Qr={"zh-CN":{title:`统计数值`,settings:{"x-component-props":{title:`数值标题`,prefix:`数值前缀`,suffix:`数值后缀`,precision:`数值精度`,groupSeparator:`千分位分隔符`,valueStyle:`数值样式`,loading:`数据加载中`}}},"en-US":{title:`Statistic`,settings:{"x-component-props":{title:`title`,prefix:`prefix`,suffix:`suffix`,precision:`precision`,groupSeparator:`group separator`,valueStyle:`value style`,loading:`loading`}}}},$r={"zh-CN":{title:`时间轴`,settings:{"x-component-props":{items:`时间轴项配置（JSON）`,mode:`相对位置`,reverse:`倒序排列`,pending:`幽灵节点（进行中）`}}},"en-US":{title:`Timeline`,settings:{"x-component-props":{items:`items (JSON)`,mode:`mode`,reverse:`reverse`,pending:`pending (ghost node)`}}}},ei={"zh-CN":{title:`徽标数`,settings:{"x-component-props":{count:`展示数字`,overflowCount:`封顶数字`,dot:`小红点模式`,showZero:`为 0 时展示`,status:`状态点`,text:`状态文本`,color:`圆点颜色`,size:`徽标尺寸`}}},"en-US":{title:`Badge`,settings:{"x-component-props":{count:`count`,overflowCount:`overflow count`,dot:`dot`,showZero:`show zero`,status:`status`,text:`text`,color:`color`,size:`size`}}}},ti={"zh-CN":{title:`进度条`,settings:{"x-component-props":{percent:`百分比`,type:`进度条类型`,status:`进度条状态`,size:`进度环尺寸`,showInfo:`显示进度信息`,strokeColor:`进度条色彩`,steps:`分段数量`,strokeLinecap:`端点形状`}}},"en-US":{title:`Progress`,settings:{"x-component-props":{percent:`percent`,type:`type`,status:`status`,size:`size`,showInfo:`show info`,strokeColor:`stroke color`,steps:`steps`,strokeLinecap:`strokeLinecap`}}}},ni={"zh-CN":{title:`内容折叠面板`,addPanel:`添加面板`,settings:{"x-component-props":{accordion:`手风琴模式`,bordered:`是否有边框`,collapsible:{title:`可折叠区域`,dataSource:[`头部`,`图标`,`禁用`]},ghost:`幽灵模式`,size:`尺寸`,expandIconPosition:{title:`图标位置`,dataSource:[`开始`,`结束`]},defaultActiveKey:`初始展开面板`}}},"en-US":{title:`Collapse`,addPanel:`Add Panel`,settings:{"x-component-props":{accordion:`Accordion Mode`,bordered:`Bordered`,collapsible:{title:`Collapsible`,dataSource:[`Header`,`Icon`,`Disabled`]},ghost:`Ghost Mode`,size:`Size`,expandIconPosition:{title:`Expand Icon Position`,dataSource:[`Start`,`End`]},defaultActiveKey:`default active key`}}}},ri={"zh-CN":{title:`折叠面板项`,settings:{"x-component-props":{header:`面板标题`,extra:`额外内容`,collapsible:{title:`可折叠区域`,dataSource:[`头部`,`图标`,`禁用`]}}}},"en-US":{title:`Collapse Panel`,settings:{"x-component-props":{header:`Panel Header`,extra:`Extra Content`,collapsible:{title:`Collapsible`,dataSource:[`Header`,`Icon`,`Disabled`]}}}}},ii={"zh-CN":{title:`内容页签`,addTabPane:`添加页签`,settings:{"x-component-props":{type:`页签样式`,tabPosition:`页签位置`,size:`尺寸`,centered:`居中布局`,animated:`启用动画过渡`,defaultActiveKey:`初始激活 Tab`,destroyInactiveTabPane:`销毁非活跃面板`}}},"en-US":{title:`Tabs`,addTabPane:`Add Tab`,settings:{"x-component-props":{type:`type`,tabPosition:`tab position`,size:`size`,centered:`centered`,animated:`animated`,defaultActiveKey:`default active key`,destroyInactiveTabPane:`destroy inactive tab pane`}}}},ai={"zh-CN":{title:`页签面板`,settings:{"x-component-props":{tab:`页签标题`}}},"en-US":{title:`Tab Pane`,settings:{"x-component-props":{tab:`Tab Title`}}}},oi={"zh-CN":{title:`数据表格`,settings:{"x-component-props":{columns:`列配置（JSON）`,dataSource:`表格数据（JSON）`,size:`尺寸`,bordered:`展示边框`,showHeader:`显示表头`,pagination:`分页配置`,scroll:`滚动配置`,loading:`加载状态`,rowKey:`行键字段`,sticky:`表头常驻`}}},"en-US":{title:`Table`,settings:{"x-component-props":{columns:`columns (JSON)`,dataSource:`data source (JSON)`,size:`size`,bordered:`bordered`,showHeader:`show header`,pagination:`pagination`,scroll:`scroll`,loading:`loading`,rowKey:`row key`,sticky:`sticky header`}}}},si={"zh-CN":{title:`导航菜单`,settings:{"x-component-props":{items:`菜单项配置（JSON）`,mode:`菜单类型`,theme:`主题颜色`,inlineCollapsed:`折叠状态`,multiple:`允许多选`,selectable:`允许选中`,defaultSelectedKeys:`初始选中项`,defaultOpenKeys:`初始展开子菜单`}}},"en-US":{title:`Menu`,settings:{"x-component-props":{items:`items (JSON)`,mode:`mode`,theme:`theme`,inlineCollapsed:`inline collapsed`,multiple:`multiple`,selectable:`selectable`,defaultSelectedKeys:`default selected keys`,defaultOpenKeys:`default open keys`}}}},ci={"zh-CN":{title:`树形控件`,settings:{"x-component-props":{treeData:`树形数据（JSON）`,checkable:`节点前添加 Checkbox`,defaultExpandAll:`默认展开所有节点`,showLine:`是否展示连接线`,showIcon:`是否展示图标`,draggable:`是否可拖拽`,blockNode:`节点占据一行`,selectable:`节点可选中`,multiple:`支持多选`,height:`虚拟滚动容器高度`}}},"en-US":{title:`Tree`,settings:{"x-component-props":{treeData:`tree data (JSON)`,checkable:`checkable`,defaultExpandAll:`default expand all`,showLine:`show line`,showIcon:`show icon`,draggable:`draggable`,blockNode:`block node`,selectable:`selectable`,multiple:`multiple`,height:`virtual scroll height`}}}},li={"zh-CN":{title:`列表`,settings:{"x-component-props":{dataSource:`列表数据（JSON）`,header:`列表头部`,footer:`列表底部`,bordered:`是否展示边框`,size:`列表尺寸`,split:`是否展示分割线`,loading:`是否加载中`}}},"en-US":{title:`List`,settings:{"x-component-props":{dataSource:`data source (JSON)`,header:`header`,footer:`footer`,bordered:`bordered`,size:`size`,split:`split`,loading:`loading`}}}},ui={"zh-CN":{title:`分页器`,settings:{"x-component-props":{total:`数据总数`,defaultCurrent:`默认当前页`,pageSize:`每页条数`,showSizeChanger:`显示每页条数切换`,showQuickJumper:`显示快速跳转`,showTotal:`显示总数文案（支持 {total}/{range} 变量）`,simple:`简单模式`,size:`尺寸`,align:`对齐方式`}}},"en-US":{title:`Pagination`,settings:{"x-component-props":{total:`total`,defaultCurrent:`default current`,pageSize:`page size`,showSizeChanger:`show size changer`,showQuickJumper:`show quick jumper`,showTotal:`show total (template: {total}/{range})`,simple:`simple`,size:`size`,align:`align`}}}},di={"zh-CN":{title:`面包屑`,settings:{"x-component-props":{items:`面包屑项配置（JSON）`,separator:`分隔符`}}},"en-US":{title:`Breadcrumb`,settings:{"x-component-props":{items:`items (JSON)`,separator:`separator`}}}},fi={"zh-CN":{title:`图片`,settings:{"x-component-props":{src:`图片地址`,alt:`替代文本`,objectFit:{title:`填充方式`,dataSource:[`铺满 Cover`,`适合 Contain`,`拉伸 Fill`,`无 None`,`缩小 Scale-down`]},width:`宽度`,height:`高度`,preview:`开启预览`,fallback:`加载失败容错地址`,placeholder:`加载占位`,loading:`加载方式`}}},"en-US":{title:`Image`,settings:{"x-component-props":{src:`src`,alt:`alt`,objectFit:`object-fit`,width:`width`,height:`height`,preview:`preview`,fallback:`fallback`,placeholder:`placeholder`,loading:`loading`}}}},pi={"zh-CN":{title:`骨架屏`,settings:{"x-component-props":{active:`展示动画效果`,loading:`是否显示骨架屏`,avatar:`显示头像占位图`,title:`显示标题占位图`,paragraph:`显示段落占位图`,round:`标题和段落显示圆角`,rows:`段落占位行数`}}},"en-US":{title:`Skeleton`,settings:{"x-component-props":{active:`active`,loading:`loading`,avatar:`avatar`,title:`title`,paragraph:`paragraph`,round:`round`,rows:`paragraph rows`}}}},mi={"zh-CN":{title:`头像`,settings:{"x-component-props":{src:`图片地址`,size:`尺寸`,shape:`形状`,icon:`图标`,alt:`替代文本`,children:`文字内容`}}},"en-US":{title:`Avatar`,settings:{"x-component-props":{src:`src`,size:`size`,shape:`shape`,icon:`icon`,alt:`alt`,children:`children`}}}},hi={"zh-CN":{title:`下拉菜单`,settings:{"x-component-props":{label:`触发按钮文字`,items:`菜单项配置（JSON）`,placement:`弹出位置`,trigger:`触发方式`,disabled:`禁用`}}},"en-US":{title:`Dropdown`,settings:{"x-component-props":{label:`button label`,items:`items (JSON)`,placement:`placement`,trigger:`trigger`,disabled:`disabled`}}}},gi={"zh-CN":{title:`空状态`,settings:{"x-component-props":{description:`描述文字`,imageStyle:`图片样式（JSON）`}}},"en-US":{title:`Empty`,settings:{"x-component-props":{description:`description`,imageStyle:`imageStyle (JSON)`}}}},_i={"zh-CN":{title:`排版`,settings:{"x-component-props":{children:`文本内容`,variant:`类型（text/title/paragraph）`,level:`标题级别`,type:`文本类型`,strong:`加粗`,italic:`斜体`,underline:`下划线`,delete:`删除线`,code:`代码样式`,mark:`高亮`,ellipsis:`省略`,copyable:`可复制`}}},"en-US":{title:`Typography`,settings:{"x-component-props":{children:`Text Content`,variant:`variant`,level:`level`,type:`type`,strong:`strong`,italic:`italic`,underline:`underline`,delete:`delete`,code:`code`,mark:`mark`,ellipsis:`ellipsis`,copyable:`copyable`}}}},vi={"zh-CN":{title:`分段控制器`,settings:{"x-component-props":{options:`选项配置（JSON）`,size:`尺寸`,block:`撑满父元素`,disabled:`禁用`}}},"en-US":{title:`Segmented`,settings:{"x-component-props":{options:`options (JSON)`,size:`size`,block:`block`,disabled:`disabled`}}}},yi={"zh-CN":{title:`走马灯`,settings:{"x-component-props":{value:`幻灯片内容（JSON 字符串数组）`,autoplay:`自动切换`,dots:`显示指示点`,dotPosition:`指示点位置`,effect:`动画效果`,infinite:`无限循环`}}},"en-US":{title:`Carousel`,settings:{"x-component-props":{value:`slides (JSON)`,autoplay:`autoplay`,dots:`dots`,dotPosition:`dotPosition`,effect:`effect`,infinite:`infinite`}}}},bi={"zh-CN":{title:`日历`,settings:{"x-component-props":{fullscreen:`全屏展示`,mode:`初始模式`}}},"en-US":{title:`Calendar`,settings:{"x-component-props":{fullscreen:`fullscreen`,mode:`mode`}}}},xi={"zh-CN":{title:`水印`,settings:{"x-component-props":{content:`水印文字`,rotate:`旋转角度`,zIndex:`层级`,gap:`间距（JSON）`,font:`字体配置（JSON）`,image:`图片水印 URL`}}},"en-US":{title:`Watermark`,settings:{"x-component-props":{content:`content`,rotate:`rotate`,zIndex:`zIndex`,gap:`gap (JSON)`,font:`font (JSON)`,image:`image URL`}}}},Si={"zh-CN":{title:`漫游式引导`,settings:{"x-component-props":{steps:`步骤配置（JSON）`,type:`类型`,arrow:`显示箭头`,placement:`弹出位置`,open:`显示引导`}}},"en-US":{title:`Tour`,settings:{"x-component-props":{steps:`steps (JSON)`,type:`type`,arrow:`arrow`,placement:`placement`,open:`open`}}}},Ci={"zh-CN":{title:`分割面板`,addPanel:`添加面板`,settings:{"x-component-props":{layout:{title:`布局方向`,dataSource:[`水平`,`垂直`]}}}},"en-US":{title:`Splitter`,addPanel:`Add Panel`,settings:{"x-component-props":{layout:{title:`Layout`,dataSource:[`Horizontal`,`Vertical`]}}}}},wi={"zh-CN":{title:`分割面板项`,settings:{"x-component-props":{defaultSize:`默认尺寸`,min:`最小尺寸`,max:`最大尺寸`,collapsible:`可收起`,resizable:`可调整大小`}}},"en-US":{title:`Splitter Panel`,settings:{"x-component-props":{defaultSize:`Default Size`,min:`Min Size`,max:`Max Size`,collapsible:`Collapsible`,resizable:`Resizable`}}}},Ti={"zh-CN":{title:`颜色选择器`,settings:{"x-component-props":{defaultValue:`默认颜色`,format:`颜色格式`,size:`尺寸`,showText:`显示颜色文本`,allowClear:`允许清除`,disabled:`禁用`,disabledAlpha:`禁用透明度`,presets:`预设调色板`}}},"en-US":{title:`ColorPicker`,settings:{"x-component-props":{defaultValue:`defaultValue`,format:`format`,size:`size`,showText:`showText`,allowClear:`allowClear`,disabled:`disabled`,disabledAlpha:`disabledAlpha`,presets:`presets`}}}},Ei={"zh-CN":{title:`锚点`,settings:{"x-component-props":{items:`锚点项配置（JSON）`,direction:`方向`,affix:`固定模式`,replace:`替换 history`,offsetTop:`顶部偏移（px）`,targetOffset:`锡点高亮偏移（px）`}}},"en-US":{title:`Anchor`,settings:{"x-component-props":{items:`items (JSON)`,direction:`direction`,affix:`affix`,replace:`replace`,offsetTop:`offset top`,targetOffset:`target offset`}}}},Di={"zh-CN":{title:`提及`,settings:{"x-component-props":{options:`提及选项（JSON）`,prefix:`触发前缀`,placeholder:`占位提示`,rows:`行数`,autoSize:`自适应高度`,disabled:`禁用`,status:`校验状态`}}},"en-US":{title:`Mentions`,settings:{"x-component-props":{options:`options (JSON)`,prefix:`prefix`,placeholder:`placeholder`,rows:`rows`,autoSize:`autoSize`,disabled:`disabled`,status:`status`}}}},Oi={"zh-CN":{title:`ECharts 图表`,settings:{"x-component-props":{option:`图表配置（JSON）`,height:`高度(px)`,width:`宽度`,theme:`主题`,renderer:`渲染器`,autoResize:`自动 resize`,style:`容器样式`}}},"en-US":{title:`ECharts`,settings:{"x-component-props":{option:`option (JSON)`,height:`height (px)`,width:`width`,theme:`theme`,renderer:`renderer`,autoResize:`autoResize`,style:`style`}}}},ki={"zh-CN":{title:`Mermaid 图表`,settings:{"x-component-props":{mode:`初始显示模式`,showModeSwitch:`显示右上角模式切换器`,definition:`图表定义（Mermaid DSL）`,theme:`主题`,style:`容器样式`}}},"en-US":{title:`Mermaid`,settings:{"x-component-props":{mode:`initial view mode`,showModeSwitch:`show mode switch`,definition:`definition (Mermaid DSL)`,theme:`theme`,style:`style`}}}},Ai={"zh-CN":{title:`Markdown`,settings:{"x-component-props":{mode:`初始显示模式`,showModeSwitch:`显示右上角模式切换器`,content:`Markdown 内容`,style:`容器样式（JSON）`}}},"en-US":{title:`Markdown`,settings:{"x-component-props":{mode:`initial view mode`,showModeSwitch:`show mode switch`,content:`content`,style:`style (JSON)`}}}},ji={"zh-CN":{title:`看板`,settings:{"x-component-props":{storageKey:`存储键（不同看板请设置不同键）`,height:`高度（px）`,readOnly:`只读模式`}}},"en-US":{title:`Kanban`,settings:{"x-component-props":{storageKey:`Storage Key`,height:`Height (px)`,readOnly:`Read Only`}}}},O=t({Alert:()=>Kr,Anchor:()=>Ei,ArrayAddition:()=>dr,ArrayCards:()=>_r,ArrayIndex:()=>hr,ArrayMoveDown:()=>mr,ArrayMoveUp:()=>pr,ArrayRemove:()=>fr,ArraySortHandle:()=>gr,ArrayTable:()=>vr,ArrayTableColumn:()=>yr,Avatar:()=>mi,Badge:()=>ei,Breadcrumb:()=>di,Button:()=>Ar,Calendar:()=>bi,Card:()=>ur,Carousel:()=>yi,Cascader:()=>Gn,CheckableTag:()=>Gr,CheckboxGroup:()=>qn,CodeEditor:()=>Jr,Collapse:()=>ni,CollapsePanel:()=>ri,ColorPicker:()=>Ti,CommonTooltipAPI:()=>Rr,Component:()=>zn,DatePicker:()=>Xn,DateRangePicker:()=>Zn,Descriptions:()=>Yr,Div:()=>Or,Divider:()=>Pr,Drawer:()=>Lr,Dropdown:()=>hi,DynamicSchemaBlock:()=>Ir,ECharts:()=>Oi,Empty:()=>gi,Field:()=>Bn,FloatButton:()=>jr,FloatButtonBackTop:()=>Nr,FloatButtonGroup:()=>Mr,Form:()=>sr,FormCollapse:()=>wr,FormCollapsePanel:()=>Tr,FormGrid:()=>Er,FormGridColumn:()=>Dr,FormLayout:()=>cr,FormTab:()=>Sr,FormTabPane:()=>Cr,Iframe:()=>qr,Img:()=>fi,Input:()=>Vn,IteratorLayout:()=>Fr,Kanban:()=>ji,List:()=>li,Markdown:()=>Ai,Mentions:()=>Di,Menu:()=>si,Mermaid:()=>ki,Modal:()=>Br,NumberPicker:()=>er,ObjectLocale:()=>or,Pagination:()=>ui,Password:()=>tr,Popconfirm:()=>Vr,Popover:()=>Hr,Progress:()=>ti,QRCode:()=>kr,RadioGroup:()=>Kn,Rate:()=>Yn,Result:()=>Zr,Segmented:()=>vi,Select:()=>Hn,Skeleton:()=>pi,Slider:()=>Jn,Space:()=>xr,Spin:()=>Ur,Splitter:()=>Ci,SplitterPanel:()=>wi,Statistic:()=>Qr,Steps:()=>Xr,Switch:()=>ar,Table:()=>oi,Tabs:()=>ii,TabsTabPane:()=>ai,Tag:()=>Wr,Text:()=>lr,TextArea:()=>Un,TimePicker:()=>Qn,TimeRangePicker:()=>$n,Timeline:()=>$r,Tooltip:()=>zr,Tour:()=>Si,Transfer:()=>nr,Tree:()=>ci,TreeSelect:()=>Wn,Typography:()=>_i,Upload:()=>rr,UploadDragger:()=>ir,Void:()=>br,Watermark:()=>xi});Pn.silent(!0);var Mi={title:`title`,description:`description`,default:`value`,enum:`dataSource`,readOnly:`readOnly`,writeOnly:`editable`,required:`required`,"x-content":`content`,"x-value":`value`,"x-editable":`editable`,"x-disabled":`disabled`,"x-read-pretty":`readPretty`,"x-read-only":`readOnly`,"x-visible":`visible`,"x-hidden":`hidden`,"x-display":`display`,"x-pattern":`pattern`},Ni={title:!0,description:!0,default:!0,"x-content":!0,"x-value":!0},Pi=e=>xn(e)&&/^\{\{.*\}\}$/.test(e),Fi=e=>{if(typeof e==`object`){let t=jn(e);return Mn(e,(e,n,r)=>{if(Pi(n))return e;{let i=Fi(n);return i==null?e:t?e.concat([i]):(e[r]=i,e)}},t?[]:{})}if(!Pi(e))return e},Ii=(e,t,n,r)=>{let i={};wn(Mi,(t,n)=>{let r=e[n];if(Pi(r)){if(!Ni[n])return;if(r){i[t]=r;return}}else r&&(i[t]=Fi(r))}),t.FormItem||=Ee;let a=e[`x-decorator`]&&Sn.getIn(t,e[`x-decorator`]),o=e[`x-component`]&&Sn.getIn(t,e[`x-component`]),s=Fi(e[`x-decorator-props`]||{}),c=Fi(e[`x-component-props`]||{});return a&&(i.decorator=[a,Cn(s)]),o&&(i.component=[o,Cn(c)]),a?Sn.setIn(i.decorator[1],n,r):o&&Sn.setIn(i.component[1],n,r),i.title=i.title&&(0,D.jsx)(`span`,{"data-content-editable":`title`,children:i.title}),i.description=i.description&&(0,D.jsx)(`span`,{"data-content-editable":`description`,children:i.description}),i},Li=x(e=>{let t=kt(),n=Pe(),r=g();if(!r)return null;let i=Ii(e,n,t.props.nodeIdAttrName,r.id);if(e.type===`object`){let t=(0,D.jsx)(Kt,{...i,name:r.id,children:e.children});return e[`x-component`]?t:(0,D.jsx)(Ln,{children:t})}return e.type===`array`?(0,D.jsx)(nn,{...i,name:r.id}):r.props.type===`void`?(0,D.jsx)(cn,{...i,name:r.id,children:e.children}):(0,D.jsx)(jt,{...i,name:r.id})});Li.Behavior=y({name:`Field`,selector:`Field`,designerLocales:Bn});var Ri=[{label:`URL地址`,value:`url`},{label:`邮箱格式`,value:`email`},{label:`数字格式`,value:`number`},{label:`整数格式`,value:`integer`},{label:`身份证格式`,value:`idcard`},{label:`手机号格式`,value:`phone`},{label:`货币格式`,value:`money`},{label:`中文格式`,value:`zh`},{label:`日期格式`,value:`date`},{label:`邮编格式`,value:`zip`}],zi={"zh-CN":{settings:{"x-validator":{title:`校验规则`,addValidatorRules:`添加校验规则`,drawer:`配置规则`,triggerType:{title:`触发类型`,placeholder:`请选择`,dataSource:[`输入时`,`聚焦时`,`失焦时`]},format:{title:`格式校验`,placeholder:`请选择`,dataSource:Ri},validator:{title:`自定义校验器`,tooltip:`格式: function (value){ return "Error Message"}`},pattern:`正则表达式`,len:`长度限制`,max:`长度/数值小于`,min:`长度/数值大于`,exclusiveMaximum:`长度/数值小于等于`,exclusiveMinimum:`长度/数值大于等于`,whitespace:`不允许空白符`,required:`是否必填`,message:{title:`错误消息`,tooltip:`错误消息只对当前规则集的一个内置规则生效，如果需要对不同内置规则定制错误消息，请拆分成多条规则`}}},SettingComponents:{DataSourceSetter:{nodeProperty:`节点属性`,pleaseSelectNode:`请先选择左侧树节点`,addKeyValuePair:`添加键值对`,configureDataSource:`配置可选项`,dataSource:`可选项`,defaultTitle:`默认标题`,dataSourceTree:`可选项节点树`,addNode:`新增节点`,label:`键名`,value:`键值`,item:`选项`},ReactionsSetter:{configureReactions:`配置响应器`,relationsFields:`依赖字段`,variableName:`变量名`,variableNameValidateMessage:`不符合变量命名规则`,pleaseInput:`请输入`,sourceField:`来源字段`,sourceProperty:`字段属性`,variableType:`变量类型`,operations:`操作`,addRelationField:`添加依赖字段`,propertyReactions:`属性响应(仅支持JS表达式)`,actionReactions:`动作响应(高级，可选，支持JS语句)`,visible:`显示/隐藏`,hidden:`UI隐藏`,display:`展示状态`,pattern:`UI形态`,title:`标题`,description:`描述`,value:`字段值`,initialValue:`默认值`,dataSource:`可选项`,required:`是否必填`,component:`组件`,componentProps:`组件属性`,decorator:`容器`,decoratorProps:`容器属性`,pleaseSelect:`请选择`,expressionValueTypeIs:`表达式值类型为`},ValidatorSetter:{pleaseSelect:`请选择`,formats:Ri}}}},Bi=[{label:`URL`,value:`url`},{label:`Email`,value:`email`},{label:`Number`,value:`number`},{label:`Integer`,value:`integer`},{label:`ID`,value:`idcard`},{label:`Phone Number`,value:`phone`},{label:`Currency`,value:`money`},{label:`Chinese`,value:`zh`},{label:`Date`,value:`date`},{label:`Zip`,value:`zip`}],Vi={"en-US":{settings:{"x-validator":{title:`Validator`,addValidatorRules:`Add Validator Rules`,drawer:`Edit Rules`,triggerType:{title:`Trigger Type`,placeholder:`Please Select`,dataSource:[`onInput`,`onFocus`,`onBlur`]},format:{title:`Format`,placeholder:`Please Select`,dataSource:Bi},validator:{title:`Custom Validator`,tooltip:`Format: function (value){ return "Error Message"}`},pattern:`RegExp`,len:`Length Limit`,max:`Length/Value Lt`,min:`Length/Value Gt`,exclusiveMaximum:`Length/Value Lte`,exclusiveMinimum:`Length/Value Gte`,whitespace:`No Whitespace`,required:`Required`,message:{title:`Error Message`,tooltip:`The error message is only effective for one built-in rule of the current rule set. If you need to customize the error message for different built-in rules, please split into multiple rules`}}},SettingComponents:{DataSourceSetter:{nodeProperty:`Node Property`,pleaseSelectNode:`please select node from the tree on the left`,addKeyValuePair:`Add Key Value Pair`,configureDataSource:`Configure`,dataSource:`Options`,defaultTitle:`Default Title`,dataSourceTree:`Options Tree`,addNode:`Add Node`,label:`label`,value:`value`,item:`Item`},ReactionsSetter:{configureReactions:`Configure`,relationsFields:`Associated Fields`,variableName:`Variable Name`,variableNameValidateMessage:`This is not a standard variable name`,pleaseInput:`Please Input`,sourceField:`Source Field`,sourceProperty:`Field Property`,variableType:`Variable Type`,operations:`Operations`,addRelationField:`Add Associated Field`,propertyReactions:`Property Reactions(Only Support Javascript Expression)`,actionReactions:`Action Reactions(Optional, Support Javascript Statement)`,visible:`Show/None`,hidden:`Show/UI Hidden`,display:`Display`,pattern:`Pattern`,title:`Title`,description:`Description`,value:`Value`,initialValue:`InitialValue`,dataSource:`Options`,required:`Required`,component:`Component`,componentProps:`Component Props`,decorator:`Decorator`,decoratorProps:`Decorator Props`,pleaseSelect:`Please Select`,expressionValueTypeIs:`Expression value type is`},ValidatorSetter:{pleaseSelect:`Please Select`,formats:Bi}}}};w.registerDesignerLocales(zi,Vi);var Hi=e(ne(),1),Ui=x(({extra:e,title:t})=>{let n=v(`data-source-setter`);return(0,D.jsxs)(`div`,{className:`${n+`-layout-item-header`}`,children:[(0,D.jsx)(`div`,{className:`${n+`-layout-item-title`}`,children:t}),e]})}),k=(e,t)=>{for(let n=0;n<e.length;n++)t(e[n],n,e),e[n]?.children&&k(e[n]?.children||[],t)},Wi=e=>{let t=bn(e);return k(t,(e,t,n)=>{let r={key:``,duplicateKey:``,map:[],children:[]};for(let[e,i]of Object.entries(n[t]||{}))e!==`children`&&r.map.push({label:e,value:i});let i=Dn();r.key=i,r.duplicateKey=i,r.children=n[t].children||[],n[t]=r}),t},Gi=e=>{let t=bn(e);return k(t,(e,t,n)=>{let r={children:[]};T(n[t].map).forEach(e=>{e.label&&(r[e.label]=e.value)}),r.children=n[t]?.children||[],n[t]=r}),t},A=le({components:{FormItem:Ee,Input:ut,ArrayItems:xt,ValueInput:Yt}}),Ki=x(e=>{let{allowExtendOption:t,effects:n}=e,r=v(`data-source-setter`),i=(0,E.useMemo)(()=>{let t;return k(e.treeDataSource.dataSource,n=>{n.key===e.treeDataSource.selectedKey&&(t=n)}),On({values:t,effects:n})},[e.treeDataSource.selectedKey,e.treeDataSource.dataSource.length]);return e.treeDataSource.selectedKey?(0,D.jsxs)(E.Fragment,{children:[(0,D.jsx)(Ui,{title:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.nodeProperty`}),extra:t?(0,D.jsx)(u,{type:`text`,onClick:()=>{i.setFieldState(`map`,e=>{e.value.push({})})},icon:(0,D.jsx)(Gt,{}),children:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.addKeyValuePair`})}):null}),(0,D.jsx)(`div`,{className:`${r+`-layout-item-content`}`,children:(0,D.jsx)(pt,{form:i,labelWidth:60,wrapperWidth:160,children:(0,D.jsx)(A,{children:(0,D.jsx)(A.Array,{name:`map`,"x-component":`ArrayItems`,children:(0,D.jsxs)(A.Object,{"x-decorator":`ArrayItems.Item`,"x-decorator-props":{type:`divide`},children:[(0,D.jsx)(A.String,{title:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.label`}),"x-decorator":`FormItem`,"x-disabled":!t,name:`label`,"x-component":`Input`}),(0,D.jsx)(A.String,{title:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.value`}),"x-decorator":`FormItem`,name:`value`,"x-component":`ValueInput`}),(0,D.jsx)(A.Void,{"x-component":`ArrayItems.Remove`,"x-visible":t,"x-component-props":{style:{margin:5,display:`flex`,justifyContent:`center`,alignItems:`center`}}})]})})})})})]}):(0,D.jsxs)(E.Fragment,{children:[(0,D.jsx)(Ui,{title:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.nodeProperty`}),extra:null}),(0,D.jsx)(`div`,{className:`${r+`-layout-item-content`}`,children:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.pleaseSelectNode`})})]})}),qi=x(e=>{let t=v(`data-source-setter-node-title`),n=e=>{let t=[`label`,`title`,`header`],n;return t.some(t=>{let r=T(e).find(e=>e.label===t)?.value;return r!==void 0&&(n=r,!0)}),n===void 0&&T(e||[]).some(e=>e.value&&typeof e.value==`string`?(n=e.value,!0):!1),n};return(0,D.jsxs)(`div`,{className:t,children:[(0,D.jsx)(`span`,{style:{marginRight:`5px`},children:(e=>{let t=n(e);return t===void 0?(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.defaultTitle`}):t+``})(e?.map||[])}),(0,D.jsx)(Ie,{className:t+`-icon`,infer:`Remove`,onClick:()=>{let t=bn(e?.treeDataSource?.dataSource);k(t||[],(t,n,r)=>{r[n].key===e.duplicateKey&&T(r).splice(n,1)}),e.treeDataSource.dataSource=t}})]})}),Ji=({dropPosition:e})=>e!==0,Yi=x(e=>{let t=v(`data-source-setter`);return(0,D.jsxs)(E.Fragment,{children:[(0,D.jsx)(Ui,{title:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.dataSourceTree`}),extra:(0,D.jsx)(u,{type:`text`,onClick:()=>{let t=Dn(),n=e.treeDataSource.dataSource,r=e.defaultOptionValue?.map(e=>({...e}))||[{label:`label`,value:`${w.getDesignerMessage(`SettingComponents.DataSourceSetter.item`)} ${n.length+1}`},{label:`value`,value:t}];e.treeDataSource.dataSource=n.concat({key:t,duplicateKey:t,map:r,children:[]})},icon:(0,D.jsx)(Ie,{infer:`Add`}),children:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.addNode`})})}),(0,D.jsx)(`div`,{className:`${t+`-layout-item-content`}`,children:(0,D.jsx)(rt,{blockNode:!0,draggable:!0,allowDrop:e.allowTree?()=>!0:Ji,defaultExpandAll:!0,defaultExpandParent:!0,autoExpandParent:!0,showLine:{showLeafIcon:!1},treeData:e.treeDataSource.dataSource,onDragEnter:()=>{},onDrop:t=>{let n=t.node?.key,r=t.dragNode?.key,i=t.node.pos.split(`-`),a=t.dropPosition-Number(i[i.length-1]),o=[...e.treeDataSource.dataSource],s={key:``};if(k(o,(e,t,n)=>{n[t].key===r&&(n.splice(t,1),s=e)}),!t.dropToGap)k(o,e=>{e.key===n&&(e.children=e.children||[],e.children.unshift(s))});else if((t.node.children||[]).length>0&&t.node.expanded&&a===1)k(o,e=>{e.key===n&&(e.children=e.children||[],e.children.unshift(s))});else{let e=[],t=0;k(o,(r,i,a)=>{r.key===n&&(e=a,t=i)}),a===-1?e.splice(t,0,s):e.splice(t+1,0,s)}e.treeDataSource.dataSource=o},titleRender:t=>(0,D.jsx)(qi,{...t,treeDataSource:e.treeDataSource}),onSelect:t=>{t[0]&&(e.treeDataSource.selectedKey=t[0].toString())}})})]})}),Xi=x(e=>{let{className:t,value:n=[],onChange:r,allowTree:i=!0,allowExtendOption:a=!0,defaultOptionValue:o,effects:s=()=>{}}=e,c=de(),l=v(`data-source-setter`),[ee,te]=(0,E.useState)(!1),ne=(0,E.useMemo)(()=>En({dataSource:Wi(n),selectedKey:``}),[n,ee]),re=()=>te(!0),ie=()=>te(!1);return(0,D.jsxs)(E.Fragment,{children:[(0,D.jsx)(u,{block:!0,onClick:re,children:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.configureDataSource`})}),(0,D.jsx)(Rt,{title:(0,D.jsx)(m,{token:`SettingComponents.DataSourceSetter.configureDataSource`}),width:`65%`,bodyStyle:{padding:10},transitionName:``,maskTransitionName:``,open:ee,onCancel:ie,onOk:()=>{r(Gi(ne.dataSource)),ie()},children:(0,D.jsxs)(`div`,{className:`${(0,Hi.default)(l,t)} ${l+`-`+c} ${l+`-layout`}`,children:[(0,D.jsx)(`div`,{className:`${l+`-layout-item left`}`,children:(0,D.jsx)(Yi,{defaultOptionValue:o,allowTree:i,treeDataSource:ne})}),(0,D.jsx)(`div`,{className:`${l+`-layout-item right`}`,children:(0,D.jsx)(Ki,{allowExtendOption:a,treeDataSource:ne,effects:s})})]})})]})}),Zi=e=>{let t=e,n=e=>{let t=``;for(let n=0;n<e;n++)t+=`.`;return t},r=(e,t)=>{let n=[],r=t=>{t&&t!==e?n.push(t.props.name||t.id):r(t.parent)};return r(t),n.reverse().join(`.`)},i=e=>e.children?.some(e=>e.props.type!==`void`&&e!==t||i(e)),a=e=>e?.parent?e?.parent?.componentName===e.componentName?a(e.parent):e.parent:e,o=e=>{if(e?.parent){if(e.parent.props.type===`array`)return e.parent;if(e.parent!==l)return o(e.parent)}},s=(e,i)=>i.depth===t.depth?`.${i.props.name||i.id}`:`${n(t.depth-e.depth)}[].${r(e,i)}`,c=(e,n=[])=>e.reduce((e,r)=>{if(r===t||r.props.type===`array`&&!r.contains(t)||r.props.type===`void`&&!i(r))return e;let a=n.concat(r.props.name||r.id),l=o(r),ee=r.props.title||r.props[`x-component-props`]?.title||r.props.name||r.designerProps.title,te=l?s(l,r):a.join(`.`);return e.concat({label:ee,value:te,node:r,children:c(r.children,a)})},[]),l=a(e);return l?c(l.children):[]},Qi=e=>{let t=Zi(bt()),n=(e,t)=>{for(let r=0;r<e.length;r++){let i=e[r];if(i.value===t)return i.node;if(i.children?.length){let e=n(i.children,t);if(e)return e}}};return(0,D.jsx)(Ct,{...e,onChange:r=>{e.onChange?.(r,n(t,r))},treeDefaultExpandAll:!0,treeData:t})},j=`
/**
 * You can use the built-in context variables
 *
 * 1. \`$chrome\` 桥接浏览器扩展开发时的 chrome 对象的常用方法。目前只桥接了部分，还在完善中
 *     如果发现有不支持的方法，可用 $chrome.callMethodByPath 替代
 *     如果发现有不支持的属性，可用 $chrome.getPropertyByPath 替代
 *
 * 2. \`$ga\` 小助手暴露到低代码页面中的扩展开发的一些常用方法
 *
 * 3. \`$utils\` 小助手暴露到低代码页面中的常用工具方法
 *
 * 4. \`$self\` is the current Field Model
 *
 * 5. \`$form\` is the current Form Model
 *
 * 6. \`$deps\` is the dependencies value
 *
 * 7. \`$observable\` function is used to create an persistent observable state object
 *
 * 8. \`$memo\` function is is used to create a persistent data
 *
 * 9. \`$effect\` function is used to handle side-effect logic
 *
 * 10. \`$props\` function is used to set component props to current field
 *
 * Document Links
 *
 * https://react.formilyjs.org/api/shared/schema#%E5%86%85%E7%BD%AE%E8%A1%A8%E8%BE%BE%E5%BC%8F%E4%BD%9C%E7%94%A8%E5%9F%9F
 **/
`,$i=`
/** 
 * Example 1
 * Static Boolean
 **/

false

/** 
 * Example 2
 * Equal Calculation
 **/

$deps.VariableName === 'TARGET_VALUE'

/** 
 * Example 3
 * Not Equal Calculation
 **/

$deps.VariableName !== 'TARGET_VALUE'

/** 
 * Example 4
 * And Logic Calculation
 **/

$deps.VariableName1 && $deps.VariableName2

/** 
 * Example 5
 * Grater Logic Calculation
 **/

$deps.VariableName > 100

/** 
 * Example 6
 * Not Logic Calculation
 **/

!$deps.VariableName

${j}
`,ea=`
/** 
 * Example 1
 * Static Mode
 **/

'none'

/** 
 * Example 2
 * Equal Condition Associated
 **/

$deps.VariableName === 'TARGET_VALUE' ? 'visible' : 'none'

/** 
 * Example 3
 * Not Equal Condition Associated
 **/

$deps.VariableName !== 'TARGET_VALUE' ? 'visible' : 'hidden'

/** 
 * Example 4
 * And Logic Condition Associated
 **/

$deps.VariableName1 && $deps.VariableName2 ? 'visible' : 'none'

/** 
 * Example 5
 * Grater Logic Condition Associated
 **/

$deps.VariableName > 100 ? 'visible' : 'hidden'

/** 
 * Example 6
 * Not Logic Condition Associated
 **/

!$deps.VariableName ? 'visible' : 'none'

${j}
`,ta=`
/** 
 * Example 1
 * Static Mode
 **/

'readPretty'

/** 
 * Example 2
 * Equal Condition Associated
 **/

$deps.VariableName === 'TARGET_VALUE' ? 'editable' : 'disabled'

/** 
 * Example 3
 * Not Equal Condition Associated
 **/

$deps.VariableName !== 'TARGET_VALUE' ? 'editable' : 'readOnly'

/** 
 * Example 4
 * And Logic Condition Associated
 **/

$deps.VariableName1 && $deps.VariableName2 ? 'editable' : 'readPretty'

/** 
 * Example 5
 * Grater Logic Condition Associated
 **/

$deps.VariableName > 100 ? 'editable' : 'readOnly'

/** 
 * Example 6
 * Not Logic Condition Associated
 **/

!$deps.VariableName ? 'editable' : 'disabled'

${j}
`,na=`
/** 
 * Example 1
 * Static String
 **/

'Normal String Text'

/** 
 * Example 2
 * Associated String
 **/

$deps.VariableName === 'TARGET_VALUE' ? 'Associated String Text' : ''

${j}
`,ra=`
/** 
 * Example 1
 * String Type
 **/

'String'

/** 
 * Example 2
 * String Array
 **/

['StringArray']

/** 
 * Example 3
 * Object Array
 **/

[{ key: 'ObjectArray' }]

/** 
 * Example 4
 * Boolean
 **/

true

/** 
 * Example 5
 * RegExp
 **/

/\d+/

/** 
 * Example 1
 * Associated String Value
 **/

$deps.VariableName + 'Compose String'

/** 
 * Example 2
 * Associated Array Value
 **/

[ $deps.VariableName ]

/** 
 * Example 3
 * Associated Object Value
 **/

{
  key : $deps.VariableName
}

/** 
 * Example 4
 * Associated Boolean Value
 **/

!$deps.VariableName

${j}
`,ia=`
/** 
 * Example 1
 * Static DataSource
 **/

[
  { label : "item1", value: "1" },
  { label : "item2", value: "2" }
]

/** 
 * Example 2
 * Associated DataSource
 **/

[
  { label : "item1", value: "1" },
  { label : "item2", value: "2" },
  ...$deps.VariableName
]

${j}
`,aa=`
/** 
 * Example 1
 * Static Props
 **/

{
  placeholder: "This is placeholder"
}

/** 
 * Example 2
 * Associated Props
 **/

{
  placeholder: $deps.VariableName
}

${j}
`,oa=`
/** 
 * Example 1
 * Static Props
 **/

{
  labelCol:6
}

/** 
 * Example 2
 * Associated Props
 **/

{
  labelCol: $deps.VariableName
}

${j}
`,sa=`
/**
 * 监听输入框回车事件
 **/
$props({
  onPressEnter: (e) => {
    const keyword = e.target.value
    if (!keyword) {
      return
    }

    $message.info(\`TODO 搜索关键词\${keyword}\`)
  },
})

/**
 * 添加点击事件
 **/
$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})

/**
 * 展示 confirm 弹窗
 **/
$props({
  onClick: () => {
    $modal.confirm({
      title: "我是标题",
      content: "我是内容",
      okText: "确认",
      onOk: () => {
        $message.success("点击了确认")
      },
      cancelText: "取消",
      onCancel: () => {
        $message.info("点击了取消")
      },
    })
  },
})

/**
 * 点击后编辑当前页面
 **/
$props({
  onClick: () => {
    $ga.editCurrentPage()
  },
})

/**
 * 点击打开低代码页面管理页面
 **/
$props({
  onClick: () => {
    $ga.lowCodePageManage()
  },
})

/**
 * 点击打开用户脚本管理页面
 **/
$props({
  onClick: () => {
    $ga.userScriptManage()
  },
})

/**
 * 点击打开设置上帝小助手页面
 **/
$props({
  onClick: () => {
    $ga.settingAssistant()
  },
})

/**
 * 操作系统通知
 */
$props({
  onClick: () => {
    let myNotificationId

    // 创建系统通知
    $chrome.notifications.create(
      null,
      {
        type: "basic",
        title: "我是标题",
        message: "我是内容",
        iconUrl: "../images/128.png",
      },
      $chrome.proxy((notificationId) => {
        myNotificationId = notificationId
        $message.info(\`创建的系统通知 ID 为 \${notificationId}\`)
      })
    )

    // 延迟 3 秒更新系统通知
    setTimeout(() => {
      $chrome.notifications.update(
        myNotificationId,
        {
          type: "basic",
          title: "我是修改后的标题",
          message: "我是修改后内容",
          iconUrl: "../images/128.png",
        },
        $chrome.proxy((wasUpdated) => {
          $message.info(\`更新系统通知 \${wasUpdated}\`)
        })
      )
    }, 3000)

    // 延迟 6 秒清除系统通知
    setTimeout(() => {
      $chrome.notifications.clear(
        myNotificationId,
        $chrome.proxy((wasCleared) => {
          $message.info(\`清除系统通知 \${wasCleared}\`)
        })
      )
    }, 6000)
  },
})

/**
 * 获取指定的循环类组件的条目和索引
 * 使用场景：需要同时获取条目和索引
 */
$props({
  onClick: () => {
    // 第二个参数是可选的，默认值就是循环布局组件 IteratorLayout
    // const { row, index } = $utils.getArrayFieldRowAndIndex($self, "IteratorLayout")
    const { row, index } = $utils.getArrayFieldRowAndIndex($self)
    $message.info(\`点击了 \${index} | \${JSON.stringify(row)}\`)
  },
})

/**
 * 获取指定的循环类组件的条目
 * 使用场景：只需获取条目，不需获取索引
 */
$props({
  onClick: () => {
    // 第二个参数是可选的，默认值就是循环布局组件 IteratorLayout
    // const row = $utils.getArrayFieldRow($self, "IteratorLayout")
    const row = $utils.getArrayFieldRow($self)
    $message.info(\`点击了 \${JSON.stringify(row)}\`)
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-推荐
 */
$props({
  onClick: () => {
    // 默认就是取的条目的 url 字段来打开
    $utils.clickArrayFieldUrlItem($self)
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-相对复杂版本，仅用于演示 API 的使用
 */
$props({
  onClick: () => {
    // 获取迭代器布局中当前点击的条目数据
    const row = $utils.getArrayFieldRow($self)
    // openUrl 内部会自动区分编辑器环境（新标签）还是预览环境（当前标签）打来链接
    $utils.openUrl(row.url)
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-较复杂版本，仅用于演示 API 的使用
 */
$props({
  onClick: () => {
    // 获取迭代器布局中当前点击的条目数据
    const row = $utils.getArrayFieldRow($self)

    if ($utils.isEditorEnv) {
      // 编辑器环境 => 新建一个标签页打开链接
      $utils.openUrlInNewTab(tab.url)
    } else {
      // 预览环境 => 当前窗口选中的标签页替换链接
      $utils.openUrlInCurrentTab(row.url)
    }
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-最复杂版本，仅用于演示 API 的使用
 */
$props({
  onClick: async () => {
    // 获取迭代器布局中当前点击的条目数据
    const row = $utils.getArrayFieldRow($self)

    if ($utils.isEditorEnv) {
      // 编辑器环境 => 新建一个标签页打开链接
      $chrome.tabs.create({
        url: row.url,
      })
    } else {
      // 预览环境 => 当前窗口选中的标签页替换链接
      const tab = await $chrome.tabs.query({
        active: true,
        currentWindow: true,
      })
      $chrome.tabs.update(tab.id, { url: row.url })
    }
  },
})

/**
 * 处理点击指定的循环类组件的条目链接-最复杂版本
 */
$props({
  onClick: async () => {
    // 获取迭代器布局中当前点击的条目数据
    const row = $utils.getArrayFieldRow($self)

    if ($utils.isEditorEnv) {
      // 编辑器环境 => 新建一个标签页打开链接
      $chrome.tabs.create({
        url: row.url,
      })
    } else {
      // 预览环境 => 当前窗口选中的标签页替换链接
      const tab = await $chrome.tabs.query({
        active: true,
        currentWindow: true,
      })
      $chrome.tabs.update(tab.id, { url: row.url })
    }
  },
})

/**
 * 设置指定的循环类组件内部的图标-推荐
 */
$effect(() => {
  // 后面 3 个参数都是可选的
  // $utils.setArrayFieldRowBookmarkIcon($self, "url", "icon", "IteratorLayout")
  $utils.setArrayFieldRowBookmarkIcon($self)
}, [])

/**
 * 设置指定的循环类组件内部的图标-相对复杂版本，仅用于演示 API 的使用
 */
$effect(() => {
  // 获取迭代器布局中当前点击的条目数据
  const row = $utils.getArrayFieldRow($self)
  // 获取书签的图标地址
  $utils.getBookmarkIconUrl(row.url, row.icon).then((iconUrl) => {
    $props({
      src: iconUrl,
    })
  })
}, [])

/**
 * 操作剪贴板
 **/
$props({
  onClick: async () => {
    // 复制文本到剪贴板
    $utils.copyTextToClipboard("我是剪贴板内容")

    // 从剪贴板读取内容
    const text = await $utils.readTextFromClipboard()
    $message.info(\`获取到剪贴板内容 \${text}\`)
  },
})

/**
 * Example 1
 * Async Select
 **/
$effect(()=>{
  $self.loading = true
  fetch('//some.domain/getSomething')
    .then(response=>response.json())
    .then(({ data })=>{
      $self.loading = false
      $self.dataSource = data
    },()=>{
      $self.loading = false
    })
},[])

/**
 * Example 2
 * Async Search Select
 **/
const state = $observable({
  keyword:''
})

$props({
  onSearch(keyword){
    state.keyword = keyword
  }
})

$effect(()=>{
  $self.loading = true
  fetch(\`//some.domain/getSomething?q=\${state.keyword}\`)
    .then(response=>response.json())
    .then(({ data })=>{
      $self.loading = false
      $self.dataSource = data
    },()=>{
      $self.loading = false
    })
},[ state.keyword ])

/**
 * Example 3
 * Async Associated Select
 **/

const state = $observable({
  keyword:''
})

$props({
  onSearch(keyword){
    state.keyword = keyword
  }
})

$effect(()=>{
  $self.loading = true
  fetch(\`//some.domain/getSomething?q=\${state.keyword}&other=\${$deps.VariableName}\`)
    .then(response=>response.json())
    .then(({ data })=>{
      $self.loading = false
      $self.dataSource = data
    },()=>{
      $self.loading = false
    })
},[ state.keyword, $deps.VariableName ])

${j}
`,ca=[{key:`visible`,type:`boolean`,helpCode:$i},{key:`hidden`,type:`boolean`,helpCode:$i},{key:`display`,type:`"visible" | "hidden" | "none"`,helpCode:ea},{key:`pattern`,type:`"editable" | "disabled" | "readOnly" | "readPretty"`,helpCode:ta},{key:`title`,type:`string`,helpCode:na},{key:`description`,type:`string`,helpCode:na},{key:`value`,type:`any`,helpCode:ra},{key:`initialValue`,type:`any`,helpCode:ra},{key:`required`,type:`boolean`,helpCode:$i},{key:`dataSource`,type:`Array<{label?:string,value?:any}>`,helpCode:ia},{key:`componentProps`,token:`componentProps`,type:`object`,helpCode:aa},{key:`decoratorProps`,token:`decoratorProps`,type:`object`,helpCode:oa}],la=e=>{if(e)return e.trim()},ua=e=>{let[t,n]=(0,E.useState)([`visible`]),r=v(`field-property-setter`),i={...e.value},a=e=>e&&String(e).match(/^\{\{([\s\S]*)\}\}$/)?.[1]||``,o=e=>Mn(e,(e,t,n)=>(!t||t===`{{}}`||(e[n]=t),e),{}),s=ca.find(e=>e.key===t[0]);return(0,D.jsxs)(`div`,{className:r,children:[(0,D.jsx)(ce,{mode:`vertical`,style:{width:200,height:300,paddingRight:4,overflowY:`auto`,overflowX:`hidden`},defaultSelectedKeys:t,selectedKeys:t,onSelect:({selectedKeys:e})=>{n(e)},children:ca.map(e=>Tn(e)?(0,D.jsx)(ce.Item,{children:(0,D.jsx)(m,{token:`SettingComponents.ReactionsSetter.${e.token||e.key}`})},e.key):(0,D.jsx)(ce.Item,{children:(0,D.jsx)(m,{token:`SettingComponents.ReactionsSetter.${e}`})},e))}),(0,D.jsxs)(`div`,{className:r+`-coder-wrapper`,children:[(0,D.jsxs)(`div`,{className:r+`-coder-start`,children:[`$self.${t[0]} = (`,(0,D.jsxs)(`span`,{style:{fontSize:14,marginLeft:10,color:`#888`,fontWeight:`normal`},children:[`//`,` `,(0,D.jsx)(m,{token:`SettingComponents.ReactionsSetter.expressionValueTypeIs`}),` `,"`",s?.type,"`"]})]}),(0,D.jsx)(`div`,{className:r+`-coder`,children:(0,D.jsx)(an,{language:`javascript.expression`,extraLib:e.extraLib,helpCode:la(s?.helpCode),value:a(i[t[0]]),options:{lineNumbers:`off`,wordWrap:`on`,glyphMargin:!1,folding:!1,lineDecorationsWidth:0,lineNumbersMinChars:0,minimap:{enabled:!1}},onChange:n=>{e.onChange?.(o({...i,[t[0]]:`{{${n}}}`}))}},t[0])}),(0,D.jsx)(`div`,{className:r+`-coder-end`,children:`)`})]})]})},da=`
/**
 * 桥接浏览器扩展开发时的 chrome 对象的常用方法。目前只桥接了部分，还在完善中
 * 如果发现有不支持的方法，可用 $chrome.callMethodByPath 替代
 * 如果发现有不支持的属性，可用 $chrome.getPropertyByPath 替代
 */
export interface IChrome {
  /**
   * 沙箱中不支持访问 window.localStorage，该对象桥接的 window.localStorage
   */
  localStorage: ILocalStorage
  /**
   * 桥接 window.fetch，用于支持跨域发起网络请求。
   * 注意：返回的是 IBridgeResponse 而非原生 Response。
   * IBridgeResponse 是普通可克隆对象，status/ok/headers 等属性可直接同步读取；
   * body 内容通过 text() / json() / blob() / arrayBuffer() 方法获取。
   * 流式请求（SSE）时 body 为 ReadableStream，可通过 body.getReader() 消费。
   */
  fetch(input: RequestInfo | URL, init?: RequestInit): Promise<IBridgeResponse>
  /**
   * 代理对象或回调方法
   */
  proxy<T extends {}>(obj: T): T & ProxyMarked
  /**
   * 根据路径执行 chrome.aa.bb.cc 方法
   * @param apiPath api 路径，例如 'storage.local.get'
   * @param arg1 方法参数1
   * @param arg2 方法参数2
   * @param arg3 方法参数3
   * @param arg4 方法参数4
   * @returns 对应方法执行结果
   */
  callMethodByPath(
    apiPath: string,
    arg1?: any,
    arg2?: any,
    arg3?: any,
    arg4?: any
  ): Promise<any>
  /**
   * 根据路径获取 chrome.aa.bb.cc 属性
   * @param propertyPath property 路径，例如 'runtime.id'
   * @returns 对应属性的值
   */
  getPropertyByPath(propertyPath: string): Promise<any>
  /**
   * 复制图片到剪贴板
   * @param imageUrl 要复制的图片 URL
   */
  copyImageToClipboard(imageUrl: string): Promise<void>
  /**
   * 桥接 chrome.storage
   */
  storage: IStorage
  /**
   * 桥接 chrome.runtime
   */
  runtime: IRuntime
  /**
   * 桥接 chrome.tabs
   */
  tabs: ITabs
  /**
   * 桥接 chrome.windows
   */
  windows: IWindows
  /**
   * 桥接 chrome.notifications
   */
  notifications: INotifications
  /**
   * 桥接 chrome.userScripts
   */
  userScripts: IUserScript
  /**
   * 桥接 chrome.action（Badge、Popup、图标、tooltip、启用/禁用）
   */
  action: IAction
  /**
   * 桥接 chrome.contextMenus（右键菜单 CRUD）
   */
  contextMenus: IContextMenus
  /**
   * 桥接 chrome.cookies（Cookie 读写）
   */
  cookies: ICookies
  /**
   * 桥接 chrome.downloads（下载管理）
   */
  downloads: IDownloads
  /**
   * 桥接 chrome.alarms（定时任务，MV3 下替代 setInterval）
   */
  alarms: IAlarms
  /**
   * 桥接 chrome.sidePanel（侧边栏配置与关闭）
   * 注意：open() 需要用户手势，请在事件回调中通过 callMethodByPath('sidePanel.open', options) 调用
   */
  sidePanel: ISidePanel
  /**
   * 桥接 chrome.tabGroups（Tab 分组管理）
   */
  tabGroups: ITabGroups
  /**
   * 桥接 chrome.scripting（MV3 脚本/CSS 注入，替代旧版 tabs.executeScript）
   */
  scripting: IScripting
}

/**
 * 桥接 fetch 的响应对象。
 * 与原生 Response 不同，IBridgeResponse 是普通可克隆的数据对象，
 * status/ok/headers 等属性可直接同步读取，无需额外 await。
 *
 * body 的两种形态：
 * - 非流式请求（默认）：body 为 null，使用 text()/json()/blob()/arrayBuffer() 获取内容
 * - 流式请求（SSE 等）：body 为 ReadableStream，可通过 body.getReader() 逐 chunk 消费
 */
export interface IBridgeResponse {
  /** HTTP 状态码（如 200、404）。 */
  status: number
  /** HTTP 状态描述文字（如 "OK"）。 */
  statusText: string
  /** 状态码是否在 200-299 范围内。 */
  ok: boolean
  /** 响应是否经过重定向。 */
  redirected: boolean
  /** 最终响应的 URL。 */
  url: string
  /** 响应头键值对。 */
  headers: Record<string, string>
  /**
   * 响应 body 流。
   * - 非流式响应时为 null
   * - 流式响应（SSE 等）时为 ReadableStream
   */
  body: ReadableStream<Uint8Array> | null
  /** 将响应体读取为 ArrayBuffer。 */
  arrayBuffer(): Promise<ArrayBuffer>
  /** 将响应体以 UTF-8 解码为字符串。 */
  text(): Promise<string>
  /** 将响应体以 UTF-8 解码后 JSON.parse。 */
  json<T = any>(): Promise<T>
  /** 将响应体构造为 Blob，content-type 取自 headers。 */
  blob(): Promise<Blob>
}

/**
 * 沙箱中不支持访问 window.localStorage，该对象桥接的 window.localStorage
 */
export interface ILocalStorage {
  getItem(key: string): Promise<string | null>
  setItem(key: string, value: string): Promise<void>
  removeItem(key: string): Promise<void>
  clear(): Promise<void>
}


export type ColorArray = [number, number, number, number];

export interface BadgeTextDetails {
  /** Badge 显示的文字。若设置为空字符串，则清除 badge 文字。 */
  text?: string | null | undefined;
  /** 可选。指定哪个 tab 的 badge。若未设置则应用于全局。 */
  tabId?: number | undefined;
}

export interface TabDetails {
  /** 可选。指定 tab id。若未设置则返回全局值。 */
  tabId?: number | undefined;
}

export interface BadgeColorDetails {
  /** 一个包含四个整数的数组 [r, g, b, a]，范围 0-255，或表示 CSS 颜色值的字符串。 */
  color: string | ColorArray;
  /** 可选。指定哪个 tab。若未设置则应用于全局。 */
  tabId?: number | undefined;
}

export interface TabIconDetails {
  /** 可选。指向图片文件的相对路径或 ImageData 对象字典。 */
  path?: string | { [key: string]: string } | undefined;
  /** 可选。指定哪个 tab。若未设置则应用于全局。 */
  tabId?: number | undefined;
  /** 可选。ImageData 对象。 */
  imageData?: ImageData | { [key: number]: ImageData } | undefined;
}

export interface PopupDetails {
  /** 弹出页面的 HTML 文件相对路径。 */
  popup: string;
  /** 可选。指定哪个 tab。若未设置则应用于全局。 */
  tabId?: number | undefined;
}

export interface TitleDetails {
  /** 鼠标悬停时显示的文字。 */
  title: string;
  /** 可选。指定哪个 tab。若未设置则应用于全局。 */
  tabId?: number | undefined;
}

export interface UserSettings {
  /** 扩展 action 是否固定到浏览器工具栏。 */
  isOnToolbar: boolean;
}

/**
 * 桥接 chrome.action
 */
export interface IAction {
  /** 设置 badge 上的文字（空字符串清除）。 */
  setBadgeText(details: BadgeTextDetails): Promise<void>
  /** 获取 badge 文字。 */
  getBadgeText(details: TabDetails): Promise<string>
  /** 设置 badge 背景色。 */
  setBadgeBackgroundColor(details: BadgeColorDetails): Promise<void>
  /** 获取 badge 背景色。 */
  getBadgeBackgroundColor(details: TabDetails): Promise<ColorArray>
  /** 设置工具栏图标。 */
  setIcon(details: TabIconDetails): Promise<void>
  /** 设置弹出页面。 */
  setPopup(details: PopupDetails): Promise<void>
  /** 获取弹出页面路径。 */
  getPopup(details: TabDetails): Promise<string>
  /** 设置 tooltip 标题。 */
  setTitle(details: TitleDetails): Promise<void>
  /** 获取 tooltip 标题。 */
  getTitle(details: TabDetails): Promise<string>
  /** 对指定 tab 启用扩展 action。 */
  enable(tabId?: number): Promise<void>
  /** 对指定 tab 禁用扩展 action。 */
  disable(tabId?: number): Promise<void>
  /** 判断扩展 action 对指定 tab 是否启用。 */
  isEnabled(tabId?: number): Promise<boolean>
  /** 获取用户设置（如是否钉在工具栏）。 */
  getUserSettings(): Promise<UserSettings>
  /** 设置 badge 文字颜色。 */
  setBadgeTextColor(details: BadgeColorDetails): Promise<void>
}


export type ContextType =
  | "all"
  | "page"
  | "frame"
  | "selection"
  | "link"
  | "editable"
  | "image"
  | "video"
  | "audio"
  | "launcher"
  | "browser_action"
  | "page_action"
  | "action";

export type ItemType = "normal" | "checkbox" | "radio" | "separator";

export interface ContextMenuCreateProperties {
  /** 可选。右键菜单项要显示的类型。默认为 "normal"。 */
  type?: ItemType | undefined;
  /** 可选。右键菜单项唯一 id，扩展内唯一。 */
  id?: string | undefined;
  /** 可选。菜单项标题文字。type 为 separator 时可省略。 */
  title?: string | undefined;
  /** 可选。仅用于 checkbox/radio 类型，表示初始选中状态。 */
  checked?: boolean | undefined;
  /** 可选。此菜单项适用的上下文类型列表。 */
  contexts?: ContextType[] | undefined;
  /** 可选。是否在父菜单项可见但此项不可见时，继续显示父项。默认 true。 */
  visible?: boolean | undefined;
  /** 可选。父菜单项的 id，将此项设置为子项。 */
  parentId?: number | string | undefined;
  /** 可选。限制此菜单项只出现在 URL 匹配的页面。 */
  documentUrlPatterns?: string[] | undefined;
  /** 可选。限制此菜单项只出现在 URL 匹配的 img/audio/video 上。 */
  targetUrlPatterns?: string[] | undefined;
  /** 可选。是否启用此菜单项。默认 true。 */
  enabled?: boolean | undefined;
}

export interface OnClickData {
  /** 所选菜单项 id。 */
  menuItemId: number | string;
  /** 若触发的菜单项是子项，则为父菜单 id。 */
  parentMenuItemId?: number | string | undefined;
  /** 可选。触发时使用的媒体类型（image/video/audio）。 */
  mediaType?: string | undefined;
  /** 可选。若菜单触发在链接上，为链接 URL。 */
  linkUrl?: string | undefined;
  /** 可选。若菜单触发在图片/音视频上，为其来源 URL。 */
  srcUrl?: string | undefined;
  /** 可选。当前页面 URL（包含 frame 时为 frame URL）。 */
  pageUrl?: string | undefined;
  /** 可选。菜单触发 frame 的 URL。 */
  frameUrl?: string | undefined;
  /** 可选。frame id。 */
  frameId?: number | undefined;
  /** 可选。用户选中的文字（如有）。 */
  selectionText?: string | undefined;
  /** 可选。checkbox/radio 类型菜单的最新选中状态。 */
  checked?: boolean | undefined;
  /** 可选。checkbox/radio 类型菜单的上一次选中状态。 */
  wasChecked?: boolean | undefined;
}

/**
 * 桥接 chrome.contextMenus
 *
 * 监听右键菜单点击事件示例：
 *   $chrome.callMethodByPath('contextMenus.onClicked.addListener',
 *     (info: OnClickData, tab?: Tab) => { console.log(info.menuItemId) }
 *   )
 */
export interface IContextMenus {
  /** 创建右键菜单项。返回新菜单项的 id。 */
  create(createProperties: ContextMenuCreateProperties): Promise<number | string>
  /** 更新右键菜单项。id 字段不可更新，其余字段均为可选。 */
  update(id: number | string, updateProperties: Omit<ContextMenuCreateProperties, 'id'>): Promise<void>
  /** 删除指定右键菜单项。 */
  remove(menuItemId: number | string): Promise<void>
  /** 删除当前扩展创建的所有右键菜单项。 */
  removeAll(): Promise<void>
}


export interface CookieDetails {
  /** 与 cookie 关联的 URL。 */
  url: string;
  /** cookie 名称。 */
  name: string;
  /** 可选。存储此 cookie 的 cookie store id，默认当前上下文。 */
  storeId?: string | undefined;
  /** 可选。分区键（Cookie Partitioning）。 */
  partitionKey?: CookiePartitionKey | undefined;
}

export interface CookiePartitionKey {
  /** 可选。顶级站点的 URL。 */
  topLevelSite?: string | undefined;
}

export interface Cookie {
  /** cookie 名称。 */
  name: string;
  /** cookie 值。 */
  value: string;
  /** cookie 所属域名。 */
  domain: string;
  /** 若 domain 以点开头，表明是宿主 cookie。 */
  hostOnly: boolean;
  /** cookie 路径。 */
  path: string;
  /** 是否仅限于安全连接传输。 */
  secure: boolean;
  /** 是否为 HttpOnly cookie（无法通过 JS 访问）。 */
  httpOnly: boolean;
  /** SameSite 状态。 */
  sameSite: SameSiteStatus;
  /** cookie 是否为会话 cookie（非持久化）。 */
  session: boolean;
  /** 可选。持久化 cookie 的过期时间（Unix 毫秒戳）。 */
  expirationDate?: number | undefined;
  /** 此 cookie 所在的存储区 id。 */
  storeId: string;
  /** 可选。分区键。 */
  partitionKey?: CookiePartitionKey | undefined;
}

export type SameSiteStatus = "unspecified" | "no_restriction" | "lax" | "strict";

export interface GetAllDetails {
  /** 可选。仅返回适用于此 URL 的 cookie。 */
  url?: string | undefined;
  /** 可选。按名称过滤。 */
  name?: string | undefined;
  /** 可选。按域名过滤。 */
  domain?: string | undefined;
  /** 可选。按路径过滤。 */
  path?: string | undefined;
  /** 可选。按 secure 属性过滤。 */
  secure?: boolean | undefined;
  /** 可选。若为 true 则只返回会话 cookie，false 则只返回持久化 cookie。 */
  session?: boolean | undefined;
  /** 可选。按存储区 id 过滤。 */
  storeId?: string | undefined;
  /** 可选。分区键。 */
  partitionKey?: CookiePartitionKey | undefined;
}

export interface SetDetails {
  /** 与 cookie 关联的请求 URI。 */
  url: string;
  /** 可选。cookie 名称，默认空字符串。 */
  name?: string | undefined;
  /** 可选。cookie 值，默认空字符串。 */
  value?: string | undefined;
  /** 可选。cookie 域名。 */
  domain?: string | undefined;
  /** 可选。cookie 路径，默认为 url 中的路径部分。 */
  path?: string | undefined;
  /** 可选。是否为 secure cookie，默认 false。 */
  secure?: boolean | undefined;
  /** 可选。是否为 HttpOnly cookie，默认 false。 */
  httpOnly?: boolean | undefined;
  /** 可选。SameSite 状态。 */
  sameSite?: SameSiteStatus | undefined;
  /** 可选。cookie 过期时间（Unix 秒级时间戳）。 */
  expirationDate?: number | undefined;
  /** 可选。cookie store id。 */
  storeId?: string | undefined;
  /** 可选。分区键。 */
  partitionKey?: CookiePartitionKey | undefined;
}

export interface CookieStore {
  /** Cookie store 的唯一 id。 */
  id: string;
  /** 共享此 cookie store 的所有 tab id 列表。 */
  tabIds: number[];
}

/**
 * 桥接 chrome.cookies
 */
export interface ICookies {
  /** 获取单个 cookie。 */
  get(details: CookieDetails): Promise<Cookie | null>
  /** 获取满足条件的所有 cookie。 */
  getAll(details: GetAllDetails): Promise<Cookie[]>
  /** 设置 cookie。成功时返回新设置的 Cookie，失败时返回 null。 */
  set(details: SetDetails): Promise<Cookie | null>
  /** 删除 cookie。成功时返回被删除 cookie 的详情，失败时返回 null。 */
  remove(details: CookieDetails): Promise<CookieDetails | null>
  /** 获取所有 cookie store。 */
  getAllCookieStores(): Promise<CookieStore[]>
}


export type FilenameConflictAction = "uniquify" | "overwrite" | "prompt";

export type InterruptReason =
  | "FILE_FAILED"
  | "FILE_ACCESS_DENIED"
  | "FILE_NO_SPACE"
  | "FILE_NAME_TOO_LONG"
  | "FILE_TOO_LARGE"
  | "FILE_VIRUS_INFECTED"
  | "FILE_TRANSIENT_ERROR"
  | "FILE_BLOCKED"
  | "FILE_SECURITY_CHECK_FAILED"
  | "FILE_TOO_SHORT"
  | "FILE_HASH_MISMATCH"
  | "FILE_SAME_AS_SOURCE"
  | "NETWORK_FAILED"
  | "NETWORK_TIMEOUT"
  | "NETWORK_DISCONNECTED"
  | "NETWORK_SERVER_DOWN"
  | "NETWORK_INVALID_REQUEST"
  | "SERVER_FAILED"
  | "SERVER_NO_RANGE"
  | "SERVER_BAD_CONTENT"
  | "SERVER_UNAUTHORIZED"
  | "SERVER_CERT_PROBLEM"
  | "SERVER_FORBIDDEN"
  | "SERVER_UNREACHABLE"
  | "SERVER_CONTENT_LENGTH_MISMATCH"
  | "SERVER_CROSS_ORIGIN_REDIRECT"
  | "USER_CANCELED"
  | "USER_SHUTDOWN"
  | "CRASH";

export type DownloadState = "in_progress" | "interrupted" | "complete";

export type DangerType =
  | "file"
  | "url"
  | "content"
  | "uncommon"
  | "host"
  | "unwanted"
  | "safe"
  | "accepted"
  | "allowlistedByPolicy"
  | "asyncScanning"
  | "passwordProtected"
  | "blockedTooLarge"
  | "sensitiveContentWarning"
  | "sensitiveContentBlock"
  | "deepScannedFailed"
  | "deepScannedSafe"
  | "deepScannedOpenedDangerous"
  | "promptForScaning"
  | "accountCompromise";

export interface HeaderNameValuePair {
  /** HTTP 请求头名称。 */
  name: string;
  /** HTTP 请求头值。 */
  value: string;
}

export interface DownloadOptions {
  /** 下载文件的 URL。 */
  url: string;
  /** 可选。保存时使用的文件名（相对路径）。 */
  filename?: string | undefined;
  /** 可选。同名文件的处理策略。 */
  conflictAction?: FilenameConflictAction | undefined;
  /** 可选。为 true 则弹出保存对话框让用户选择路径。 */
  saveAs?: boolean | undefined;
  /** 可选。HTTP 请求方法，默认 GET。 */
  method?: "GET" | "POST" | undefined;
  /** 可选。额外的 HTTP 请求头（不允许 Cookie）。 */
  headers?: HeaderNameValuePair[] | undefined;
  /** 可选。POST 请求体。 */
  body?: string | undefined;
}

export interface DownloadItem {
  id: number;
  url: string;
  finalUrl: string;
  referrer: string;
  filename: string;
  incognito: boolean;
  danger: DangerType;
  mime: string;
  startTime: string;
  endTime?: string | undefined;
  estimatedEndTime?: string | undefined;
  state: DownloadState;
  paused: boolean;
  canResume: boolean;
  error?: InterruptReason | undefined;
  bytesReceived: number;
  totalBytes: number;
  fileSize: number;
  exists: boolean;
  byExtensionId?: string | undefined;
  byExtensionName?: string | undefined;
}

export interface DownloadQuery {
  /** 可选。按 id 列表过滤。 */
  id?: number | undefined;
  /** 可选。按 URL 过滤（支持通配符）。 */
  url?: string | undefined;
  /** 可选。按保存文件名过滤（支持通配符）。 */
  filename?: string | undefined;
  /** 可选。按危险类型过滤。 */
  danger?: DangerType | undefined;
  /** 可选。按 MIME 类型过滤。 */
  mime?: string | undefined;
  /** 可选。按开始时间过滤（ISO 8601 字符串，>=）。 */
  startedAfter?: string | undefined;
  /** 可选。按开始时间过滤（ISO 8601 字符串，<=）。 */
  startedBefore?: string | undefined;
  /** 可选。按结束时间过滤（ISO 8601 字符串，>=）。 */
  endedAfter?: string | undefined;
  /** 可选。按结束时间过滤（ISO 8601 字符串，<=）。 */
  endedBefore?: string | undefined;
  /** 可选。按已接收字节数过滤（>=）。 */
  totalBytesGreater?: number | undefined;
  /** 可选。按已接收字节数过滤（<=）。 */
  totalBytesLess?: number | undefined;
  /** 可选。按文件名正则过滤。 */
  filenameRegex?: string | undefined;
  /** 可选。按 URL 正则过滤。 */
  urlRegex?: string | undefined;
  /** 可选。最多返回条数。 */
  limit?: number | undefined;
  /** 可选。排序字段列表（加 - 前缀表示降序）。 */
  orderBy?: string[] | undefined;
  /** 可选。按下载状态过滤。 */
  state?: DownloadState | undefined;
  /** 可选。是否暂停中。 */
  paused?: boolean | undefined;
  /** 可选。文件是否存在。 */
  exists?: boolean | undefined;
}

export interface GetFileIconOptions {
  /** 可选。图标尺寸，支持 16 或 32，默认 32。 */
  size?: 16 | 32 | undefined;
}

export interface DownloadDelta {
  /** 发生变化的下载任务 id。 */
  id: number;
  url?: StringDelta | undefined;
  filename?: StringDelta | undefined;
  danger?: StringDelta | undefined;
  mime?: StringDelta | undefined;
  startTime?: StringDelta | undefined;
  endTime?: StringDelta | undefined;
  state?: StringDelta | undefined;
  canResume?: BooleanDelta | undefined;
  paused?: BooleanDelta | undefined;
  error?: StringDelta | undefined;
  totalBytes?: DoubleDelta | undefined;
  fileSize?: DoubleDelta | undefined;
  exists?: BooleanDelta | undefined;
}

export interface StringDelta {
  previous?: string | undefined;
  current?: string | undefined;
}

export interface BooleanDelta {
  previous?: boolean | undefined;
  current?: boolean | undefined;
}

export interface DoubleDelta {
  previous?: number | undefined;
  current?: number | undefined;
}

/**
 * 桥接 chrome.downloads
 */
export interface IDownloads {
  /** 发起下载。返回下载任务 id。 */
  download(options: DownloadOptions): Promise<number>
  /** 搜索下载历史。 */
  search(query: DownloadQuery): Promise<DownloadItem[]>
  /** 暂停指定下载任务。 */
  pause(downloadId: number): Promise<void>
  /** 恢复指定下载任务。 */
  resume(downloadId: number): Promise<void>
  /** 取消指定下载任务。 */
  cancel(downloadId: number): Promise<void>
  /** 在文件管理器中显示下载的文件。 */
  show(downloadId: number): Promise<void>
  /** 将已完成的下载任务从历史中移除（不删除文件）。 */
  erase(query: DownloadQuery): Promise<number[]>
  /** 删除下载的文件（保留历史记录）。 */
  removeFile(downloadId: number): Promise<void>
  /** 在系统文件管理器中打开默认下载文件夹。 */
  showDefaultFolder(): Promise<void>
  /** 获取下载文件的图标 URL。文件不存在时返回 undefined。 */
  getFileIcon(downloadId: number, options?: GetFileIconOptions): Promise<string | undefined>
}


export interface AlarmCreateInfo {
  /**
   * 可选。触发 alarm 的时间（毫秒时间戳，类似 Date.now()）。
   * 精度限制：Chrome 会将延迟不足 30 秒的 alarm 延迟至少 30 秒。
   */
  when?: number | undefined;
  /**
   * 可选。从当前时间起延迟多少分钟后首次触发。
   * 精度限制同上。
   */
  delayInMinutes?: number | undefined;
  /**
   * 可选。每隔多少分钟重复触发（设置后变为周期性 alarm）。
   * 精度限制同上。
   */
  periodInMinutes?: number | undefined;
}

export interface Alarm {
  /** alarm 的名称。 */
  name: string;
  /** alarm 下一次预计触发时间（毫秒时间戳）。 */
  scheduledTime: number;
  /** 若为周期性 alarm，表示重复间隔（分钟）。 */
  periodInMinutes?: number | undefined;
}

/**
 * 桥接 chrome.alarms
 */
export interface IAlarms {
  /**
   * 创建定时任务（匿名）。
   */
  create(alarmInfo: AlarmCreateInfo): Promise<void>
  /**
   * 创建定时任务（具名，name 可为 undefined 表示匿名）。
   */
  create(name: string | undefined, alarmInfo: AlarmCreateInfo): Promise<void>
  /** 获取指定 alarm。 */
  get(name?: string): Promise<Alarm | undefined>
  /** 获取所有 alarm。 */
  getAll(): Promise<Alarm[]>
  /** 清除指定 alarm。 */
  clear(name?: string): Promise<boolean>
  /** 清除所有 alarm。 */
  clearAll(): Promise<boolean>
}


export type CloseOptions =
  | {
      /** 要关闭侧边栏的 tab id。tabId 与 windowId 至少需提供其一。 */
      tabId: number;
      /** 可选。要关闭侧边栏的 window id。 */
      windowId?: number | undefined;
    }
  | {
      /** 可选。要关闭侧边栏的 tab id。 */
      tabId?: number | undefined;
      /** 要关闭侧边栏的 window id。tabId 与 windowId 至少需提供其一。 */
      windowId: number;
    };

export interface GetPanelOptions {
  /** 可选。指定 tab id，获取该 tab 专属的侧边栏配置。若未设置则获取全局配置。 */
  tabId?: number | undefined;
}

export interface PanelOptions {
  /** 可选。侧边栏 HTML 页面的相对路径。 */
  path?: string | undefined;
  /** 可选。是否允许侧边栏打开。 */
  enabled?: boolean | undefined;
  /** 可选。指定 tab id，配置该 tab 专属的侧边栏。若未设置则配置全局。 */
  tabId?: number | undefined;
}

export interface PanelBehavior {
  /** 可选。点击工具栏扩展图标时是否自动打开侧边栏。 */
  openPanelOnActionClick?: boolean | undefined;
}

/**
 * 桥接 chrome.sidePanel
 */
export interface ISidePanel {
  /**
   * 获取指定 tab 或全局的侧边栏配置。
   */
  getOptions(options: GetPanelOptions): Promise<PanelOptions>
  /**
   * 设置侧边栏配置（路径/启用状态）。
   */
  setOptions(options: PanelOptions): Promise<void>
  /**
   * 关闭侧边栏。
   */
  close(options: CloseOptions): Promise<void>
  /**
   * 获取点击 action 图标时是否自动打开侧边栏的行为配置。
   */
  getPanelBehavior(): Promise<PanelBehavior>
  /**
   * 设置点击 action 图标时是否自动打开侧边栏的行为。
   */
  setPanelBehavior(behavior: PanelBehavior): Promise<void>
}

/**
 * 开启侧边栏（需要用户手势，请在事件回调中调用）示例：
 *   $chrome.callMethodByPath('sidePanel.open', { windowId: tabInfo.windowId })
 */
export interface SidePanelOpenOptions {
  /** 要在哪个窗口打开侧边栏。 */
  windowId: number;
  /** 可选。要在哪个 tab 打开侧边栏（如不传则展示全局侧边栏）。 */
  tabId?: number | undefined;
}


export type ColorEnum =
  | "grey"
  | "blue"
  | "red"
  | "yellow"
  | "green"
  | "pink"
  | "purple"
  | "cyan"
  | "orange";

export interface TabGroup {
  /** tab 分组是否折叠。 */
  collapsed: boolean;
  /** tab 分组颜色。 */
  color: ColorEnum;
  /** 可选。tab 分组标题。 */
  title?: string | undefined;
  /** tab 分组 id，在浏览器会话内唯一。 */
  id: number;
  /** 分组所在窗口 id。 */
  windowId: number;
}

export interface TabGroupQueryInfo {
  /** 可选。按折叠状态过滤。 */
  collapsed?: boolean | undefined;
  /** 可选。按颜色过滤。 */
  color?: ColorEnum | undefined;
  /** 可选。按标题过滤（支持通配符）。 */
  title?: string | undefined;
  /** 可选。按 windowId 过滤。-2 表示任意窗口。 */
  windowId?: number | undefined;
}

export interface TabGroupUpdateProperties {
  /** 可选。是否折叠分组。 */
  collapsed?: boolean | undefined;
  /** 可选。分组颜色。 */
  color?: ColorEnum | undefined;
  /** 可选。分组标题，空字符串表示清除标题。 */
  title?: string | undefined;
}

export interface MoveProperties {
  /** 目标 windowId。-2 表示当前窗口。 */
  windowId?: number | undefined;
  /** 分组在目标窗口中的新位置索引。-1 表示放到末尾。 */
  index: number;
}

/**
 * 桥接 chrome.tabGroups
 */
export interface ITabGroups {
  /** 获取指定 tab 分组。 */
  get(groupId: number): Promise<TabGroup>
  /** 查询满足条件的 tab 分组。 */
  query(queryInfo: TabGroupQueryInfo): Promise<TabGroup[]>
  /** 更新 tab 分组的颜色、标题或折叠状态。 */
  update(groupId: number, updateProperties: TabGroupUpdateProperties): Promise<TabGroup | undefined>
  /** 移动 tab 分组到窗口中的指定位置。 */
  move(groupId: number, moveProperties: MoveProperties): Promise<TabGroup | undefined>
}


/**
 * chrome.scripting 的脚本执行环境。
 * 注意：与 chrome.userScripts.ExecutionWorld 不同，scripting 支持三种环境（含 ISOLATED）。
 */
export type ScriptingExecutionWorld = "ISOLATED" | "MAIN" | "USER_SCRIPT";

export type StyleOrigin = "AUTHOR" | "USER";

export interface InjectionTarget {
  /** 要注入的 tab id。 */
  tabId: number;
  /** 可选。要注入的 frame id 列表。若不设置则注入所有 frame。 */
  frameIds?: number[] | undefined;
  /** 可选。要注入的 document id 列表。 */
  documentIds?: string[] | undefined;
  /** 可选。是否注入所有 frame，默认 false（仅注入顶层 frame）。 */
  allFrames?: boolean | undefined;
}

export interface CSSInjection {
  /** 注入目标。 */
  target: InjectionTarget;
  /** 可选。要注入的 CSS 字符串。 */
  css?: string | undefined;
  /** 可选。要注入的 CSS 文件路径列表（相对路径）。 */
  files?: string[] | undefined;
  /** 可选。注入来源，影响优先级。默认 "AUTHOR"。 */
  origin?: StyleOrigin | undefined;
}

export interface ScriptInjection<Args extends any[] = any[], Result = any> {
  /** 注入目标。 */
  target: InjectionTarget;
  /** 可选。要注入的 JS 文件路径列表（相对路径）。 */
  files?: string[] | undefined;
  /** 可选。要执行的函数。与 files 互斥。 */
  func?: (...args: Args) => Result;
  /** 可选。传给 func 的参数列表（必须可序列化）。 */
  args?: Args;
  /** 可选。脚本执行环境，默认 "ISOLATED"。 */
  world?: ScriptingExecutionWorld | undefined;
  /** 可选。是否在文档加载完成前注入（需要 document_start 时机）。 */
  injectImmediately?: boolean | undefined;
}

export interface InjectionResult<Result = any> {
  /** 注入结果（函数返回值）。 */
  result?: Result;
  /** 注入所在的 frame id。 */
  frameId: number;
  /** 注入所在的 document id。 */
  documentId: string;
  /** 若注入出错，此处包含错误信息。 */
  error?: any;
}

export interface RegisteredContentScript {
  /** 内容脚本唯一 id，不能以 _ 开头。 */
  id: string;
  /** 可选。是否注入所有 frame，默认 false。 */
  allFrames?: boolean | undefined;
  /** 可选。排除匹配的 URL 规则列表。 */
  excludeMatches?: string[] | undefined;
  /** 可选。要注入的 CSS 文件列表。 */
  css?: string[] | undefined;
  /** 可选。要注入的 JS 文件列表。 */
  js?: string[] | undefined;
  /** 可选。匹配的 URL 规则列表。register 时必须。 */
  matches?: string[] | undefined;
  /** 可选。注入时机。 */
  runAt?: "document_start" | "document_end" | "document_idle" | undefined;
  /** 可选。是否持久化（在扩展重启后保留），默认 true。 */
  persistAcrossSessions?: boolean | undefined;
  /** 可选。脚本执行环境，默认 "ISOLATED"。 */
  world?: ScriptingExecutionWorld | undefined;
}

export interface ContentScriptFilter {
  /** 可选。按 id 过滤。 */
  ids?: string[] | undefined;
  /** 可选。按样式来源过滤。 */
  styleOrigin?: StyleOrigin | undefined;
}

/**
 * 桥接 chrome.scripting（MV3，替代旧版 tabs.executeScript / tabs.insertCSS）
 */
export interface IScripting {
  /** 向页面注入 JavaScript（支持函数或文件）。 */
  executeScript<Args extends any[] = any[], Result = any>(
    injection: ScriptInjection<Args, Result>
  ): Promise<InjectionResult<Result>[]>
  /** 向页面注入 CSS。 */
  insertCSS(injection: CSSInjection): Promise<void>
  /** 移除已注入的 CSS。 */
  removeCSS(injection: CSSInjection): Promise<void>
  /** 注册持久化内容脚本。 */
  registerContentScripts(scripts: RegisteredContentScript[]): Promise<void>
  /** 获取已注册的持久化内容脚本。 */
  getRegisteredContentScripts(filter?: ContentScriptFilter): Promise<RegisteredContentScript[]>
  /** 更新已注册的持久化内容脚本。 */
  updateContentScripts(scripts: RegisteredContentScript[]): Promise<void>
  /** 注销持久化内容脚本。 */
  unregisterContentScripts(filter?: ContentScriptFilter): Promise<void>
}


/**
 * Execution environment for a user script.
 */
export type ExecutionWorld = "MAIN" | "USER_SCRIPT";

/**
 * Properties for configuring the user script world.
 */
export interface WorldProperties {
    /** Specifies the world csp. The default is the \`ISOLATED\` world csp. */
    csp?: string;
    /** Specifies whether messaging APIs are exposed. The default is false.*/
    messaging?: boolean;
}

/**
 * Properties for filtering user scripts.
 */
export interface UserScriptFilter {
    ids?: string[];
}

/**
 * Properties for a registered user script.
 */
export interface RegisteredUserScript {
    /** If true, it will inject into all frames, even if the frame is not the top-most frame in the tab. Each frame is checked independently for URL requirements; it will not inject into child frames if the URL requirements are not met. Defaults to false, meaning that only the top frame is matched. */
    allFrames?: boolean;
    /** Specifies wildcard patterns for pages this user script will NOT be injected into. */
    excludeGlobs?: string[];
    /**Excludes pages that this user script would otherwise be injected into. See Match Patterns for more details on the syntax of these strings. */
    excludeMatches?: string[];
    /** The ID of the user script specified in the API call. This property must not start with a '_' as it's reserved as a prefix for generated script IDs. */
    id: string;
    /** Specifies wildcard patterns for pages this user script will be injected into. */
    includeGlobs?: string[];
    /** The list of ScriptSource objects defining sources of scripts to be injected into matching pages. */
    js: ScriptSource[];
    /** Specifies which pages this user script will be injected into. See Match Patterns for more details on the syntax of these strings. This property must be specified for \${ref:register}. */
    matches?: string[];
    /** Specifies when JavaScript files are injected into the web page. The preferred and default value is document_idle */
    runAt?: RunAt;
    /** The JavaScript execution environment to run the script in. The default is \`USER_SCRIPT\` */
    world?: ExecutionWorld;
}

/**
 * Properties for a script source.
 */
export interface ScriptSource {
    /** A string containing the JavaScript code to inject. Exactly one of file or code must be specified. */
    code?: string;
    /** The path of the JavaScript file to inject relative to the extension's root directory. Exactly one of file or code must be specified. */
    file?: string;
}

/**
 * Enum for the run-at property.
 */
export type RunAt = "document_start" | "document_end" | "document_idle";

/**
 * 桥接 chrome.userScripts
 */
export interface IUserScript {
  configureWorld(properties: WorldProperties): Promise<void>
  getScripts(filter?: UserScriptFilter): Promise<RegisteredUserScript[]>
  register(scripts: RegisteredUserScript[]): Promise<void>
  update(scripts: RegisteredUserScript[]): Promise<void>
  unregister(filter?: UserScriptFilter): Promise<void>
}


export type TemplateType = "basic" | "image" | "list" | "progress";

export interface ButtonOptions {
    title: string;
    iconUrl?: string | undefined;
}

export interface ItemOptions {
    /** Title of one item of a list notification. */
    title: string;
    /** Additional details about this item. */
    message: string;
}

export type NotificationOptions<T extends boolean = false> =
    & {
        /**
         * Optional.
         * Alternate notification content with a lower-weight font.
         * @since Chrome 31
         */
        contextMessage?: string | undefined;
        /** Optional. Priority ranges from -2 to 2. -2 is lowest priority. 2 is highest. Zero is default. */
        priority?: number | undefined;
        /** Optional. A timestamp associated with the notification, in milliseconds past the epoch (e.g. Date.now() + n). */
        eventTime?: number | undefined;
        /** Optional. Text and icons for up to two notification action buttons. */
        buttons?: ButtonOptions[] | undefined;
        /** Optional. Items for multi-item notifications. */
        items?: ItemOptions[] | undefined;
        /**
         * Optional.
         * Current progress ranges from 0 to 100.
         * @since Chrome 30
         */
        progress?: number | undefined;
        /**
         * Optional.
         * Whether to show UI indicating that the app will visibly respond to clicks on the body of a notification.
         * @since Chrome 32
         */
        isClickable?: boolean | undefined;
        /**
         * Optional.
         * A URL to the app icon mask. URLs have the same restrictions as iconUrl. The app icon mask should be in alpha channel, as only the alpha channel of the image will be considered.
         * @since Chrome 38
         */
        appIconMaskUrl?: string | undefined;
        /** Optional. A URL to the image thumbnail for image-type notifications. URLs have the same restrictions as iconUrl. */
        imageUrl?: string | undefined;
        /**
         * Indicates that the notification should remain visible on screen until the user activates or dismisses the notification.
         * This defaults to false.
         * @since Chrome 50
         */
        requireInteraction?: boolean | undefined;
        /**
         * Optional.
         * Indicates that no sounds or vibrations should be made when the notification is being shown. This defaults to false.
         * @since Chrome 70
         */
        silent?: boolean | undefined;
    }
    & (T extends true ? {
            /**
             * A URL to the sender's avatar, app icon, or a thumbnail for image notifications.
             * URLs can be a data URL, a blob URL, or a URL relative to a resource within this extension's .crx file. Required for notifications.create method.
             */
            iconUrl: string;
            /** Main notification content. Required for notifications.create method. */
            message: string;
            /** Which type of notification to display. Required for notifications.create method. */
            type: TemplateType;
            /** Title of the notification (e.g. sender name for email). Required for notifications.create method. */
            title: string;
        }
        : {
            /**
             * Optional.
             * A URL to the sender's avatar, app icon, or a thumbnail for image notifications.
             * URLs can be a data URL, a blob URL, or a URL relative to a resource within this extension's .crx file. Required for notifications.create method.
             */
            iconUrl?: string | undefined;
            /** Optional. Main notification content. Required for notifications.create method. */
            message?: string | undefined;
            /** Optional. Which type of notification to display. Required for notifications.create method. */
            type?: TemplateType | undefined;
            /** Optional. Title of the notification (e.g. sender name for email). Required for notifications.create method. */
            title?: string | undefined;
        });

/**
 * 桥接 chrome.notifications
 */
export interface INotifications {
  create(
    notificationId: string,
    options: NotificationOptions<true>,
    callback?: (notificationId: string) => void
  ): Promise<void>

  update(
    notificationId: string,
    options: NotificationOptions,
    callback?: (wasUpdated: boolean) => void
  ): Promise<void>

  clear(
    notificationId: string,
    callback?: (wasCleared: boolean) => void
  ): Promise<void>
}


/**
 * Specifies what type of browser window to create.
 * 'panel' is deprecated and is available only to existing whitelisted extensions on Chrome OS.
 * @since Chrome 44
 */
export type createTypeEnum = "normal" | "popup" | "panel";

/**
 * The state of this browser window.
 * In some circumstances a window may not be assigned a state property; for example, when querying closed windows from the sessions API.
 * @since Chrome 44
 */
export type windowStateEnum = "normal" | "minimized" | "maximized" | "fullscreen" | "locked-fullscreen";

/**
 * The type of browser window this is.
 * In some circumstances a window may not be assigned a type property; for example, when querying closed windows from the sessions API.
 * @since Chrome 44
 */
export type windowTypeEnum = "normal" | "popup" | "panel" | "app" | "devtools";

export interface CreateData {
    /**
     * Optional. The id of the tab for which you want to adopt to the new window.
     * @since Chrome 10
     */
    tabId?: number | undefined;
    /**
     * Optional.
     * A URL or array of URLs to open as tabs in the window. Fully-qualified URLs must include a scheme (i.e. 'http://www.google.com', not 'www.google.com'). Relative URLs will be relative to the current page within the extension. Defaults to the New Tab Page.
     */
    url?: string | string[] | undefined;
    /**
     * Optional.
     * The number of pixels to position the new window from the top edge of the screen. If not specified, the new window is offset naturally from the last focused window. This value is ignored for panels.
     */
    top?: number | undefined;
    /**
     * Optional.
     * The height in pixels of the new window, including the frame. If not specified defaults to a natural height.
     */
    height?: number | undefined;
    /**
     * Optional.
     * The width in pixels of the new window, including the frame. If not specified defaults to a natural width.
     */
    width?: number | undefined;
    /**
     * Optional. If true, opens an active window. If false, opens an inactive window.
     * @since Chrome 12
     */
    focused?: boolean | undefined;
    /** Optional. Whether the new window should be an incognito window. */
    incognito?: boolean | undefined;
    /** Optional. Specifies what type of browser window to create. */
    type?: createTypeEnum | undefined;
    /**
     * Optional.
     * The number of pixels to position the new window from the left edge of the screen. If not specified, the new window is offset naturally from the last focused window. This value is ignored for panels.
     */
    left?: number | undefined;
    /**
     * Optional. The initial state of the window. The 'minimized', 'maximized' and 'fullscreen' states cannot be combined with 'left', 'top', 'width' or 'height'.
     * @since Chrome 44
     */
    state?: windowStateEnum | undefined;
    /**
     * If true, the newly-created window's 'window.opener' is set to the caller and is in the same [unit of related browsing contexts](https://www.w3.org/TR/html51/browsers.html#unit-of-related-browsing-contexts) as the caller.
     * @since Chrome 64
     */
    setSelfAsOpener?: boolean | undefined;
}

export interface Window {
    /** Optional. Array of tabs.Tab objects representing the current tabs in the window. */
    tabs?: Tab[] | undefined;
    /** Optional. The offset of the window from the top edge of the screen in pixels. Under some circumstances a Window may not be assigned top property, for example when querying closed windows from the sessions API. */
    top?: number | undefined;
    /** Optional. The height of the window, including the frame, in pixels. Under some circumstances a Window may not be assigned height property, for example when querying closed windows from the sessions API. */
    height?: number | undefined;
    /** Optional. The width of the window, including the frame, in pixels. Under some circumstances a Window may not be assigned width property, for example when querying closed windows from the sessions API. */
    width?: number | undefined;
    /**
     * The state of this browser window.
     * @since Chrome 17
     */
    state?: windowStateEnum | undefined;
    /** Whether the window is currently the focused window. */
    focused: boolean;
    /**
     * Whether the window is set to be always on top.
     * @since Chrome 19
     */
    alwaysOnTop: boolean;
    /** Whether the window is incognito. */
    incognito: boolean;
    /**
     * The type of browser window this is.
     */
    type?: windowTypeEnum | undefined;
    /** Optional. The ID of the window. Window IDs are unique within a browser session. Under some circumstances a Window may not be assigned an ID, for example when querying windows using the sessions API, in which case a session ID may be present. */
    id?: number | undefined;
    /** Optional. The offset of the window from the left edge of the screen in pixels. Under some circumstances a Window may not be assigned left property, for example when querying closed windows from the sessions API. */
    left?: number | undefined;
    /**
     * Optional. The session ID used to uniquely identify a Window obtained from the sessions API.
     * @since Chrome 31
     */
    sessionId?: string | undefined;
}

export interface WindowQueryOptions {
    /**
     * Optional.
     * If true, the windows.Window object will have a tabs property that contains a list of the tabs.Tab objects.
     * The Tab objects only contain the url, pendingUrl, title and favIconUrl properties if the extension's manifest file includes the "tabs" permission.
     */
    populate?: boolean | undefined;
    /**
     * If set, the Window returned is filtered based on its type. If unset, the default filter is set to ['normal', 'popup'].
     */
    windowTypes?: windowTypeEnum[] | undefined;
}

export interface UpdateInfo {
    /** 可选。要将窗口移动到的偏移位置（距屏幕左边缘像素数）。 */
    left?: number | undefined;
    /** 可选。要将窗口移动到的偏移位置（距屏幕顶边缘像素数）。 */
    top?: number | undefined;
    /** 可选。要调整到的窗口宽度（像素）。 */
    width?: number | undefined;
    /** 可选。要调整到的窗口高度（像素）。 */
    height?: number | undefined;
    /** 可选。若为 true 则将窗口带到最前并聚焦；若为 false 则使其失焦。 */
    focused?: boolean | undefined;
    /** 可选。若为 true 则将窗口从当前应用绘制中移除。 */
    drawAttention?: boolean | undefined;
    /** 可选。窗口的目标状态（最小化/最大化/全屏/普通等）。 */
    state?: windowStateEnum | undefined;
}

/**
 * 桥接 chrome.windows
 */
export interface IWindows {
  create(createData?: CreateData): Promise<Window>
  get(windowId: number, queryOptions?: WindowQueryOptions): Promise<Window>
  getCurrent(queryOptions?: WindowQueryOptions): Promise<Window>
  getAll(queryOptions?: WindowQueryOptions): Promise<Window[]>
  update(windowId: number, updateInfo: UpdateInfo): Promise<Window>
  remove(windowId: number): Promise<void>
  getLastFocused(queryOptions?: WindowQueryOptions): Promise<Window>
}


export interface MutedInfo {
  /** Whether the tab is prevented from playing sound (but hasn't necessarily recently produced sound). Equivalent to whether the muted audio indicator is showing. */
  muted: boolean;
  /** Optional. The reason the tab was muted or unmuted. */
  reason?: "user" | "capture" | "extension" | undefined;
  /** Optional. The ID of the extension that muted the tab. */
  extensionId?: string | undefined;
}

export interface Tab {
  /**
   * Optional.
   * Either loading or complete.
   */
  status?: string | undefined;
  /** The zero-based index of the tab within its window. */
  index: number;
  /**
   * Optional.
   * The ID of the tab that opened this tab, if any. This property is only present if the opener tab still exists.
   * @since Chrome 18
   */
  openerTabId?: number | undefined;
  /**
   * Optional.
   * The title of the tab. This property is only present if the extension's manifest includes the "tabs" permission.
   */
  title?: string | undefined;
  /**
   * Optional.
   * The URL the tab is displaying. This property is only present if the extension's manifest includes the "tabs" permission.
   */
  url?: string | undefined;
  /**
   * The URL the tab is navigating to, before it has committed.
   * This property is only present if the extension's manifest includes the "tabs" permission and there is a pending navigation.
   * @since Chrome 79
   */
  pendingUrl?: string | undefined;
  /**
   * Whether the tab is pinned.
   * @since Chrome 9
   */
  pinned: boolean;
  /**
   * Whether the tab is highlighted.
   * @since Chrome 16
   */
  highlighted: boolean;
  /** The ID of the window the tab is contained within. */
  windowId: number;
  /**
   * Whether the tab is active in its window. (Does not necessarily mean the window is focused.)
   * @since Chrome 16
   */
  active: boolean;
  /**
   * Optional.
   * The URL of the tab's favicon. This property is only present if the extension's manifest includes the "tabs" permission. It may also be an empty string if the tab is loading.
   */
  favIconUrl?: string | undefined;
  /**
   * Optional.
   * The ID of the tab. Tab IDs are unique within a browser session. Under some circumstances a Tab may not be assigned an ID, for example when querying foreign tabs using the sessions API, in which case a session ID may be present. Tab ID can also be set to chrome.tabs.TAB_ID_NONE for apps and devtools windows.
   */
  id?: number | undefined;
  /** Whether the tab is in an incognito window. */
  incognito: boolean;
  /**
   * Whether the tab is selected.
   * @deprecated since Chrome 33. Please use tabs.Tab.highlighted.
   */
  selected: boolean;
  /**
   * Optional.
   * Whether the tab has produced sound over the past couple of seconds (but it might not be heard if also muted). Equivalent to whether the speaker audio indicator is showing.
   * @since Chrome 45
   */
  audible?: boolean | undefined;
  /**
   * Whether the tab is discarded. A discarded tab is one whose content has been unloaded from memory, but is still visible in the tab strip. Its content gets reloaded the next time it's activated.
   * @since Chrome 54
   */
  discarded: boolean;
  /**
   * Whether the tab can be discarded automatically by the browser when resources are low.
   * @since Chrome 54
   */
  autoDiscardable: boolean;
  /**
   * Optional.
   * Current tab muted state and the reason for the last state change.
   * @since Chrome 46
   */
  mutedInfo?: MutedInfo | undefined;
  /**
   * Optional. The width of the tab in pixels.
   * @since Chrome 31
   */
  width?: number | undefined;
  /**
   * Optional. The height of the tab in pixels.
   * @since Chrome 31
   */
  height?: number | undefined;
  /**
   * Optional. The session ID used to uniquely identify a Tab obtained from the sessions API.
   * @since Chrome 31
   */
  sessionId?: string | undefined;
  /**
   * The ID of the group that the tab belongs to.
   * @since Chrome 88
   */
  groupId: number;
  /**
   * The last time the tab was accessed as the number of milliseconds since epoch.
   * @since Chrome 121
   */
  lastAccessed?: number | undefined;
}

export interface TabQueryInfo {
  /**
   * Optional. Whether the tabs have completed loading.
   * One of: "loading", or "complete"
   */
  status?: "loading" | "complete" | undefined;
  /**
   * Optional. Whether the tabs are in the last focused window.
   * @since Chrome 19
   */
  lastFocusedWindow?: boolean | undefined;
  /** Optional. The ID of the parent window, or windows.WINDOW_ID_CURRENT for the current window. */
  windowId?: number | undefined;
  /**
   * Optional. The type of window the tabs are in.
   * One of: "normal", "popup", "panel", "app", or "devtools"
   */
  windowType?: "normal" | "popup" | "panel" | "app" | "devtools" | undefined;
  /** Optional. Whether the tabs are active in their windows. */
  active?: boolean | undefined;
  /**
   * Optional. The position of the tabs within their windows.
   * @since Chrome 18
   */
  index?: number | undefined;
  /** Optional. Match page titles against a pattern. */
  title?: string | undefined;
  /** Optional. Match tabs against one or more URL patterns. Note that fragment identifiers are not matched. */
  url?: string | string[] | undefined;
  /**
   * Optional. Whether the tabs are in the current window.
   * @since Chrome 19
   */
  currentWindow?: boolean | undefined;
  /** Optional. Whether the tabs are highlighted. */
  highlighted?: boolean | undefined;
  /**
   * Optional.
   * Whether the tabs are discarded. A discarded tab is one whose content has been unloaded from memory, but is still visible in the tab strip. Its content gets reloaded the next time it's activated.
   * @since Chrome 54
   */
  discarded?: boolean | undefined;
  /**
   * Optional.
   * Whether the tabs can be discarded automatically by the browser when resources are low.
   * @since Chrome 54
   */
  autoDiscardable?: boolean | undefined;
  /** Optional. Whether the tabs are pinned. */
  pinned?: boolean | undefined;
  /**
   * Optional. Whether the tabs are audible.
   * @since Chrome 45
   */
  audible?: boolean | undefined;
  /**
   * Optional. Whether the tabs are muted.
   * @since Chrome 45
   */
  muted?: boolean | undefined;
  /**
   * Optional. The ID of the group that the tabs are in, or chrome.tabGroups.TAB_GROUP_ID_NONE for ungrouped tabs.
   * @since Chrome 88
   */
  groupId?: number | undefined;
}

export interface TabCreateProperties {
  /** Optional. The position the tab should take in the window. The provided value will be clamped to between zero and the number of tabs in the window. */
  index?: number | undefined;
  /**
   * Optional.
   * The ID of the tab that opened this tab. If specified, the opener tab must be in the same window as the newly created tab.
   * @since Chrome 18
   */
  openerTabId?: number | undefined;
  /**
   * Optional.
   * The URL to navigate the tab to initially. Fully-qualified URLs must include a scheme (i.e. 'http://www.google.com', not 'www.google.com'). Relative URLs will be relative to the current page within the extension. Defaults to the New Tab Page.
   */
  url?: string | undefined;
  /**
   * Optional. Whether the tab should be pinned. Defaults to false
   * @since Chrome 9
   */
  pinned?: boolean | undefined;
  /** Optional. The window to create the new tab in. Defaults to the current window. */
  windowId?: number | undefined;
  /**
   * Optional.
   * Whether the tab should become the active tab in the window. Does not affect whether the window is focused (see windows.update). Defaults to true.
   * @since Chrome 16
   */
  active?: boolean | undefined;
  /**
   * Optional. Whether the tab should become the selected tab in the window. Defaults to true
   * @deprecated since Chrome 33. Please use active.
   */
  selected?: boolean | undefined;
}

export interface TabUpdateProperties {
  /**
   * Optional. Whether the tab should be pinned.
   * @since Chrome 9
   */
  pinned?: boolean | undefined;
  /**
   * Optional. The ID of the tab that opened this tab. If specified, the opener tab must be in the same window as this tab.
   * @since Chrome 18
   */
  openerTabId?: number | undefined;
  /** Optional. A URL to navigate the tab to. */
  url?: string | undefined;
  /**
   * Optional. Adds or removes the tab from the current selection.
   * @since Chrome 16
   */
  highlighted?: boolean | undefined;
  /**
   * Optional. Whether the tab should be active. Does not affect whether the window is focused (see windows.update).
   * @since Chrome 16
   */
  active?: boolean | undefined;
  /**
   * Optional. Whether the tab should be selected.
   * @deprecated since Chrome 33. Please use highlighted.
   */
  selected?: boolean | undefined;
  /**
   * Optional. Whether the tab should be muted.
   * @since Chrome 45
   */
  muted?: boolean | undefined;
  /**
   * Optional. Whether the tab should be discarded automatically by the browser when resources are low.
   * @since Chrome 54
   */
  autoDiscardable?: boolean | undefined;
}

export interface ReloadProperties {
  /** Optional. Whether using any local cache. Default is false. */
  bypassCache?: boolean | undefined;
}

export interface MessageSendOptions {
  /** Optional. Send a message to a specific frame identified by frameId instead of all frames in the tab. */
  frameId?: number | undefined;
  /**
   * Optional. Send a message to a specific document identified by documentId instead of all frames in the tab.
   * @since Chrome 106
   */
  documentId?: string;
}

/**
 * 桥接 chrome.tabs
 */
export interface ITabs {
  create(
    createProperties: TabCreateProperties
  ): Promise<Tab>
  query(queryInfo: TabQueryInfo): Promise<Tab[]>
  update(updateProperties: TabUpdateProperties): Promise<Tab>
  update(tabId: number, updateProperties: TabUpdateProperties): Promise<Tab>
  reload(tabId: number, reloadProperties?: ReloadProperties): Promise<void>
  reload(reloadProperties: ReloadProperties): Promise<void>
  reload(): Promise<void>
  get(tabId: number): Promise<Tab>
  getCurrent(): Promise<Tab | undefined>
  sendMessage(tabId: number, message: any, responseCallback: (response: any) => void): Promise<void>
  sendMessage(tabId: number, message: any, options: MessageSendOptions, responseCallback: (response: any) => void): Promise<void>
  sendMessage(tabId: number, message: any): Promise<any>
  sendMessage(tabId: number, message: any, options: MessageSendOptions): Promise<any>
}

/**
 * 桥接 chrome.runtime
 */
export interface IRuntime {
  getId(): Promise<string>
  getURL(path: string): Promise<string>
  /**
   * 获取扩展的 manifest.json 内容。
   * 返回类型为 Record<string, any> 以兼容各版本 manifest，
   * 常用字段包括 name/version/manifest_version/permissions 等。
   */
  getManifest(): Promise<Record<string, any>>

  sendMessage(message: any, responseCallback: (response: any) => void): Promise<void>
  sendMessage(message: any, options: MessageSendOptions, responseCallback: (response: any) => void): Promise<void>
  sendMessage(message: any): Promise<any>
  sendMessage(message: any, options: MessageSendOptions): Promise<any>

  sendMessage(extensionId: string | undefined | null, message: any, responseCallback: (response: any) => void): Promise<void>
  sendMessage(extensionId: string | undefined | null, message: any, options: MessageSendOptions, responseCallback: (response: any) => void): Promise<void>
  sendMessage(extensionId: string | undefined | null, message: any): Promise<any>
  sendMessage(extensionId: string | undefined | null, message: any, options: MessageSendOptions): Promise<any>

  onMessage: {
    addListener(callback: (message: any, sender: any, sendResponse: (response?: any) => void) => void): void
  }
}

/**
 * 桥接 chrome.storage
 */
export interface IStorage {
  local: IStorageArea
  sync: IStorageArea
  session: IStorageArea
}

/**
 * 桥接 chrome.storage.xxx
 */
export interface IStorageArea {
  get(
    keys?: string | string[] | { [key: string]: any } | null
  ): Promise<{ [key: string]: any }>
  set(items: { [key: string]: any }): Promise<void>
  remove(keys: string | string[]): Promise<void>
  clear(): Promise<void>
  /**
   * 获取当前存储区已用空间大小（字节）。
   * 警告：该方法目前尚未实现桶接，如需使用请通过
   * callMethodByPath('storage.local.getBytesInUse', keys) 调用。
   */
  getBytesInUse(keys?: string | string[] | null): Promise<number>
}

/**
 * 暴露到低代码页面中的 $ga 上下文对象，封装了扩展开发的一些常用工具方法
 */
export interface IBridge {
  /**
   * 编辑当前页面
   */
  editCurrentPage(): Promise<Tab>
  /**
   * 低代码页面管理
   */
  lowCodePageManage(): Promise<Tab>
  /**
   * 用户脚本管理
   */
  userScriptManage(): Promise<Tab>
  /**
   * 低代码区块模板市场
   */
  dynamicSchemaBlockTemplateMarket(): Promise<Tab>
  /**
   * 低代码页面模板市场
   */
  lowCodePageTemplateMarket(): Promise<Tab>
  /**
   * 用户脚本市场
   */
  userScriptMarket(): Promise<Tab>
  /**
   * 设置上帝小助手
   */
  settingAssistant(): Promise<Tab>
  /**
   * 关于
   */
  about(): Promise<Tab>
  /**
   * 隐私声明
   */
  privacy(): Promise<Tab>
}

declare global {
  /**
   * 暴露到低代码页面中的 $ga 上下文对象，封装了扩展开发的一些常用工具方法
   */
  declare var $ga: IBridge
  /**
   * 桥接浏览器扩展开发时的 chrome 对象的常用方法。目前只桥接了部分，还在完善中
   * 如果发现有不支持的方法，可用 $chrome.callMethodByPath 替代
   * 如果发现有不支持的属性，可用 $chrome.getPropertyByPath 替代
   */
  declare var $chrome: IChrome
}
`,fa=`
export interface IGaUtils {
/**
 * 延迟指定毫秒后执行
 * @param time 要延迟的毫秒数
 */
sleep(time: number): Promise<unknown>
/**
 * 获取 url 参数
 * @param name 参数名称
 */
getQueryString(name: string): string | null
/**
 * 导出 json 文件
 * @param jsonString 要导出的 json 字符串
 * @param filename 导出的文件名
 */
exportJsonToFile(jsonString: string, filename: string): void
/**
 * 从本地 json 文件导入数据
 * @returns 从本地 json 文件导入的 json 对象
 */
importJsonFromFile<T>(): Promise<{
    result: T | null;
    canceled: boolean;
}>
/**
 * 从剪贴板导入 json 数据
 * @returns 从剪贴板导入的 json 对象
 */
importJsonFromClipboard<T>(): Promise<T | null>
/**
 * 复制文字到剪贴板
 * @param text 要复制的内容
 */
copyTextToClipboard(text: string): Promise<void>
/**
 * 从剪贴板读取文本内容
 * @returns 从剪贴板读取到的文本内容
 */
readTextFromClipboard(): Promise<string>
/**
 * 复制图片到剪贴板
 * @param imageUrl 要复制的图片 url
 */
copyImageToClipboard(imageUrl: string): Promise<void>
/**
 * 获取指定的循环类组件的条目数据和索引
 * @param 条目 Field 或条目里的子 Field，大部分情况传递 $self 即可
 * @param componentType 默认为 IteratorLayout 循环布局。可选值为 ArrayTable、Table、IteratorLayout、ArrayTabs、ArrayCards、ArrayAccordion 之一
 */
getArrayFieldRowAndIndex(field: GeneralField, componentType?: 'IteratorLayout' | 'ArrayTable'|'Table' | 'ArrayTabs' | 'ArrayCards' | 'ArrayAccordion'): {
    row: any;
    index: number;
}
/**
 * 获取指定的循环类组件的条目数据
 * @param 条目 Field 或条目里的子 Field，大部分情况传递 $self 即可
 * @param componentType 默认为 IteratorLayout 循环布局。可选值为 ArrayTable、Table、IteratorLayout、ArrayTabs、ArrayCards、ArrayAccordion 之一
 */
getArrayFieldRow(field: GeneralField, componentType?: 'IteratorLayout' | 'ArrayTable'|'Table' | 'ArrayTabs' | 'ArrayCards' | 'ArrayAccordion'): any
/**
 * 获取书签的图标地址
 * @param url 书签地址
 * @param defaultIcon 用户指定的默认书签图标地址，如果指定了该值就会以该值为准，否则扩展内部会自动抓取图标地址
 */
getBookmarkIconUrl(url: string, defaultIcon?: string): Promise<string>
/**
 * 获取书签的图标地址（比 getBookmarkIconUrl 速度更快，但前提是之前访问过对应的页面，否则就是个默认图片）
 * @param url 书签地址
 * @param defaultIcon 用户指定的默认书签图标地址，如果指定了该值就会以该值为准，否则扩展内部会自动抓取图标地址
 */
getBookmarkIconUrlFast(url: string, defaultIcon?: string): Promise<string>
/**
 * 设置指定的循环类组件里书签图标
 * @param field 条目里的图片 Field，大部分情况传递 $self 即可
 * @param urlKey 链接对应的字段名，默认为 url
 * @param defaultIconKey 默认图标对应的字段名，默认为 icon
 * @param componentType 默认为 IteratorLayout 循环布局。可选值为 ArrayTable、Table、IteratorLayout、ArrayTabs、ArrayCards、ArrayAccordion 之一
 */
setArrayFieldRowBookmarkIcon(field: GeneralField, urlKey?: string, defaultIconKey?: string, componentType?: ComponentType): Promise<void>
/**
 * 获取 vip 配置信息
 * @param isNeedShowVipDialog 是否展示 vip 开通提示弹窗，默认为 true
 * @param isNeedCheckUpdate 是否检查更新，默认为 true
 */
getVipConfig(isNeedShowVipDialog?: boolean, isNeedCheckUpdate?: boolean): Promise<any>
/**
 * 获取扩展配置信息
 */
getAssistantConfig(): Promise<any>
/**
 * 在新标签页中打开链接
 * @param url 要打开的链接
 */
openUrlInNewTab(url: string): Promise<Tab | undefined>
/**
 * 在当前标签页中打开链接
 * @param url 要打开的链接
 */
openUrlInCurrentTab(url: string): Promise<Tab | undefined>
/**
 * 打开链接，该方法会判断运行环境，如果是编辑器环境，则在新标签页中打开链接，否则在当前标签页中打开链接
 * @param url 要打开的链接
 */
openUrl(url: string): Promise<Tab | undefined>
/**
 * 处理点击指定的循环类组件的条目链接
 * @param field 条目 Field 或条目里的子 Field，大部分情况传递 $self 即可
 * @param key 链接对应的字段名，默认为 url
 * @param componentType 默认为 IteratorLayout 循环布局。可选值为 ArrayTable、Table、IteratorLayout、ArrayTabs、ArrayCards、ArrayAccordion 之一
 */
clickArrayFieldUrlItem(field: GeneralField, key?: string, componentType?: 'IteratorLayout' | 'ArrayTable'|'Table' | 'ArrayTabs' | 'ArrayCards' | 'ArrayAccordion'): Promise<Tab | undefined>
/**
 * 修复 formilyItem 底部间距问题
 * @param $self 当前 field
 * @param $effect $effect 钩子
 */
fixAntFormilyItemMarginBottom($self: GeneralField, $effect: any): void
/**
 * 设置指定 Field 为区块根节点
 * @param field 要设置为区块根节点的 Field，大部分情况传递 $self 即可
 */
setAsBlockRoot(field: GeneralField): void
/**
 * 获取当前区块根节点
 * @param field 当前 Field，大部分情况传递 $self 即可
 * @param blockRootName 当前区块根节点字段标识。可选，如果传递了该值就根据该值查询，如果不传该值就查询包含属性 isBlockRoot 为 true 的节点
 */
getBlockRootField: (field: GeneralField, blockRootName?: string): GeneralField | null | undefined
/**
 * 生成 html 节点
 * @param html html 字符串
 * @param tagName 标签名称
 * @returns 生成的 html 节点
 */
html(html: string, tagName?: string): React.DOMElement
/**
 * 是否为低代码编辑器环境（是否为开发环境）
 */
isEditorEnv: boolean
/**
 * 是否为低代码预览环境（是否为发布后的环境）
 */
isPreviewEnv: boolean
}

export interface IGaLogger {
info(...args: any[]): void
success(...args: any[]): void
warn(...args: any[]): void
error(...args: any[]): void
}

declare global {
    /**
     * utils
     */
    declare var $utils: IGaUtils
    /**
     * logger
     */
    declare var $logger: IGaLogger
    /**
     * dayjs
     */
    declare var $dayjs: any
}
`,pa=`
import { Form, Field } from '@formily/core'
declare global {
  /*
   * Form Model
   **/
  declare var $form: Form
  /*
   * Form Values
   **/
  declare var $values: any
  /*
   * Field Model
   **/
  declare var $self: Field
  /*
   * create an persistent observable state object
   **/
  declare var $observable: <T>(target: T, deps?: any[]) => T
  /*
   * create a persistent data
   **/
  declare var $memo: <T>(callback: () => T, deps?: any[]) => T
  /*
   * handle side-effect logic
   **/
  declare var $effect: (callback: () => void | (() => void), deps?: any[]) => void
  /*
   * set initial component props to current field
   **/
  declare var $props: (props: any) => void
  /**
   * set formily schema
   */
  function $setFormilySchema(formilySchema: object): void
  /**
   * @formily/core
   */
  declare var $formilyCore: any
  /**
   * @formily/reactive
   */
  declare var $formilyReactive: any
}
`,ma=`
export interface MessageType extends PromiseLike<boolean> {
    (): void;
}
type TypeOpen = (content: any,
/**
 * @descCN 消息通知持续显示的时间，也可以直接使用 onClose。
 * @descEN You can also use onClose directly to determine how long the message notification continues to be displayed.
 */
duration?: number | VoidFunction,
/**
 * @descCN 消息通知关闭时进行调用的回调函数
 * @descEN The callback function called when the message notification is closed
 */
onClose?: VoidFunction) => MessageType;

type MessageMethods = Record<'info' | 'success' | 'error' | 'warning' | 'loading', TypeOpen>;

type ModalFunc = (props: object) => any;
type ModalStaticFunctions = Record<'info' | 'success' | 'error' | 'warning' | 'confirm', ModalFunc>;

declare global {
  /**
   * Ant Design message
   */
  declare var $message: MessageMethods
  /**
   * Ant Design modal
   */
  declare var $modal: ModalStaticFunctions
  /**
   * React
   */
  declare var $React: any
}
`,ha=async e=>Promise.all(e.map(async({name:e,path:t})=>({name:e,path:t,library:await fetch(`${fn()}/${e}/${t}`).then(e=>e.text())}))),ga=async()=>an.loader.init().then(async e=>{(await ha([{name:`@formily/core`,path:`dist/formily.core.all.d.ts`}]))?.forEach(({name:t,library:n})=>{e.languages.typescript.typescriptDefaults.addExtraLib(`declare module '${t}'{ ${n} }`,`file:///node_modules/${t}/index.d.ts`)}),e.languages.typescript.typescriptDefaults.addExtraLib(pa,`file:///node_modules/formily_global.d.ts`),e.languages.typescript.typescriptDefaults.addExtraLib(da,`file:///node_modules/ga_global_$ga.d.ts`),e.languages.typescript.typescriptDefaults.addExtraLib(fa,`file:///node_modules/ga_global_$utils.d.ts`),e.languages.typescript.typescriptDefaults.addExtraLib(ma,`file:///node_modules/ga_global_component.d.ts`)}),M=le({components:{Card:Oe,FormCollapse:st,Input:ut,TypeView:({value:e})=>{let t=String(e);return t.length<=26?(0,D.jsx)(Dt,{children:t}):(0,D.jsx)(Dt,{children:(0,D.jsxs)(se,{title:(0,D.jsx)(`div`,{style:{fontSize:12},children:(0,D.jsx)(`code`,{children:(0,D.jsx)(`pre`,{style:{whiteSpace:`pre-wrap`,padding:0,margin:0},children:t})})}),children:[t.substring(0,24),`...`]})})},Select:Le,FormItem:Ee,PathSelector:Qi,FieldPropertySetter:ua,ArrayTable:gt,MonacoInput:an}}),_a=`value.initialValue.inputValue.inputValues.modified.initialized.title.description.mounted.unmounted.active.visited.loading.errors.warnings.successes.feedbacks.valid.invalid.pattern.display.disabled.readOnly.readPretty.visible.hidden.editable.validateStatus.validating`.split(`.`),va={modified:`boolean`,initialized:`boolean`,title:`string`,description:`string`,mounted:`boolean`,unmounted:`boolean`,active:`boolean`,visited:`boolean`,loading:`boolean`,errors:`string[]`,warnings:`string[]`,successes:`string[]`,feedbacks:`Array<
  triggerType?: 'onInput' | 'onFocus' | 'onBlur'
  type?: 'error' | 'success' | 'warning'
  code?:
    | 'ValidateError'
    | 'ValidateSuccess'
    | 'ValidateWarning'
    | 'EffectError'
    | 'EffectSuccess'
    | 'EffectWarning'
  messages?: string[]
>
`,valid:`boolean`,invalid:`boolean`,pattern:`'editable' | 'disabled' | 'readOnly' | 'readPretty'`,display:`'visible' | 'hidden' | 'none'`,disabled:`boolean`,readOnly:`boolean`,readPretty:`boolean`,visible:`boolean`,hidden:`boolean`,editable:`boolean`,validateStatus:`'error' | 'warning' | 'success' | 'validating'`,validating:`boolean`},ya=e=>{let[t,n]=(0,E.useState)(!1),[r,i]=(0,E.useState)(!1),a=v(`reactions-setter`),o=(0,E.useMemo)(()=>On({values:bn(e.value)}),[t,e.value]),s=(0,E.useMemo)(()=>st.createFormCollapse([`run`,`deps`]),[t]),c=()=>n(!0),l=()=>n(!1);return(0,E.useEffect)(()=>{t?Xt(()=>{ga().then(()=>{i(!0)})},{timeout:400}):i(!1)},[t]),(0,D.jsxs)(D.Fragment,{children:[(0,D.jsx)(u,{block:!0,onClick:c,children:(0,D.jsx)(m,{token:`SettingComponents.ReactionsSetter.configureReactions`})}),(0,D.jsx)(Rt,{title:w.getDesignerMessage(`SettingComponents.ReactionsSetter.configureReactions`),width:`90%`,centered:!0,bodyStyle:{padding:10},transitionName:``,maskTransitionName:``,open:t,onCancel:l,destroyOnClose:!0,onOk:()=>{o.submit(t=>{e.onChange?.(t)}),l()},children:(0,D.jsx)(`div`,{className:a,children:r&&(0,D.jsx)(pt,{form:o,children:(0,D.jsx)(M,{children:(0,D.jsxs)(M.Void,{"x-component":`FormCollapse`,"x-component-props":{formCollapse:s,defaultActiveKey:[`run`,`deps`],style:{marginBottom:10}},children:[(0,D.jsx)(M.Void,{"x-component":`FormCollapse.CollapsePanel`,"x-component-props":{key:`run`,header:w.getDesignerMessage(`SettingComponents.ReactionsSetter.actionReactions`),className:`reaction-runner`},children:(0,D.jsx)(M.String,{name:`fulfill.run`,"x-component":`MonacoInput`,"x-component-props":{width:`100%`,height:400,language:`typescript`,helpCode:sa,options:{minimap:{enabled:!1}}},"x-reactions":e=>{let t=e.query(`dependencies`).value();Array.isArray(t)&&(e.componentProps.extraLib=`
                          declare var $deps : {
                            ${t.map(({name:e,type:t})=>e?`${e}?:${t||`any`},`:``)}
                          }
                          `)}})}),(0,D.jsx)(M.Void,{"x-component":`FormCollapse.CollapsePanel`,"x-component-props":{key:`deps`,header:w.getDesignerMessage(`SettingComponents.ReactionsSetter.relationsFields`)},children:(0,D.jsxs)(M.Array,{name:`dependencies`,default:[{}],"x-component":`ArrayTable`,children:[(0,D.jsxs)(M.Object,{children:[(0,D.jsx)(M.Void,{"x-component":`ArrayTable.Column`,"x-component-props":{title:w.getDesignerMessage(`SettingComponents.ReactionsSetter.sourceField`),width:240},children:(0,D.jsx)(M.String,{name:`source`,"x-decorator":`FormItem`,"x-component":`PathSelector`,"x-component-props":{placeholder:w.getDesignerMessage(`SettingComponents.ReactionsSetter.pleaseSelect`)}})}),(0,D.jsx)(M.Void,{"x-component":`ArrayTable.Column`,"x-component-props":{title:w.getDesignerMessage(`SettingComponents.ReactionsSetter.sourceProperty`),width:200},children:(0,D.jsx)(M.String,{name:`property`,default:`value`,"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{showSearch:!0},enum:_a})}),(0,D.jsx)(M.Void,{"x-component":`ArrayTable.Column`,"x-component-props":{title:w.getDesignerMessage(`SettingComponents.ReactionsSetter.variableName`),width:200},children:(0,D.jsx)(M.String,{name:`name`,"x-decorator":`FormItem`,"x-validator":{pattern:/^[$_a-zA-Z]+[$_a-zA-Z0-9]*$/,message:w.getDesignerMessage(`SettingComponents.ReactionsSetter.variableNameValidateMessage`)},"x-component":`Input`,"x-component-props":{addonBefore:`$deps.`,placeholder:w.getDesignerMessage(`SettingComponents.ReactionsSetter.pleaseInput`)},"x-reactions":e=>{kn(e)||e.query(`.source`).take(t=>{kn(t)||t.value&&!e.value&&!e.modified&&(e.value=t.inputValues[1]?.props?.name||`v_${Dn()}`)})}})}),(0,D.jsx)(M.Void,{"x-component":`ArrayTable.Column`,"x-component-props":{title:w.getDesignerMessage(`SettingComponents.ReactionsSetter.variableType`),ellipsis:{showTitle:!1},width:200,align:`center`},children:(0,D.jsx)(M.String,{name:`type`,default:`any`,"x-decorator":`FormItem`,"x-component":`TypeView`,"x-reactions":e=>{if(kn(e))return;let t=e.query(`.property`).get(`inputValues`);t&&(t[0]=t[0]||`value`,e.query(`.source`).take(n=>{kn(n)||n.value&&(e.value=t[0]===`value`||t[0]===`initialValue`||t[0]===`inputValue`?n.inputValues[1]?.props?.type||`any`:t[0]===`inputValues`?`any[]`:t[0]?va[t[0]]:`any`)}))}})}),(0,D.jsx)(M.Void,{"x-component":`ArrayTable.Column`,"x-component-props":{title:w.getDesignerMessage(`SettingComponents.ReactionsSetter.operations`),align:`center`,width:80},children:(0,D.jsx)(M.Markup,{type:`void`,"x-component":`ArrayTable.Remove`})})]}),(0,D.jsx)(M.Void,{title:w.getDesignerMessage(`SettingComponents.ReactionsSetter.addRelationField`),"x-component":`ArrayTable.Addition`,"x-component-props":{style:{marginTop:8}}})]})}),(0,D.jsx)(M.Void,{"x-component":`FormCollapse.CollapsePanel`,"x-component-props":{header:w.getDesignerMessage(`SettingComponents.ReactionsSetter.propertyReactions`),key:`state`,className:`reaction-state`},children:(0,D.jsx)(M.Markup,{name:`fulfill.state`,"x-component":`FieldPropertySetter`})})]})})})})})]})},ba={type:`array`,items:{type:`object`,"x-decorator":`ArrayItems.Item`,"x-decorator-props":{style:{alignItems:`center`,borderRadius:3,paddingTop:6,paddingBottom:6}},properties:{sortable:{type:`void`,"x-component":`ArrayItems.SortHandle`,"x-component-props":{style:{marginRight:10}}},drawer:{type:`void`,"x-component":`DrawerSetter`,properties:{triggerType:{type:`string`,enum:[`onInput`,`onFocus`,`onBlur`],"x-decorator":`FormItem`,"x-component":`Select`},validator:{type:`string`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},message:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`},format:{type:`string`,"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{allowClear:!0}},pattern:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{prefix:`/`,suffix:`/`}},len:{type:`string`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},max:{type:`string`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},min:{type:`string`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},exclusiveMaximum:{type:`string`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},exclusiveMinimum:{type:`string`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},whitespace:{type:`string`,"x-decorator":`FormItem`,"x-component":`Switch`},required:{type:`string`,"x-decorator":`FormItem`,"x-component":`Switch`}}},moveDown:{type:`void`,"x-component":`ArrayItems.MoveDown`,"x-component-props":{style:{marginLeft:10}}},moveUp:{type:`void`,"x-component":`ArrayItems.MoveUp`,"x-component-props":{style:{marginLeft:5}}},remove:{type:`void`,"x-component":`ArrayItems.Remove`,"x-component-props":{style:{marginLeft:5}}}}},properties:{addValidatorRules:{type:`void`,"x-component":`ArrayItems.Addition`,"x-component-props":{style:{marginBottom:10}}}}},xa=x(e=>{let t=It();return(0,D.jsxs)(Lt,{label:t.title,children:[(0,D.jsx)(Lt.Base,{children:(0,D.jsx)(St,{value:Array.isArray(e.value)?void 0:e.value,onChange:e.onChange,allowClear:!0,placeholder:w.getDesignerMessage(`SettingComponents.ValidatorSetter.pleaseSelect`),options:w.getDesignerMessage(`SettingComponents.ValidatorSetter.formats`)})}),(0,D.jsx)(Lt.Extra,{children:(0,D.jsx)(Tt.Provider,{value:new Pn(ba),children:(0,D.jsx)(xt,{})})})]})}),Sa=e=>(0,D.jsx)(ve,{checked:e.value===`FormItem`,onChange:t=>{e.onChange?.(t?`FormItem`:void 0)}}),Ca={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/input-cn`,properties:{addonBefore:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},addonAfter:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},prefix:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},suffix:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},maxLength:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{type:`string`,enum:[`large`,`small`,`middle`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}}}};Ca.TextArea={type:`object`,properties:{bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},maxLength:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},autoSize:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showCount:{"x-decorator":`FormItem`,"x-component":`Switch`}}};var wa={type:`object`,properties:{content:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`},mode:{type:`string`,"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`normal`},enum:[`h1`,`h2`,`h3`,`p`,`normal`]}}},Ta={type:`object`,properties:{labelCol:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},wrapperCol:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},labelWidth:{"x-decorator":`FormItem`,"x-component":`SizeInput`},wrapperWidth:{"x-decorator":`FormItem`,"x-component":`SizeInput`},colon:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},feedbackLayout:{type:`string`,enum:[`loose`,`terse`,`popover`,`none`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`loose`}},size:{type:`string`,enum:[`large`,`small`,`default`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},layout:{type:`string`,enum:[`vertical`,`horizontal`,`inline`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`horizontal`}},tooltipLayout:{type:`string`,enum:[`icon`,`text`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`icon`}},labelAlign:{type:`string`,enum:[`left`,`right`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`right`}},wrapperAlign:{type:`string`,enum:[`left`,`right`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`left`}},labelWrap:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},wrapperWrap:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},fullness:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},inset:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},shallow:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}}}},Ea={type:`void`,properties:{"style.width":{type:`string`,"x-decorator":`FormItem`,"x-component":`SizeInput`},"style.height":{type:`string`,"x-decorator":`FormItem`,"x-component":`SizeInput`},"style.display":{"x-component":`DisplayStyleSetter`},"style.background":{"x-component":`BackgroundStyleSetter`},"style.boxShadow":{"x-component":`BoxShadowStyleSetter`},"style.font":{"x-component":`FontStyleSetter`},"style.margin":{"x-component":`BoxStyleSetter`},"style.padding":{"x-component":`BoxStyleSetter`},"style.borderRadius":{"x-component":`BorderRadiusStyleSetter`},"style.border":{"x-component":`BorderStyleSetter`},"style.opacity":{"x-decorator":`FormItem`,"x-component":`Slider`,"x-component-props":{defaultValue:1,min:0,max:1,step:.01}}}},Da={type:`object`,properties:{...Ta.properties,style:Ea}},Oa={type:`object`,properties:{className:{type:`string`,"x-component":`TailwindCSSPicker`},tooltip:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},addonBefore:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},addonAfter:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},labelCol:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},wrapperCol:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},labelWidth:{"x-decorator":`FormItem`,"x-component":`SizeInput`},wrapperWidth:{"x-decorator":`FormItem`,"x-component":`SizeInput`},colon:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},asterisk:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},gridSpan:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},feedbackLayout:{type:`string`,enum:[`loose`,`terse`,`popover`,`none`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`loose`}},size:{type:`string`,enum:[`large`,`small`,`default`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},layout:{type:`string`,enum:[`vertical`,`horizontal`,`inline`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`horizontal`}},tooltipLayout:{type:`string`,enum:[`icon`,`text`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`icon`}},labelAlign:{type:`string`,enum:[`left`,`right`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`right`}},wrapperAlign:{type:`string`,enum:[`left`,`right`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`left`}},labelWrap:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},wrapperWrap:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},fullness:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},inset:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}}}},ka={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/select-cn`,properties:{mode:{type:`string`,enum:[`multiple`,`tags`,{value:null}],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:null,optionType:`button`}},allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},autoClearSearchValue:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},dropdownMatchSelectWidth:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},defaultActiveFirstOption:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},defaultOpen:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},labelInValue:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showArrow:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showSearch:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},virtual:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},filterOption:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`BOOLEAN`,`EXPRESSION`]}},filterSort:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},listHeight:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:256}},maxTagCount:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},maxTagPlaceholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},maxTagTextLength:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},notFoundContent:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{defaultValue:`Not Found`}},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{type:`string`,enum:[`large`,`small`,`middle`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}}}},Aa={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/card-cn`,properties:{title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},extra:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},type:{type:`boolean`,enum:w.getDesignerMessage(`settings.cardTypes`),"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:``,optionType:`button`}},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}}}},ja={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/cascader-cn`,properties:{allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},changeOnSelect:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},displayRender:{type:`string`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},fieldNames:{type:`string`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},showSearch:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},notFoundContent:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{defaultValue:`Not Found`}},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{type:`string`,enum:[`large`,`small`,`middle`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}}}},Ma={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/checkbox-cn`,properties:{autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}},Na={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/radio-cn`,properties:{autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}};Na.Group={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/radio-cn`,properties:{optionType:{type:`string`,enum:[`default`,`button`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`default`,optionType:`button`}},buttonStyle:{type:`string`,enum:[`outline`,`solid`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`outline`,optionType:`button`}}}};var Pa={allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},disabledTime:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},disabledDate:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},inputReadOnly:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{type:`string`,enum:[`large`,`small`,`middle`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}},format:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`YYYY-MM-DD`}}},Fa={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/date-picker-cn`,properties:{picker:{type:`string`,enum:[`time`,`date`,`month`,`year`,`quarter`,`decade`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`date`}},...Pa,showNow:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showTime:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showToday:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}};Fa.RangePicker={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/date-picker-cn`,properties:{picker:{type:`string`,enum:[`time`,`date`,`month`,`year`,`decade`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`date`}},...Pa,showTime:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}};var Ia={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/input-number-cn`,properties:{decimalSeparator:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},precision:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},max:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},min:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},step:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{type:`string`,enum:[`large`,`small`,`middle`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}},formatter:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},parser:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},stringMode:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},keyboard:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}}}},La={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/input-cn`,properties:{...Ca.properties,checkStrength:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}},Ra={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/rate-cn`,properties:{allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},count:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:5}},allowHalf:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},tooltips:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}},za={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/slider-cn`,properties:{allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},dots:{title:w.getDesignerMessage(`settings.sliderDots`),type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},range:{title:w.getDesignerMessage(`settings.sliderRange`),type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},reverse:{title:w.getDesignerMessage(`settings.sliderReverse`),type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},vertical:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},tooltipVisible:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},tooltipPlacement:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},marks:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},max:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:100}},min:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:0}},step:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1}}}},Ba={allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},clearText:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},disabledHours:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},disabledMinutes:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},disabledSeconds:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},hideDisabledOptions:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},inputReadOnly:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showNow:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},use12Hours:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},hourStep:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1}},minuteStep:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1}},secondStep:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1}},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{type:`string`,enum:[`large`,`small`,`middle`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`},format:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`YYYY-MM-DD`}}},Va={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/time-picker-cn`,properties:Ba};Va.RangePicker={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/time-picker-cn`,properties:Ba};var Ha={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/tree-select-cn`,properties:{allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},autoClearSearchValue:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},labelInValue:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showArrow:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showSearch:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},virtual:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},treeCheckable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},treeDefaultExpandAll:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},dropdownMatchSelectWidth:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},showCheckedStrategy:{type:`string`,enum:[`SHOW_ALL`,`SHOW_PARENT`,`SHOW_CHILD`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`SHOW_CHILD`}},treeDefaultExpandedKeys:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},treeNodeFilterProp:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},treeNodeLabelProp:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},filterTreeNode:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`BOOLEAN`,`EXPRESSION`]}},treeDataSimpleMode:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`BOOLEAN`,`EXPRESSION`]}},listHeight:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:256}},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{type:`string`,enum:[`large`,`small`,`middle`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}}}},Ua={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/transfer-cn`,properties:{oneWay:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showSearch:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},showSearchAll:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},filterOption:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},operations:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},titles:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}}}},Wa={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/upload-cn`,properties:{textContent:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},accept:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},action:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`TEXT`,`EXPRESSION`]}},name:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{defaultValue:`file`}},maxCount:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},method:{enum:[`POST`,`PUT`,`GET`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`POST`,optionType:`button`}},data:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},headers:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},listType:{enum:[`text`,`picture`,`picture-card`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`text`,optionType:`button`}},directory:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},multiple:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},openFileDialogOnClick:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},showUploadList:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},withCredentials:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}};Wa.Dragger=Wa;var Ga={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/switch-cn`,properties:{autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},size:{type:`string`,enum:[`large`,`small`,`default`,``],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}}}},Ka={type:`object`,properties:{minWidth:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:100}},maxWidth:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},minColumns:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:0}},maxColumns:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},breakpoints:{type:`number`,"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`EXPRESSION`]}},columnGap:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:10}},rowGap:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:5}},colWrap:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},strictAutoFit:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}}}};Ka.GridColumn={type:`object`,properties:{gridSpan:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1}}}};var qa={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/space-cn`,properties:{align:{type:`string`,enum:[`start`,`end`,`center`,`baseline`],"x-decorator":`FormItem`,"x-component":`Select`},direction:{type:`string`,enum:[`vertical`,`horizontal`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`horizontal`,optionType:`button`}},size:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:8}},split:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},wrap:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}},Ja={type:`object`,properties:{animated:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},centered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},size:{type:`string`,enum:[`large`,`small`,`default`,{value:null}],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},type:{type:`string`,"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`line`,optionType:`button`}}}};Ja.TabPane={type:`object`,properties:{tab:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`}}};var Ya={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/collapse-cn`,properties:{accordion:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},collapsible:{type:`string`,enum:[`header`,`disabled`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`header`,optionType:`button`}},ghost:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}}}};Ya.CollapsePanel={type:`object`,properties:{collapsible:{type:`string`,enum:[`header`,`disabled`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`header`,optionType:`button`}},header:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Input`},extra:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Input`}}};var Xa={type:`object`,properties:{bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},showHeader:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},sticky:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},size:{type:`string`,enum:[`large`,`small`,`middle`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`small`}},tableLayout:{type:`string`,enum:[`auto`,`fixed`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`auto`,optionType:`button`}}}};Xa.Column={type:`object`,properties:{title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},align:{type:`string`,enum:[`left`,`right`,`center`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`left`,optionType:`button`}},colSpan:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},width:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},fixed:{type:`string`,enum:[`left`,`right`,!1],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{optionType:`button`}}}},Xa.Addition={type:`object`,properties:{method:{type:`string`,enum:[`push`,`unshift`],"x-decorator":`FormItem`,"x-component":`Radio.Group`,"x-component-props":{defaultValue:`push`,optionType:`button`}},defaultValue:{type:`string`,"x-decorator":`FormItem`,"x-component":`ValueInput`}}};var Za=Aa;Za.Addition=Xa.Addition;var Qa={type:`object`,properties:{children:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`}}},$a={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/qr-code-cn`,properties:{content:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`我是二维码的内容`},type:{type:`string`,enum:[`canvas`,`svg`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`canvas`}},icon:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:160}},iconSize:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:40}},color:{type:`string`,"x-decorator":`FormItem`,"x-component":`ColorInput`,"x-component-props":{defaultValue:`#000`}},bgColor:{type:`string`,"x-decorator":`FormItem`,"x-component":`ColorInput`,"x-component-props":{defaultValue:`transparent`}},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},errorLevel:{type:`string`,enum:[`L`,`M`,`Q`,`H`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`M`}}}},N={type:`string`,enum:Object.keys(sn).filter(e=>e.charAt(0)>=`A`&&e.charAt(0)<=`Z`),"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{showSearch:!0,allowClear:!0}},eo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/button-cn`,properties:{children:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`按钮`},type:{type:`string`,enum:[`primary`,`dashed`,`link`,`text`,`default`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},href:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},danger:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},shape:{type:`string`,enum:[`default`,`circle`,`round`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},size:{type:`string`,enum:[`large`,`middle`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}},target:{type:`string`,enum:[`_self`,`_blank`,`_parent`,`_top`],"x-decorator":`FormItem`,"x-component":`Select`,default:`_blank`},icon:{...N},iconPosition:{type:`string`,enum:[`start`,`end`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`start`}},block:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},autoInsertSpace:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},ghost:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},loading:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},disabled:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},htmlType:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{defaultValue:`button`}}}},to={icon:{...N},description:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},tooltip:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},type:{type:`string`,enum:[`primary`,`default`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},shape:{type:`string`,enum:[`circle`,`square`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`circle`}},insetInlineEnd:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},insetBlockEnd:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},disabled:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},badge:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`}},no={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/float-button-cn`,properties:{...to,href:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},target:{type:`string`,enum:[`_self`,`_blank`,`_parent`,`_top`],"x-decorator":`FormItem`,"x-component":`Select`,default:`_blank`}}},ro={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/float-button-cn`,properties:{trigger:{type:`string`,enum:[``,`click`,`hover`],"x-decorator":`FormItem`,"x-component":`Select`},...to}},io={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/float-button-cn`,properties:{duration:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:450}},visibilityHeight:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:400}},...to}},ao={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/divider-cn`,properties:{children:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`分割线`},variant:{type:`string`,enum:[`dashed`,`dotted`,`solid`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`solid`}},orientation:{type:`string`,enum:[`left`,`right`,`center`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`center`}},orientationMargin:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},plain:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},type:{type:`string`,enum:[`horizontal`,`vertical`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`horizontal`}}}},oo={type:`object`,properties:{}},so={type:`object`,properties:{"x-link":{"x-component":u,"x-component-props":{block:!0,type:`primary`,style:{marginBottom:10},children:`查看低代码区块模版市场`,onClick:()=>{$gaContext.$ga.dynamicSchemaBlockTemplateMarket()}}},schema:{type:`object`,title:`本地动态 schema`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},schemaUrl:{type:`string`,title:`远程 schema url`,"x-decorator":`FormItem`,"x-component":`Input`},cacheRemoteSchema:{type:`boolean`,title:`缓存远程 schema`,"x-decorator":`FormItem`,"x-component":`Switch`,default:!0},valueType:{type:`string`,title:`值类型`,enum:[{label:`对象包裹：以当前字段标识把动态区块里的字段包裹一层`,value:`object`},{label:`展开：把动态区块里的多个字段平铺展开`,value:`unfold`}],"x-decorator":`FormItem`,"x-component":`Select`,default:`object`},reset:{type:`boolean`,title:`切换动态 schema 时是否重置表单状态`,"x-decorator":`FormItem`,"x-component":`Switch`,default:!0}}},co={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/drawer-cn`,properties:{open:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},extra:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},footer:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},placement:{type:`string`,enum:[`top`,`right`,`bottom`,`left`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`right`}},autoFocus:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},mask:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},maskClosable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},size:{type:`string`,enum:[`default`,`large`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},width:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:378}},height:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:378}},rootStyle:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},styles:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},classNames:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},loading:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},closeIcon:{...N},destroyOnClose:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},keyboard:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},push:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`BOOLEAN`,`JSON`]},default:{distance:180}},zIndex:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1e3}},forceRender:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}}}},lo={arrow:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},autoAdjustOverflow:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},color:{type:`string`,"x-decorator":`FormItem`,"x-component":`ColorInput`},defaultOpen:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},open:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},destroyTooltipOnHide:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},fresh:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},mouseEnterDelay:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:.1}},mouseLeaveDelay:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:.1}},overlayClassName:{type:`string`,"x-decorator":`FormItem`,"x-component":`TailwindCSSPicker`},overlayStyle:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},overlayInnerStyle:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},placement:{type:`string`,enum:[`top`,`left`,`right`,`bottom`,`topLeft`,`topRight`,`bottomLeft`,`bottomRight`,`leftTop`,`leftBottom`,`rightTop`,`rightBottom`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`top`}},trigger:{type:`string`,enum:[`hover`,`focus`,`click`,`contextMenu`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{mode:`tags`},default:[`hover`]},zIndex:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`}},uo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/tooltip-cn`,properties:{title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},...lo}},fo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/modal-cn`,properties:{open:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},centered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},closable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},closeIcon:{...N},footer:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},keyboard:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},mask:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},maskClosable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},cancelButtonProps:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},cancelText:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`取消`},okButtonProps:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},okText:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`确定`},okType:{type:`string`,enum:[`primary`,`dashed`,`link`,`text`,`default`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`primary`}},width:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:520}},classNames:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},styles:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},wrapClassName:{type:`string`,"x-decorator":`FormItem`,"x-component":`TailwindCSSPicker`},confirmLoading:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},loading:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},zIndex:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1e3}},destroyOnClose:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},focusTriggerAfterClose:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},forceRender:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}}}},po={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/popconfirm-cn`,properties:{icon:{...N,default:`ExclamationCircleFilled`},title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},description:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},okButtonProps:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},okText:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`确定`},okType:{type:`string`,enum:[`primary`,`dashed`,`link`,`text`,`default`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`primary`}},cancelButtonProps:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},cancelText:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`取消`},showCancel:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},disabled:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},...lo}},mo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/popover-cn`,properties:{title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},content:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},...lo}},ho={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/spin-cn`,properties:{delay:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},fullscreen:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},indicator:{...N},percent:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},size:{type:`string`,enum:[`small`,`default`,`large`],"x-decorator":`FormItem`,"x-component":`Select`,default:`small`},spinning:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},tip:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},wrapperClassName:{type:`string`,"x-decorator":`FormItem`,"x-component":`TailwindCSSPicker`}}},go={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/tag-cn`,properties:{children:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},color:{type:`string`,"x-decorator":`FormItem`,"x-component":`ColorInput`},icon:{...N},closeIcon:{...N},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}}}},_o={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/tag-cn`,properties:{children:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},checked:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}}}},vo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/alert-cn`,properties:{message:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`这是一条提示信息`},description:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`},type:{type:`string`,enum:[`success`,`info`,`warning`,`error`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`info`}},showIcon:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},closable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},banner:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},action:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`如：关闭 / 知道了（需 reactions 注入 ReactNode）`}}}},yo={type:`object`,"x-usage-href":`https://developer.mozilla.org/zh-CN/docs/Web/HTML/Element/iframe`,properties:{sandbox:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`allow-scripts allow-same-origin allow-forms`}},loading:{type:`string`,enum:[`lazy`,`eager`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`eager`}}}},bo={type:`object`,properties:{language:{type:`string`,enum:[`javascript`,`typescript`,`json`,`css`,`html`,`less`,`scss`,`markdown`,`shell`,`python`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`javascript`,allowClear:!0}},theme:{type:`string`,enum:[`light`,`vs-dark`,`hc-black`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`light`,allowClear:!0}},height:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:300}},width:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{defaultValue:`100%`,placeholder:`如：100%、400、400px`}},fontSize:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:13}},tabSize:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:2}},minimap:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},wordWrap:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},readOnly:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!1}},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`}}},xo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/descriptions-cn`,properties:{title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`详情信息`},items:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{label:`名称`,children:`示例名称`},{label:`状态`,children:`正常`}]},column:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:3}},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},size:{type:`string`,enum:[`default`,`middle`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},layout:{type:`string`,enum:[`horizontal`,`vertical`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`horizontal`}}}},So={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/steps-cn`,properties:{items:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{title:`第一步`},{title:`第二步`},{title:`第三步`}]},current:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:0}},direction:{type:`string`,enum:[`horizontal`,`vertical`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`horizontal`}},status:{type:`string`,enum:[`wait`,`process`,`finish`,`error`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`process`}},size:{type:`string`,enum:[`default`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},progressDot:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},type:{type:`string`,enum:[`default`,`navigation`,`inline`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}}}},Co={type:`void`,"x-usage-href":`https://ant-design.antgroup.com/components/result-cn`,properties:{status:{type:`string`,enum:[`success`,`error`,`info`,`warning`,`404`,`403`,`500`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`success`}},title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`操作成功`},subTitle:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`},icon:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`可通过 reactions 注入自定义图标`}},extra:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`可通过 reactions 注入操作按钮`}}}},wo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/statistic-cn`,properties:{title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`统计标题`},prefix:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},suffix:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},precision:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},groupSeparator:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`,`},valueStyle:{type:`object`,"x-decorator":`FormItem`,"x-component":`JsonEditor`},loading:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}}}},To={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/timeline-cn`,properties:{items:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{children:`创建服务 2024-01-01`},{children:`初步排查问题 2024-01-02`},{children:`解决问题 2024-01-03`}]},mode:{type:`string`,enum:[`left`,`alternate`,`right`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`left`}},reverse:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},pending:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}}}},Eo={type:`void`,"x-usage-href":`https://ant-design.antgroup.com/components/badge-cn`,properties:{count:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:5}},overflowCount:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:99}},dot:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},showZero:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},status:{type:`string`,enum:[`success`,`processing`,`default`,`error`,`warning`],"x-decorator":`FormItem`,"x-component":`Select`},text:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},color:{type:`string`,"x-decorator":`FormItem`,"x-component":`ColorInput`},size:{type:`string`,enum:[`default`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}}}},Do={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/progress-cn`,properties:{percent:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:30,min:0,max:100}},type:{type:`string`,enum:[`line`,`circle`,`dashboard`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`line`}},status:{type:`string`,enum:[`normal`,`active`,`success`,`exception`],"x-decorator":`FormItem`,"x-component":`Select`},size:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},showInfo:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},strokeColor:{type:`string`,"x-decorator":`FormItem`,"x-component":`ColorInput`},steps:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`},strokeLinecap:{type:`string`,enum:[`round`,`butt`,`square`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`round`}}}},Oo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/collapse-cn`,properties:{accordion:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}},collapsible:{type:`string`,enum:[`header`,`icon`,`disabled`],"x-decorator":`FormItem`,"x-component":`Select`},ghost:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},size:{type:`string`,enum:[`large`,`middle`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}},expandIconPosition:{type:`string`,enum:[`start`,`end`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`start`}},defaultActiveKey:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`,`EXPRESSION`]},"x-component-props.placeholder":`如：["1"] 或 "1"`}}};Oo.Panel={type:`object`,properties:{header:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},extra:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},collapsible:{type:`string`,enum:[`header`,`icon`,`disabled`],"x-decorator":`FormItem`,"x-component":`Select`}}};var ko={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/tabs-cn`,properties:{type:{type:`string`,enum:[`line`,`card`,`editable-card`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`line`}},tabPosition:{type:`string`,enum:[`top`,`right`,`bottom`,`left`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`top`}},size:{type:`string`,enum:[`large`,`middle`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}},centered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},animated:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},defaultActiveKey:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`默认第一个 Tab，可填具体 key`}},destroyInactiveTabPane:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}}}};ko.TabPane={type:`object`,properties:{tab:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`}}};var Ao={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/table-cn`,properties:{columns:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{title:`名称`,dataIndex:`name`,key:`name`},{title:`状态`,dataIndex:`status`,key:`status`}]},dataSource:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[]},size:{type:`string`,enum:[`large`,`middle`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`large`}},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},showHeader:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},pagination:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`BOOLEAN`,`JSON`]},default:{pageSize:10}},scroll:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},"x-component-props.placeholder":`如：{ x: 800, y: 400 }`},loading:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},rowKey:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`默认自动推断，如：id 或 key`}},sticky:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}}}},jo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/menu-cn`,properties:{items:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{key:`1`,label:`菜单项一`},{key:`2`,label:`菜单项二`},{key:`sub`,label:`子菜单`,children:[{key:`3`,label:`子项一`}]}]},mode:{type:`string`,enum:[`horizontal`,`vertical`,`inline`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`inline`}},theme:{type:`string`,enum:[`light`,`dark`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`light`}},inlineCollapsed:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},multiple:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},selectable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},defaultSelectedKeys:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},"x-component-props.placeholder":`如：["1"]`},defaultOpenKeys:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},"x-component-props.placeholder":`如：["sub"]`}}},Mo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/tree-cn`,properties:{treeData:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{title:`父节点一`,key:`0-0`,children:[{title:`子节点一`,key:`0-0-0`}]},{title:`父节点二`,key:`0-1`}]},checkable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},defaultExpandAll:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},showLine:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},showIcon:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},draggable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},blockNode:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},selectable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},multiple:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},height:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{placeholder:`如：400，不填则不启用虚拟滚动`}}}},No={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/list-cn`,properties:{dataSource:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{title:`列表项一`},{title:`列表项二`},{title:`列表项三`}]},header:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},footer:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},bordered:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},size:{type:`string`,enum:[`large`,`default`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},split:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},loading:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}}}},Po={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/pagination-cn`,properties:{total:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:100}},defaultCurrent:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1}},pageSize:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:10}},showSizeChanger:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},showQuickJumper:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},showTotal:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`如：共 {total} 条，当前 {range[0]}-{range[1]}`}},simple:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},size:{type:`string`,enum:[`default`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},align:{type:`string`,enum:[`start`,`center`,`end`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`end`}}}},Fo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/breadcrumb-cn`,properties:{items:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{title:`首页`},{title:`列表页`},{title:`详情页`}]},separator:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{defaultValue:`/`}}}},Io={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/image-cn`,properties:{src:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png`},alt:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},objectFit:{type:`string`,enum:[`cover`,`contain`,`fill`,`none`,`scale-down`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`cover`}},width:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`NUMBER`,`EXPRESSION`]},default:200},height:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`NUMBER`,`EXPRESSION`]}},preview:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},fallback:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},placeholder:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},loading:{type:`string`,enum:[`eager`,`lazy`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`eager`}}}},Lo={type:`void`,"x-usage-href":`https://ant-design.antgroup.com/components/skeleton-cn`,properties:{active:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},loading:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},avatar:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},title:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},paragraph:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},round:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},rows:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:3,min:1}}}},Ro={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/avatar-cn`,properties:{src:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},size:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`NUMBER`,`EXPRESSION`]},"x-component-props.defaultValue":40},shape:{type:`string`,enum:[`circle`,`square`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`circle`}},icon:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},alt:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},children:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`如：王、A（无图片时显示）`}}}},zo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/dropdown-cn`,properties:{label:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`下拉菜单`},items:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{key:`1`,label:`选项一`},{key:`2`,label:`选项二`},{key:`3`,label:`选项三`}]},placement:{type:`string`,enum:[`bottomLeft`,`bottomCenter`,`bottomRight`,`topLeft`,`topCenter`,`topRight`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`bottomLeft`}},trigger:{type:`string`,enum:[`click`,`hover`,`contextMenu`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`hover`}},disabled:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}},Bo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/empty-cn`,properties:{description:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`暂无数据`},imageStyle:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]}}}},Vo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/typography-cn`,properties:{children:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`,"x-component-props":{autoSize:{minRows:1,maxRows:6}}},variant:{type:`string`,enum:[`text`,`title`,`paragraph`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`text`}},level:{type:`number`,enum:[1,2,3,4,5],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:1},"x-reactions":{dependencies:[`.variant`],fulfill:{state:{visible:`{{$deps[0] === "title"}}`}}}},type:{type:`string`,enum:[``,`secondary`,`success`,`warning`,`danger`],"x-decorator":`FormItem`,"x-component":`Select`},strong:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},italic:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},underline:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},delete:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},code:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},mark:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},ellipsis:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},copyable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}},Ho={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/segmented-cn`,properties:{options:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[`选项一`,`选项二`,`选项三`]},size:{type:`string`,enum:[`large`,`middle`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}},block:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},disabled:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}},Uo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/carousel-cn`,properties:{value:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[`幻灯片 1`,`幻灯片 2`,`幻灯片 3`]},autoplay:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}},dots:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},dotPosition:{type:`string`,enum:[`top`,`bottom`,`left`,`right`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`bottom`}},effect:{type:`string`,enum:[`scrollx`,`fade`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`scrollx`}},infinite:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}}}},Wo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/calendar-cn`,properties:{fullscreen:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},mode:{type:`string`,enum:[`month`,`year`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`month`}}}},Go={type:`void`,"x-usage-href":`https://ant-design.antgroup.com/components/watermark-cn`,properties:{content:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`水印文字`},rotate:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:-22}},zIndex:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:9}},gap:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[100,100]},font:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]}},image:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`图片 URL，配置后优先于文字水印`}}}},Ko={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/tour-cn`,properties:{steps:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{title:`步骤一`,description:`这是第一步的说明`},{title:`步骤二`,description:`这是第二步的说明`}]},type:{type:`string`,enum:[`default`,`primary`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},arrow:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},placement:{type:`string`,enum:[`top`,`bottom`,`left`,`right`,`center`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`bottom`}},open:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}}}},qo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/splitter-cn`,properties:{layout:{type:`string`,enum:[`horizontal`,`vertical`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`horizontal`}}}};qo.Panel={type:`object`,properties:{defaultSize:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`如: 200 或 30%`}},min:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`如: 100 或 20%`}},max:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:`如: 600 或 80%`}},collapsible:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},resizable:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultChecked:!0}}}};var Jo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/color-picker-cn`,properties:{defaultValue:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,default:`#1677ff`},format:{type:`string`,enum:[`hex`,`rgb`,`hsb`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`hex`}},size:{type:`string`,enum:[`large`,`middle`,`small`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`middle`}},showText:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},allowClear:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},disabled:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},disabledAlpha:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},presets:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},"x-component-props.placeholder":`如：[{ label: "推荐", colors: ["#1677ff"] }]`}}},Yo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/anchor-cn`,properties:{items:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{key:`part-1`,href:`#part-1`,title:`第一部分`},{key:`part-2`,href:`#part-2`,title:`第二部分`}]},direction:{type:`string`,enum:[`vertical`,`horizontal`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`vertical`}},affix:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},replace:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},offsetTop:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{placeholder:`如：64（Header 高度）`}},targetOffset:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{placeholder:`默认等于 offsetTop`}}}},Xo={type:`object`,"x-usage-href":`https://ant-design.antgroup.com/components/mentions-cn`,properties:{options:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:[{value:`afc163`,label:`afc163`},{value:`zombieJ`,label:`zombieJ`},{value:`yesmeck`,label:`yesmeck`}]},prefix:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{defaultValue:`@`}},placeholder:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},rows:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:1}},autoSize:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},disabled:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`},status:{type:`string`,enum:[``,`error`,`warning`],"x-decorator":`FormItem`,"x-component":`Select`}}},Zo={type:`object`,"x-usage-href":`https://echarts.apache.org/zh/option.html`,properties:{option:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]},default:{title:{text:`ECharts 示例`},tooltip:{},xAxis:{data:[`Mon`,`Tue`,`Wed`,`Thu`,`Fri`,`Sat`,`Sun`]},yAxis:{},series:[{name:`销量`,type:`bar`,data:[120,200,150,80,70,110,130]}]}},height:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:300}},width:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`NUMBER`,`EXPRESSION`]}},theme:{type:`string`,enum:[``,`dark`,`vintage`,`macarons`,`infographic`,`shine`,`roma`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{allowClear:!0}},renderer:{type:`string`,enum:[`canvas`,`svg`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`canvas`}},autoResize:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!0}},style:{"x-decorator":`FormItem`,"x-component":`CSSStyle`}}},Qo={type:`object`,"x-usage-href":`https://mermaid.js.org/intro/`,properties:{mode:{type:`string`,"x-decorator":`FormItem`,"x-component":`Select`,enum:[{label:`仅编辑`,value:`edit`},{label:`仅预览`,value:`preview`},{label:`同时编辑和预览`,value:`both`}],default:`both`},showModeSwitch:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,default:!0},definition:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`,"x-component-props":{rows:8,placeholder:`flowchart LR
  A --> B`},default:`flowchart LR
  A[开始] --> B{判断}
  B -- 是 --> C[处理]
  B -- 否 --> D[结束]
  C --> D`},theme:{type:`string`,enum:[`default`,`dark`,`forest`,`base`,`neutral`],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`default`}},style:{"x-decorator":`FormItem`,"x-component":`CSSStyle`}}},$o={type:`object`,"x-usage-href":`https://commonmark.org/`,properties:{mode:{type:`string`,"x-decorator":`FormItem`,"x-component":`Select`,enum:[{label:`仅编辑`,value:`edit`},{label:`仅预览`,value:`preview`},{label:`同时编辑和预览`,value:`both`}],default:`both`},showModeSwitch:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,default:!0},content:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`,"x-component-props":{rows:8,placeholder:`# 标题

正文内容...`},default:`# 标题

这里是 **Markdown** 内容。

- 列表项一
- 列表项二`},style:{"x-decorator":`FormItem`,"x-component":`ValueInput`,"x-component-props":{include:[`JSON`]}}}},es={type:`object`,properties:{storageKey:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-component-props":{placeholder:Ft},default:Ft},height:{type:`number`,"x-decorator":`FormItem`,"x-component":`NumberPicker`,"x-component-props":{defaultValue:500,min:200}},readOnly:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`,"x-component-props":{defaultValue:!1}}}},P=t({Alert:()=>vo,Anchor:()=>Yo,ArrayCards:()=>Za,ArrayTable:()=>Xa,Avatar:()=>Ro,Badge:()=>Eo,Breadcrumb:()=>Fo,Button:()=>eo,CSSStyle:()=>Ea,Calendar:()=>Wo,Card:()=>Aa,Carousel:()=>Uo,Cascader:()=>ja,CheckableTag:()=>_o,Checkbox:()=>Ma,CodeEditor:()=>bo,Collapse:()=>Oo,ColorPicker:()=>Jo,CommonTimePickerAPI:()=>Ba,CommonTooltipAPI:()=>lo,DatePicker:()=>Fa,Descriptions:()=>xo,Div:()=>Qa,Divider:()=>ao,Drawer:()=>co,Dropdown:()=>zo,DynamicSchemaBlock:()=>so,ECharts:()=>Zo,Empty:()=>Bo,FloatButton:()=>no,FloatButtonBackTop:()=>io,FloatButtonGroup:()=>ro,Form:()=>Da,FormCollapse:()=>Ya,FormGrid:()=>Ka,FormItem:()=>Oa,FormLayout:()=>Ta,FormTab:()=>Ja,Iframe:()=>yo,Img:()=>Io,Input:()=>Ca,IteratorLayout:()=>oo,Kanban:()=>es,List:()=>No,Markdown:()=>$o,Mentions:()=>Xo,Menu:()=>jo,Mermaid:()=>Qo,Modal:()=>fo,NumberPicker:()=>Ia,Pagination:()=>Po,Password:()=>La,Popconfirm:()=>po,Popover:()=>mo,Progress:()=>Do,QRCode:()=>$a,Radio:()=>Na,Rate:()=>Ra,Result:()=>Co,Segmented:()=>Ho,Select:()=>ka,Skeleton:()=>Lo,Slider:()=>za,Space:()=>qa,Spin:()=>ho,Splitter:()=>qo,Statistic:()=>wo,Steps:()=>So,Switch:()=>Ga,Table:()=>Ao,Tabs:()=>ko,Tag:()=>go,Text:()=>wa,TimePicker:()=>Va,Timeline:()=>To,Tooltip:()=>uo,Tour:()=>Ko,Transfer:()=>Ua,Tree:()=>Mo,TreeSelect:()=>Ha,Typography:()=>Vo,Upload:()=>Wa,Watermark:()=>Go}),ts=(e,t)=>{let n=e?.[`x-usage-href`],r=n?n.split(`/`).pop().replace(`-cn`,``):``,i=n?{"x-link":{"x-component":u,"x-component-props":{type:`link`,href:n,target:`_blank`,children:`${r} 使用文档`}}}:{};return{"component-group":e?{type:`void`,"x-component":`CollapseItem`,"x-reactions":{fulfill:{state:{visible:`{{!!$form.values["x-component"]}}`}}},properties:{...i,"x-component-props":{...e,properties:{className:{type:`string`,"x-component":`TailwindCSSPicker`},...e.properties}}}}:{},"decorator-group":t?{type:`void`,"x-component":`CollapseItem`,"x-component-props":{defaultExpand:!1},"x-reactions":{fulfill:{state:{visible:`{{!!$form.values["x-decorator"]}}`}}},properties:{"x-decorator-props":t}}:{},"component-style-group":{type:`void`,"x-component":`CollapseItem`,"x-component-props":{defaultExpand:!1},"x-reactions":{fulfill:{state:{visible:`{{!!$form.values["x-component"]}}`}}},properties:{"x-component-props.style":Ea}},"decorator-style-group":{type:`void`,"x-component":`CollapseItem`,"x-component-props":{defaultExpand:!1},"x-reactions":{fulfill:{state:{visible:`{{!!$form.values["x-decorator"]}}`}}},properties:{"x-decorator-props.style":Ea}}}},F=(e,t=Oa)=>({type:`object`,properties:{"field-group":{type:`void`,"x-component":`CollapseItem`,properties:{name:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},description:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`},"x-display":{type:`string`,enum:[`visible`,`hidden`,`none`,``],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`visible`}},"x-pattern":{type:`string`,enum:[`editable`,`disabled`,`readOnly`,`readPretty`,``],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`editable`}},default:{"x-decorator":`FormItem`,"x-component":`ValueInput`},enum:{"x-decorator":`FormItem`,"x-component":Xi},"x-reactions":{"x-decorator":`FormItem`,"x-component":ya},"x-validator":{type:`array`,"x-component":xa},required:{type:`boolean`,"x-decorator":`FormItem`,"x-component":`Switch`}}},...ts(e,t)}}),I=(e,t=Oa)=>({type:`object`,properties:{"field-group":{type:`void`,"x-component":`CollapseItem`,properties:{name:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`},title:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input`,"x-reactions":{fulfill:{state:{hidden:`{{$form.values["x-decorator"] !== "FormItem"}}`}}}},description:{type:`string`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`,"x-reactions":{fulfill:{state:{hidden:`{{$form.values["x-decorator"] !== "FormItem"}}`}}}},"x-display":{type:`string`,enum:[`visible`,`hidden`,`none`,``],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`visible`}},"x-pattern":{type:`string`,enum:[`editable`,`disabled`,`readOnly`,`readPretty`,``],"x-decorator":`FormItem`,"x-component":`Select`,"x-component-props":{defaultValue:`editable`}},"x-reactions":{"x-decorator":`FormItem`,"x-component":ya},"x-decorator":{type:`string`,"x-decorator":`FormItem`,"x-component":Sa}}},...ts(e,t)}}),ns=x(e=>{let t=v(`designable-form`),n=(0,E.useMemo)(()=>On({designable:!0}),[]);return(0,D.jsx)(pt,{...e,style:{...e.style},className:t,form:n,children:e.children})});ns.Behavior=y({name:`Form`,selector:e=>e.componentName===`Form`,designerProps(e){return{draggable:!e.isRoot,cloneable:!e.isRoot,deletable:!e.isRoot,droppable:!0,propsSchema:{type:`object`,properties:{"x-reactions":{"x-component":ya,"x-decorator":`FormItem`},...Ta.properties,style:Ea}},defaultProps:{labelCol:6,wrapperCol:12}}},designerLocales:sr}),ns.Resource=b(`Inputs`,{title:{"zh-CN":`表单`,"en-US":`Form`},icon:`FormLayoutSource`,elements:[{componentName:`Field`,props:{type:`object`,"x-component":`Form`}}]});var rs=ut;rs.Behavior=y({name:`Input`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Input`,designerProps:{propsSchema:F(Ca)},designerLocales:Vn},{name:`Input.TextArea`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Input.TextArea`,designerProps:{propsSchema:F(Ca.TextArea)},designerLocales:Un}),rs.Resource=b(`Inputs`,{icon:`InputSource`,elements:[{componentName:`Field`,props:{type:`string`,title:`Input`,"x-decorator":`FormItem`,"x-component":`Input`}}]},{icon:`TextAreaSource`,elements:[{componentName:`Field`,props:{type:`string`,title:`TextArea`,"x-decorator":`FormItem`,"x-component":`Input.TextArea`}}]});var is=Le;is.Behavior=y({name:`Select`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Select`,designerProps:{propsSchema:F(ka)},designerLocales:Hn}),is.Resource=b(`Inputs`,{icon:`SelectSource`,elements:[{componentName:`Field`,props:{title:`Select`,"x-decorator":`FormItem`,"x-component":`Select`}}]});var as=Ue;as.Behavior=y({name:`TreeSelect`,extends:[`Field`],selector:e=>e.props[`x-component`]===`TreeSelect`,designerProps:{propsSchema:F(Ha)},designerLocales:Wn}),as.Resource=b(`Inputs`,{icon:`TreeSelectSource`,elements:[{componentName:`Field`,props:{title:`TreeSelect`,"x-decorator":`FormItem`,"x-component":`TreeSelect`}}]});var os=vt;os.Behavior=y({name:`Cascader`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Cascader`,designerProps:{propsSchema:F(ja)},designerLocales:Gn}),os.Resource=b(`Inputs`,{icon:`CascaderSource`,elements:[{componentName:`Field`,props:{title:`Cascader`,"x-decorator":`FormItem`,"x-component":`Cascader`}}]});var ss=$e;ss.Behavior=y({name:`Radio.Group`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Radio.Group`,designerProps:{propsSchema:F(Na.Group)},designerLocales:Kn}),ss.Resource=b(`Inputs`,{icon:`RadioGroupSource`,elements:[{componentName:`Field`,props:{type:`string | number`,title:`Radio Group`,"x-decorator":`FormItem`,"x-component":`Radio.Group`,enum:[{label:`选项1`,value:1},{label:`选项2`,value:2}]}}]});var cs=Me;cs.Behavior=y({name:`Checkbox.Group`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Checkbox.Group`,designerProps:{propsSchema:F(Ma.Group)},designerLocales:qn}),cs.Resource=b(`Inputs`,{icon:`CheckboxGroupSource`,elements:[{componentName:`Field`,props:{type:`Array<string | number>`,title:`Checkbox Group`,"x-decorator":`FormItem`,"x-component":`Checkbox.Group`,enum:[{label:`选项1`,value:1},{label:`选项2`,value:2}]}}]});var ls=_n;ls.Behavior=y({name:`Slider`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Slider`,designerProps:{propsSchema:F(za)},designerLocales:Jn}),ls.Resource=b(`Inputs`,{icon:`SliderSource`,elements:[{componentName:`Field`,props:{type:`number`,title:`Slider`,"x-decorator":`FormItem`,"x-component":`Slider`}}]});var us=be;us.Behavior=y({name:`Rate`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Rate`,designerProps:{propsSchema:F(Ra)},designerLocales:Yn}),us.Resource=b(`Inputs`,{icon:`RateSource`,elements:[{componentName:`Field`,props:{type:`number`,title:`Rate`,"x-decorator":`FormItem`,"x-component":`Rate`}}]});var ds=he;ds.Behavior=y({name:`NumberPicker`,extends:[`Field`],selector:e=>e.props[`x-component`]===`NumberPicker`,designerProps:{propsSchema:F(Ia)},designerLocales:er}),ds.Resource=b(`Inputs`,{icon:`NumberPickerSource`,elements:[{componentName:`Field`,props:{type:`number`,title:`NumberPicker`,"x-decorator":`FormItem`,"x-component":`NumberPicker`}}]});var fs=Ye;fs.Behavior=y({name:`Transfer`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Transfer`,designerProps:{propsSchema:F(Ua)},designerLocales:nr}),fs.Resource=b(`Inputs`,{icon:`TransferSource`,elements:[{componentName:`Field`,props:{title:`Transfer`,"x-decorator":`FormItem`,"x-component":`Transfer`}}]});var ps=gn;ps.Behavior=y({name:`Password`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Password`,designerProps:{propsSchema:F(La)},designerLocales:tr}),ps.Resource=b(`Inputs`,{icon:`PasswordSource`,elements:[{componentName:`Field`,props:{title:`Password`,"x-decorator":`FormItem`,"x-component":`Password`}}]});var ms=Zt;ms.Behavior=y({name:`DatePicker`,extends:[`Field`],selector:e=>e.props[`x-component`]===`DatePicker`,designerProps:{propsSchema:F(Fa)},designerLocales:Xn},{name:`DatePicker.RangePicker`,extends:[`Field`],selector:e=>e.props[`x-component`]===`DatePicker.RangePicker`,designerProps:{propsSchema:F(Fa.RangePicker)},designerLocales:Zn}),ms.Resource=b(`Inputs`,{icon:`DatePickerSource`,elements:[{componentName:`Field`,props:{type:`string`,title:`DatePicker`,"x-decorator":`FormItem`,"x-component":`DatePicker`}}]},{icon:`DateRangePickerSource`,elements:[{componentName:`Field`,props:{type:`string[]`,title:`DateRangePicker`,"x-decorator":`FormItem`,"x-component":`DatePicker.RangePicker`}}]});var hs=Ce;hs.Behavior=y({name:`TimePicker`,extends:[`Field`],selector:e=>e.props[`x-component`]===`TimePicker`,designerProps:{propsSchema:F(Va)},designerLocales:Qn},{name:`TimePicker.RangePicker`,extends:[`Field`],selector:e=>e.props[`x-component`]===`TimePicker.RangePicker`,designerProps:{propsSchema:F(Va.RangePicker)},designerLocales:$n}),hs.Resource=b(`Inputs`,{icon:`TimePickerSource`,elements:[{componentName:`Field`,props:{type:`string`,title:`TimePicker`,"x-decorator":`FormItem`,"x-component":`TimePicker`}}]},{icon:`TimeRangePickerSource`,elements:[{componentName:`Field`,props:{type:`string[]`,title:`TimeRangePicker`,"x-decorator":`FormItem`,"x-component":`TimePicker.RangePicker`}}]});var gs=Be;gs.Behavior=y({name:`Upload`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Upload`,designerProps:{propsSchema:F(Wa)},designerLocales:rr},{name:`Upload.Dragger`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Upload.Dragger`,designerProps:{propsSchema:F(Wa.Dragger)},designerLocales:ir}),gs.Resource=b(`Inputs`,{icon:`UploadSource`,elements:[{componentName:`Field`,props:{type:`Array<object>`,title:`Upload`,"x-decorator":`FormItem`,"x-component":`Upload`,"x-component-props":{textContent:`Upload`}}}]},{icon:`UploadDraggerSource`,elements:[{componentName:`Field`,props:{type:`Array<object>`,title:`Drag Upload`,"x-decorator":`FormItem`,"x-component":`Upload.Dragger`,"x-component-props":{textContent:`Click or drag file to this area to upload`}}}]});var _s=ve;_s.Behavior=y({name:`Switch`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Switch`,designerProps:{propsSchema:F(Ga)},designerLocales:ar}),_s.Resource=b(`Inputs`,{icon:`SwitchSource`,elements:[{componentName:`Field`,props:{type:`boolean`,title:`Switch`,"x-decorator":`FormItem`,"x-component":`Switch`}}]});var vs=x(({value:e,mode:t,content:n,...r})=>{let i=t===`normal`||!t?`div`:t;return E.createElement(i,{...r,className:(0,Hi.default)(r.className,`dn-text`),"data-content-editable":`x-component-props.content`,dangerouslySetInnerHTML:{__html:e||n}})});vs.Behavior=y({name:`Text`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Text`,designerProps:{propsSchema:F(wa)},designerLocales:lr}),vs.Resource=b(`Displays`,{icon:`TextSource`,elements:[{componentName:`Field`,props:{type:`string`,"x-component":`Text`}}]});var ys=e=>(0,D.jsx)(Oe,{...e,title:(0,D.jsx)(`span`,{"data-content-editable":`x-component-props.title`,children:e.title}),children:e.children});ys.Behavior=y({name:`Card`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Card`,designerProps:{droppable:!0,propsSchema:I(Aa)},designerLocales:ur}),ys.Resource=b(`Layouts`,{icon:`CardSource`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`Card`,"x-component-props":{title:`Title`}}}]});var bs=Rn(ke);bs.Behavior=y({name:`Space`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Space`,designerProps:{droppable:!0,inlineChildrenLayout:!0,propsSchema:I(qa)},designerLocales:xr}),bs.Resource=b(`Layouts`,{icon:`SpaceSource`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`Space`}}]});var xs=Ln;xs.Behavior=y({name:`Object`,extends:[`Field`],selector:e=>e.props.type===`object`&&!e.props[`x-component`],designerProps:{droppable:!0,propsSchema:F()},designerLocales:or}),xs.Resource=b(`Inputs`,{icon:`ObjectSource`,elements:[{componentName:`Field`,props:{type:`object`}}]});var L=e=>(0,D.jsx)(ft,{children:e.actions?.map((e,t)=>(0,E.createElement)(ft.Action,{...e,key:t}))}),R=(e,t,n)=>{if(t===`*`)return!0;let r=e?.props?.[`x-component`];return typeof t==`function`?t(r||``,e,n):Array.isArray(t)?t.includes(r):r===t},Ss=(e,t,n)=>{if(t===`*`)return!0;let r=e?.props?.[`x-component`];return r?typeof t==`function`?t(r||``,e,n):Array.isArray(t)?t.includes(r):r.indexOf(`${t}.`)>-1:!1},z=(e,t)=>t?.length===0?[]:t?.length===1&&R(e,t[0])?[e]:R(e,t[0])?e.children.reduce((e,n)=>e.concat(z(n,t.slice(1))),[]):[],B=(e,t)=>{if(t?.length!==0){if(t?.length===1&&R(e,t[0]))return e;if(R(e,t[0]))for(let n=0;n<e.children.length;n++){let r=B(e.children[n],t.slice(1));if(r)return r}}},Cs=(e,t)=>!!B(e,t),ws=(e,t)=>({[e.props.nodeIdAttrName]:t}),Ts=e=>t=>{let n=t.children.find(t=>t.props.type===e);if(n)return n;{let n=new S({componentName:`Field`,props:{type:e}});return t.prepend(n),n}};function V(e){if(Array.isArray(e))return e;if(typeof e==`string`)try{return JSON.parse(e)}catch{}return[]}var H=(e,t)=>kt(n=>n.subscribeTo(Mt,n=>{let{source:r,target:i}=n.data;if(!Array.isArray(i)&&Array.isArray(r)&&R(i,t=>t===e&&r.every(t=>!Ss(t,e)))&&i.children.length===0)return i.setChildren(...t(r)),!1})),Es=e=>y({name:e,extends:[`Field`],selector:t=>t.props[`x-component`]===e,designerProps:{droppable:!0,propsSchema:F(P[e])},designerLocales:O[e]},{name:`${e}.Addition`,extends:[`Field`],selector:t=>t.props[`x-component`]===`${e}.Addition`,designerProps:{allowDrop(t){return t.props[`x-component`]===e},propsSchema:I(P[e]?.Addition)},designerLocales:dr},{name:`${e}.Remove`,extends:[`Field`],selector:t=>t.props[`x-component`]===`${e}.Remove`,designerProps:{allowDrop(t){return t.props[`x-component`]===e},propsSchema:I()},designerLocales:fr},{name:`${e}.Index`,extends:[`Field`],selector:t=>t.props[`x-component`]===`${e}.Index`,designerProps:{allowDrop(t){return t.props[`x-component`]===e},propsSchema:I()},designerLocales:hr},{name:`${e}.MoveUp`,extends:[`Field`],selector:t=>t.props[`x-component`]===`${e}.MoveUp`,designerProps:{allowDrop(t){return t.props[`x-component`]===e},propsSchema:I()},designerLocales:pr},{name:`${e}.MoveDown`,extends:[`Field`],selector:t=>t.props[`x-component`]===`${e}.MoveDown`,designerProps:{allowDrop(e){return e.props[`x-component`]===`ArrayCards`},propsSchema:I()},designerLocales:mr}),U=Ts(`object`),Ds=e=>e===`ArrayCards.Remove`||e===`ArrayCards.MoveDown`||e===`ArrayCards.MoveUp`,Os=x(e=>{let t=g(),n=_(),r=H(`ArrayCards`,e=>{let n=new S({componentName:t.componentName,props:{type:`void`,"x-component":`ArrayCards.Index`}}),r=new S({componentName:t.componentName,props:{type:`void`,title:`Addition`,"x-component":`ArrayCards.Addition`}}),i=new S({componentName:t.componentName,props:{type:`void`,title:`Addition`,"x-component":`ArrayCards.Remove`}}),a=new S({componentName:t.componentName,props:{type:`void`,title:`Addition`,"x-component":`ArrayCards.MoveDown`}}),o=new S({componentName:t.componentName,props:{type:`void`,title:`Addition`,"x-component":`ArrayCards.MoveUp`}});return[new S({componentName:t.componentName,props:{type:`object`},children:[n,...e,i,a,o]}),r]}),i=()=>{if(t.children.length===0)return(0,D.jsx)(d,{});let n=z(t,[`ArrayCards`,`ArrayCards.Addition`]),i=z(t,[`ArrayCards`,`*`,`ArrayCards.Index`]),a=z(t,[`ArrayCards`,`*`,Ds]),o=z(t,[`ArrayCards`,`*`,e=>e.indexOf(`ArrayCards.`)===-1]);return(0,D.jsxs)(h,{disabled:!0,children:[(0,D.jsx)(h.Item,{index:0,record:()=>null,children:(0,D.jsx)(Oe,{...e,title:(0,D.jsxs)(E.Fragment,{children:[i.map((e,t)=>(0,D.jsx)(p,{node:e},t)),(0,D.jsx)(`span`,{"data-content-editable":`x-component-props.title`,children:e.title})]}),className:(0,Hi.default)(`ant-formily-array-cards-item`,e.className),extra:(0,D.jsxs)(E.Fragment,{children:[a.map(e=>(0,D.jsx)(p,{node:e},e.id)),e.extra]}),children:(0,D.jsx)(`div`,{...ws(r,U(t).id),children:o.length?o.map(e=>(0,D.jsx)(p,{node:e},e.id)):(0,D.jsx)(d,{hasChildren:!1})})})}),n.map(e=>(0,D.jsx)(p,{node:e},e.id))]})};return(0,D.jsxs)(`div`,{...n,className:`dn-array-cards`,children:[i(),(0,D.jsx)(L,{actions:[{title:t.getMessage(`addIndex`),icon:`AddIndex`,onClick:()=>{if(Cs(t,[`ArrayCards`,`*`,`ArrayCards.Index`]))return;let e=new S({componentName:t.componentName,props:{type:`void`,"x-component":`ArrayCards.Index`}});U(t).append(e)}},{title:t.getMessage(`addOperation`),icon:`AddOperation`,onClick:()=>{if(!B(t,[`ArrayCards`,`ArrayCards.Addition`])){let e=new S({componentName:t.componentName,props:{type:`void`,title:`Addition`,"x-component":`ArrayCards.Addition`}});U(t).insertAfter(e)}let e=B(t,[`ArrayCards`,`*`,`ArrayCards.Remove`]),n=B(t,[`ArrayCards`,`*`,`ArrayCards.MoveDown`]),r=B(t,[`ArrayCards`,`*`,`ArrayCards.MoveUp`]);e||U(t).append(new S({componentName:t.componentName,props:{type:`void`,"x-component":`ArrayCards.Remove`}})),n||U(t).append(new S({componentName:t.componentName,props:{type:`void`,"x-component":`ArrayCards.MoveDown`}})),r||U(t).append(new S({componentName:t.componentName,props:{type:`void`,"x-component":`ArrayCards.MoveUp`}}))}}]})]})});h.mixin(Os),Os.Behavior=Es(`ArrayCards`),Os.Resource=b(`Arrays`,{icon:`ArrayCardsSource`,elements:[{componentName:`Field`,props:{type:`array`,"x-decorator":`FormItem`,"x-component":`ArrayCards`,"x-component-props":{title:`Title`}}}]});var ks=Ts(`object`),As=e=>(0,D.jsx)(`th`,{...e,"data-designer-node-id":e.className.match(/data-id\:([^\s]+)/)?.[1],children:e.children}),js=e=>(0,D.jsx)(`td`,{...e,"data-designer-node-id":e.className.match(/data-id\:([^\s]+)/)?.[1],children:e.children}),Ms=x(e=>{let t=g(),n=_();H(`ArrayTable`,e=>{let t=new S({componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Column`,"x-component-props":{title:`Title`}},children:[{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.SortHandle`}}]}),n=new S({componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Column`,"x-component-props":{title:`Title`}},children:[{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Index`}}]}),r=new S({componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Column`,"x-component-props":{title:`Title`}},children:e.map(e=>(e.props.title=void 0,e))}),i=new S({componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Column`,"x-component-props":{title:`Title`}},children:[{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Remove`}},{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.MoveDown`}},{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.MoveUp`}}]});return[new S({componentName:`Field`,props:{type:`object`},children:[t,n,r,i]}),new S({componentName:`Field`,props:{type:`void`,title:`Addition`,"x-component":`ArrayTable.Addition`}})]});let r=z(t,[`ArrayTable`,`*`,`ArrayTable.Column`]),i=z(t,[`ArrayTable`,`ArrayTable.Addition`]),a=()=>t.id,o=()=>t.children.length===0?(0,D.jsx)(d,{}):(0,D.jsxs)(h,{disabled:!0,children:[(0,D.jsxs)(mn,{size:`small`,bordered:!0,...e,scroll:{x:`100%`},className:(0,Hi.default)(`ant-formily-array-table`,e.className),style:{marginBottom:10,...e.style},rowKey:a,dataSource:[{id:`1`}],pagination:!1,components:{header:{cell:As},body:{cell:js}},children:[r.map(e=>{let t=e.children.map(e=>(0,D.jsx)(p,{node:e},e.id)),n=e.props[`x-component-props`];return(0,E.createElement)(mn.Column,{...n,title:(0,D.jsx)(`div`,{"data-content-editable":`x-component-props.title`,children:n.title}),dataIndex:e.id,className:`data-id:${e.id}`,key:e.id,render:(e,n,r)=>(0,D.jsx)(h.Item,{index:r,record:()=>null,children:t.length>0?t:`Droppable`},r)})}),r.length===0&&(0,D.jsx)(mn.Column,{render:()=>(0,D.jsx)(d,{})})]}),i.map(e=>(0,D.jsx)(p,{node:e},e.id))]});return H(`ArrayTable.Column`,e=>e.map(e=>(e.props.title=void 0,e))),(0,D.jsxs)(`div`,{...n,className:`dn-array-table`,children:[o(),(0,D.jsx)(L,{actions:[{title:t.getMessage(`addSortHandle`),icon:`AddSort`,onClick:()=>{if(Cs(t,[`ArrayTable`,`*`,`ArrayTable.Column`,`ArrayTable.SortHandle`]))return;let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Column`,"x-component-props":{title:`Title`}},children:[{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.SortHandle`}}]});ks(t).prepend(e)}},{title:t.getMessage(`addIndex`),icon:`AddIndex`,onClick:()=>{if(Cs(t,[`ArrayTable`,`*`,`ArrayTable.Column`,`ArrayTable.Index`]))return;let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Column`,"x-component-props":{title:`Title`}},children:[{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Index`}}]}),n=B(t,[`ArrayTable`,`*`,`ArrayTable.Column`,`ArrayTable.SortHandle`]);n?n.parent.insertAfter(e):ks(t).prepend(e)}},{title:t.getMessage(`addColumn`),icon:`AddColumn`,onClick:()=>{let e=B(t,[`ArrayTable`,`*`,`ArrayTable.Column`,e=>e===`ArrayTable.Remove`||e===`ArrayTable.MoveDown`||e===`ArrayTable.MoveUp`]),n=new S({componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Column`,"x-component-props":{title:`Title`}}});e?e.parent.insertBefore(n):ks(t).append(n)}},{title:t.getMessage(`addOperation`),icon:`AddOperation`,onClick:()=>{let e=B(t,[`ArrayTable`,`*`,`ArrayTable.Column`,e=>e===`ArrayTable.Remove`||e===`ArrayTable.MoveDown`||e===`ArrayTable.MoveUp`]),n=B(t,[`ArrayTable`,`ArrayTable.Addition`]);if(!e){let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Column`,"x-component-props":{title:`Title`}},children:[{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.Remove`}},{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.MoveDown`}},{componentName:`Field`,props:{type:`void`,"x-component":`ArrayTable.MoveUp`}}]});ks(t).append(e)}if(!n){let e=new S({componentName:`Field`,props:{type:`void`,title:`Addition`,"x-component":`ArrayTable.Addition`}});ks(t).insertAfter(e)}}}]})]})});h.mixin(Ms),Ms.Behavior=y(Es(`ArrayTable`),{name:`ArrayTable.Column`,extends:[`Field`],selector:e=>e.props[`x-component`]===`ArrayTable.Column`,designerProps:{droppable:!0,allowDrop:e=>e.props.type===`object`&&e.parent?.props?.[`x-component`]===`ArrayTable`,propsSchema:I(Xa.Column)},designerLocales:yr}),Ms.Resource=b(`Arrays`,{icon:`ArrayTableSource`,elements:[{componentName:`Field`,props:{type:`array`,"x-decorator":`FormItem`,"x-component":`ArrayTable`}}]});var Ns=e=>{let t=[];return e.children.forEach(e=>{R(e,`FormTab.TabPane`)&&t.push(e)}),t},Ps=(e,t=[])=>{if(t.length!==0)return t.some(t=>t.id===e)?e:t[t.length-1].id},Fs=x(e=>{let[t,n]=(0,E.useState)(),r=_(),i=g(),a=H(`FormTab`,e=>[new S({componentName:`Field`,props:{type:`void`,"x-component":`FormTab.TabPane`,"x-component-props":{tab:`Unnamed Title`}},children:e})]),o=Ns(i),s=()=>i.children?.length?(0,D.jsx)(ct,{...e,activeKey:Ps(t,o),onChange:e=>{n(e)},children:o.map(e=>{let t=e.props[`x-component-props`]||{};return(0,E.createElement)(ct.TabPane,{...t,style:{...t.style},tab:(0,D.jsx)(`span`,{"data-content-editable":`x-component-props.tab`,"data-content-editable-node-id":e.id,children:t.tab}),key:e.id},E.createElement(`div`,{[a.props.nodeIdAttrName]:e.id,style:{padding:`20px 0`}},e.children.length?(0,D.jsx)(p,{node:e}):(0,D.jsx)(d,{node:e})))})}):(0,D.jsx)(d,{});return(0,D.jsxs)(`div`,{...r,children:[s(),(0,D.jsx)(L,{actions:[{title:i.getMessage(`addTabPane`),icon:`AddPanel`,onClick:()=>{let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`FormTab.TabPane`,"x-component-props":{tab:`Unnamed Title`}}});i.append(e),n(e.id)}}]})]})});Fs.TabPane=e=>(0,D.jsx)(E.Fragment,{children:e.children}),Fs.Behavior=y({name:`FormTab`,extends:[`Field`],selector:e=>e.props[`x-component`]===`FormTab`,designerProps:{droppable:!0,allowAppend:(e,t)=>e.children.length===0||t?.every(e=>e.props[`x-component`]===`FormTab.TabPane`)||!1,propsSchema:I(Ja)},designerLocales:Sr},{name:`FormTab.TabPane`,extends:[`Field`],selector:e=>e.props[`x-component`]===`FormTab.TabPane`,designerProps:{droppable:!0,allowDrop:e=>e.props[`x-component`]===`FormTab`,propsSchema:I(Ja.TabPane)},designerLocales:Cr}),Fs.Resource=b(`Layouts`,{icon:`TabSource`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`FormTab`}}]});var Is=e=>{let t=[];return e.children.forEach(e=>{R(e,`FormCollapse.CollapsePanel`)&&t.push(e)}),t},Ls=x(e=>{let[t,n]=(0,E.useState)([]),r=g(),i=_(),a=H(`FormCollapse`,e=>{let r=new S({componentName:`Field`,props:{type:`void`,"x-component":`FormCollapse.CollapsePanel`,"x-component-props":{header:`Unnamed Title`}},children:e});return n(T(t).concat(r.id)),[r]}),o=Is(r),s=()=>r.children?.length?(0,D.jsx)(l,{...e,activeKey:o.map(e=>e.id),children:o.map(e=>{let t=e.props[`x-component-props`]||{};return(0,E.createElement)(l.Panel,{...t,style:{...t.style},header:(0,D.jsx)(`span`,{"data-content-editable":`x-component-props.header`,"data-content-editable-node-id":e.id,children:t.header}),key:e.id},E.createElement(`div`,{[a.props.nodeIdAttrName]:e.id,style:{padding:`20px 0`}},e.children.length?(0,D.jsx)(p,{node:e}):(0,D.jsx)(d,{})))})}):(0,D.jsx)(d,{});return(0,D.jsxs)(`div`,{...i,children:[s(),(0,D.jsx)(L,{actions:[{title:r.getMessage(`addCollapsePanel`),icon:`AddPanel`,onClick:()=>{let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`FormCollapse.CollapsePanel`,"x-component-props":{header:`Unnamed Title`}}});r.append(e);let i=T(t);n(i.concat(e.id))}}]})]})});Ls.CollapsePanel=e=>(0,D.jsx)(E.Fragment,{children:e.children}),Ls.Behavior=y({name:`FormCollapse`,extends:[`Field`],selector:e=>e.props[`x-component`]===`FormCollapse`,designerProps:{droppable:!0,allowAppend:(e,t)=>e.children.length===0||!!t?.every(e=>e.props[`x-component`]===`FormCollapse.CollapsePanel`),propsSchema:I(Ya)},designerLocales:wr},{name:`FormCollapse.CollapsePanel`,extends:[`Field`],selector:e=>e.props[`x-component`]===`FormCollapse.CollapsePanel`,designerProps:{droppable:!0,allowDrop:e=>e.props[`x-component`]===`FormCollapse`,propsSchema:I(Ya.CollapsePanel)},designerLocales:Tr}),Ls.Resource=b(`Layouts`,{icon:`CollapseSource`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`FormCollapse`}}]});var Rs=x(e=>{let t=g(),n=_();return t.children.length===0?(0,D.jsx)(d,{...e}):(0,D.jsxs)(`div`,{...n,className:`dn-grid`,children:[(0,D.jsx)(De,{...e,children:e.children}),(0,D.jsx)(L,{actions:[{title:t.getMessage(`addGridColumn`),icon:`AddColumn`,onClick:()=>{let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`FormGrid.GridColumn`}});t.append(e)}}]})]})});Rs.GridColumn=x(({gridSpan:e,...t})=>(0,D.jsx)(d,{...t,"data-grid-span":e,children:t.children})),Rs.Behavior=y({name:`FormGrid`,extends:[`Field`],selector:e=>e.props[`x-component`]===`FormGrid`,designerProps:{droppable:!0,allowDrop:e=>e.props[`x-component`]!==`FormGrid`,propsSchema:F(Ka)},designerLocales:Er},{name:`FormGrid.GridColumn`,extends:[`Field`],selector:e=>e.props[`x-component`]===`FormGrid.GridColumn`,designerProps:{droppable:!0,allowDrop:e=>e.props[`x-component`]===`FormGrid`,propsSchema:F(Ka.GridColumn)},designerLocales:Dr}),Rs.Resource=b(`Layouts`,{icon:`GridSource`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`FormGrid`},children:[{componentName:`Field`,props:{type:`void`,"x-component":`FormGrid.GridColumn`}},{componentName:`Field`,props:{type:`void`,"x-component":`FormGrid.GridColumn`}},{componentName:`Field`,props:{type:`void`,"x-component":`FormGrid.GridColumn`}}]}]});var zs=Rn(Fe);zs.Behavior=y({name:`FormLayout`,extends:[`Field`],selector:e=>e.props[`x-component`]===`FormLayout`,designerProps:{droppable:!0,propsSchema:I(Ta)},designerLocales:cr}),zs.Resource=b(`Layouts`,{icon:`FormLayoutSource`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`FormLayout`}}]});var Bs=x(e=>(0,D.jsx)(d,{children:(0,D.jsx)(`div`,{...e})})),W=`Div`;Bs.Behavior=y({name:W,extends:[`Field`],selector:e=>e.props[`x-component`]===W,designerProps:{droppable:!0,propsSchema:I(P[W])},designerLocales:O[W]}),Bs.Resource=b(`Layouts`,{icon:W,elements:[{componentName:`Field`,props:{type:`void`,"x-component":W}}]});var Vs=x(({value:e,content:t,...n})=>(0,D.jsx)(qe,{value:e||t,...n})),G=`QRCode`;Vs.Behavior=y({name:G,extends:[`Field`],selector:e=>e.props[`x-component`]===G,designerProps:{propsSchema:F(P[G])},designerLocales:O[G]}),Vs.Resource=b(`Displays`,{icon:G,elements:[{componentName:`Field`,props:{type:`string`,"x-component":G}}]});var Hs=x(({icon:e,value:t,children:n,href:r,...i})=>{let a=f({icon:e}),o=t||n;return!a&&!o&&(o=`按钮`),(0,D.jsx)(u,{...i,icon:a,children:o})}),K=`Button`;Hs.Behavior=y({name:K,extends:[`Field`],selector:e=>e.props[`x-component`]===K,designerProps:{propsSchema:F(P[K])},designerLocales:O[K]}),Hs.Resource=b(`Buttons`,{icon:K,elements:[{componentName:`Field`,props:{type:`string`,"x-component":K,"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})
`}}}}]});var Us=305,Ws=({style:e,insetInlineEnd:t,insetBlockEnd:n})=>{let r=t===void 0?e?.insetInlineEnd?+e?.insetInlineEnd:0:t||0,i=n===void 0?e?.insetBlockEnd?+e?.insetInlineEnd:void 0:n||0;return{...e,insetInlineEnd:Us+r,insetBlockEnd:i}},Gs=x(({icon:e,style:t,href:n,...r})=>(0,D.jsx)(Xe.Group,{...r,icon:f({icon:e}),style:Ws(r)})),Ks=x(({icon:e,style:t,href:n,...r})=>{let i=()=>document.querySelector(`.dn-pc-simulator`)?.firstChild||window;return(0,D.jsx)(Xe.BackTop,{...r,icon:f({icon:e}),style:Ws(r),target:i})}),qs=x(({icon:e,value:t,description:n,style:r,href:i,...a})=>(0,D.jsx)(Xe,{...a,icon:f({icon:e}),description:t||n,style:Ws(a)})),q=`FloatButton`;qs.Behavior=y({name:q,extends:[`Field`],selector:e=>e.props[`x-component`]===q,designerProps:{propsSchema:I(P[q])},designerLocales:O[q]}),qs.Resource=b(`Buttons`,{icon:q,elements:[{componentName:`Field`,props:{type:`string`,"x-component":q,"x-component-props":{description:`按钮`,type:`primary`,insetInlineEnd:24,insetBlockEnd:48},"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})
`}}}}]});var J=`${q}Group`;Gs.Behavior=y({name:J,extends:[`Field`],selector:e=>e.props[`x-component`]===J,designerProps:{droppable:!0,allowAppend:(e,t)=>!!t?.every(e=>e.props[`x-component`]===q),propsSchema:I(P[J])},designerLocales:O[J]}),Gs.Resource=b(`Buttons`,{icon:J,elements:[{componentName:`Field`,props:{type:`void`,"x-component":J,"x-component-props":{icon:`MoreOutlined`,type:`primary`,trigger:`hover`,insetInlineEnd:24,insetBlockEnd:48}},children:[{componentName:`Field`,props:{"x-component":q,"x-component-props":{description:`按钮1`,type:`primary`},"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})
`}}}},{componentName:`Field`,props:{"x-component":q,"x-component-props":{description:`按钮2`,type:`primary`,insetInlineEnd:24,insetBlockEnd:48},"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    $message.info("TODO 处理点击事件")
  },
})
`}}}}]}]});var Y=`${q}BackTop`;Ks.Behavior=y({name:Y,extends:[`Field`],selector:e=>e.props[`x-component`]===Y,designerProps:{propsSchema:I(P[Y])},designerLocales:O[Y]}),Ks.Resource=b(`Buttons`,{icon:Y,elements:[{componentName:`Field`,props:{type:`void`,"x-component":Y,"x-component-props":{type:`primary`}}}]});var Js=x(({value:e,children:t,...n})=>(0,D.jsx)(dt,{...n,children:e||t})),X=`Divider`;Js.Behavior=y({name:X,extends:[`Field`],selector:e=>e.props[`x-component`]===X,designerProps:{propsSchema:F(P[X])},designerLocales:O[X]}),Js.Resource=b(`Displays`,{icon:X,elements:[{componentName:`Field`,props:{type:`string`,"x-component":X}}]});var Ys=x(({style:e,className:t})=>{let n=_(),r=g();return(0,D.jsx)(`div`,{...n,style:e,className:t,children:r.children.length===0?(0,D.jsx)(d,{}):(0,D.jsx)(p,{node:r.children[0]})})}),Xs=`IteratorLayout`;Ys.Behavior=y({name:Xs,extends:[`Field`],selector:e=>e.props[`x-component`]===Xs,designerProps:{inlineChildrenLayout:!0,droppable:!0,allowAppend:(e,t)=>e.children.length===0,propsSchema:F(P[Xs])},designerLocales:O[Xs]}),Ys.Resource=b(`Arrays`,{icon:Xs,elements:[{componentName:`Field`,props:{type:`array`,"x-component":Xs,"x-component-props":{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fill, 120px)`,justifyContent:`space-between`,gap:`10px`}},default:[{title:`React`,url:`https://zh-hans.react.dev/learn`},{title:`ReactRouter`,url:`https://reactrouter.com/en/main/start/tutorial`},{title:`Zustand`,url:`https://docs.pmnd.rs/zustand/getting-started/introduction`},{title:`Redux`,url:`https://redux.js.org/introduction/getting-started`},{title:`Redux-Toolkit`,url:`https://redux-toolkit.js.org/introduction/getting-started`},{title:`Next.js`,url:`https://www.nextjs.cn`},{title:`Vue`,url:`https://cn.vuejs.org/v2/guide/index.html`},{title:`VueRouter`,url:`https://router.vuejs.org/zh/guide`},{title:`Vuex`,url:`https://vuex.vuejs.org/zh/guide`},{title:`Pinia`,url:`https://pinia.vuejs.org/zh/introduction.html`},{title:`Nuxt`,url:`https://nuxt.com/docs/getting-started/installation`},{title:`Electron`,url:`https://www.electronjs.org/zh/docs/latest/tutorial/quick-start`},{title:`Tauri`,url:`https://tauri.app/zh-cn/v1/guides/`}]},children:[{componentName:`Field`,props:{type:`object`},children:[{componentName:`Field`,props:{type:`void`,"x-component":`Div`,"x-component-props":{style:{cursor:`pointer`,display:`flex`,flexDirection:`column`,alignItems:`center`,padding:`8px 0px 8px 0px`}},"x-reactions":{fulfill:{run:`$props({
  onClick: () => {
    // 处理点击指定的循环类组件的条目链接，默认就是取的条目的 url 字段来打开
    $utils.clickArrayFieldUrlItem($self)
  },
})
`}}},children:[{componentName:`Field`,props:{type:`string`,"x-component":`Img`,"x-component-props":{style:{width:`40px`,height:`40px`},objectFit:`contain`},name:`icon`,"x-reactions":{fulfill:{run:`$effect(() => {
  // 获取迭代器布局中当前点击的条目数据
  const row = $utils.getArrayFieldRow($self)
  // 获取书签的图标地址
  $utils.getBookmarkIconUrl(row.url, row.icon).then((iconUrl) => {
    $props({
      src: iconUrl,
    })
  })
}, [])
`}}}},{componentName:`Field`,props:{type:`string`,"x-component":`Text`,name:`title`}}]}]}]}]});var Zs=x(e=>(0,D.jsx)(d,{children:(0,D.jsx)(`div`,{...e})})),Qs=`DynamicSchemaBlock`;Zs.Behavior=y({name:Qs,extends:[`Field`],selector:e=>e.props[`x-component`]===Qs,designerProps:{propsSchema:I(P[Qs])},designerLocales:O[Qs]}),Zs.Resource=b(`Layouts`,{icon:Qs,elements:[{componentName:`Field`,props:{type:`void`,"x-component":Qs}}]});var $s=x(e=>{let[t,n]=(0,E.useState)(e.open),r=_(),i=g(),a=(0,E.useCallback)(()=>{n(!1)},[]);return(0,D.jsxs)(D.Fragment,{children:[!t&&(0,D.jsx)(`div`,{...r,children:(0,D.jsx)(L,{actions:[{title:`打开抽屉 ${i.props.title||i.props.name||``}`,icon:`AddOperation`,onClick:()=>{n(!0)}}]})}),t&&(0,D.jsx)(Ae,{...e,rootStyle:{position:`absolute`},getContainer:()=>document.querySelector(`.dn-component-tree`),closeIcon:f({icon:e.closeIcon}),open:t,onClose:a,children:(0,D.jsx)(`div`,{...t?r:{},children:i.children.length?e.children:(0,D.jsx)(d,{})})})]})}),ec=`Drawer`;$s.Behavior=y({name:ec,extends:[`Field`],selector:e=>e.props[`x-component`]===ec,designerProps:{droppable:!0,propsSchema:I(P[ec])},designerLocales:O[ec]}),$s.Resource=b(`Layouts`,{icon:ec,elements:[{componentName:`Field`,props:{type:`object`,"x-component":ec,"x-reactions":{fulfill:{run:`$props({
  // 点击遮罩层或左上角叉或取消按钮的回调
  onClose: () => {
    $self.componentProps.open = false
  },
})
`}}}}]});var tc=x(({title:e,...t})=>(0,D.jsx)(d,{children:(0,D.jsx)(se,{...t,title:e||`Tooltip`})})),nc=`Tooltip`;tc.Behavior=y({name:nc,extends:[`Field`],selector:e=>e.props[`x-component`]===nc,designerProps:{droppable:!0,propsSchema:F(P[nc])},designerLocales:O[nc]}),tc.Resource=b(`Layouts`,{icon:nc,elements:[{componentName:`Field`,props:{type:`void`,"x-component":nc}}]});var rc=x(e=>{let[t,n]=(0,E.useState)(e.open),r=_(),i=g(),a=(0,E.useCallback)(()=>{n(!1)},[]);return(0,D.jsxs)(D.Fragment,{children:[!t&&(0,D.jsx)(`div`,{...r,children:(0,D.jsx)(L,{actions:[{title:`打开对话框 ${i.props.title||i.props.name||``}`,icon:`AddOperation`,onClick:()=>{n(!0)}}]})}),t&&(0,D.jsx)(Rt,{...e,getContainer:()=>document.querySelector(`.dn-component-tree`),styles:{mask:{position:`absolute`},wrapper:{position:`absolute`}},closeIcon:f({icon:e.closeIcon}),open:t,onCancel:a,onOk:a,children:(0,D.jsx)(`div`,{...t?r:{},children:i.children.length?e.children:(0,D.jsx)(d,{})})})]})}),ic=`Modal`;rc.Behavior=y({name:ic,extends:[`Field`],selector:e=>e.props[`x-component`]===ic,designerProps:{droppable:!0,propsSchema:I(P[ic])},designerLocales:O[ic]}),rc.Resource=b(`Layouts`,{icon:ic,elements:[{componentName:`Field`,props:{type:`object`,"x-component":ic,"x-reactions":{fulfill:{run:`$props({
  // 点击取消按钮
  onCancel: () => {
    $self.componentProps.open = false
  },
  // 点击确认按钮
  onOk: () => {
    $self.componentProps.open = false
  },
})
`}}}}]});var ac=x(({icon:e,...t})=>(0,D.jsx)(d,{children:(0,D.jsx)(pe,{...t,icon:f({icon:e})})})),oc=`Popconfirm`;ac.Behavior=y({name:oc,extends:[`Field`],selector:e=>e.props[`x-component`]===oc,designerProps:{droppable:!0,propsSchema:I(P[oc])},designerLocales:O[oc]}),ac.Resource=b(`Layouts`,{icon:oc,elements:[{componentName:`Field`,props:{type:`void`,"x-component":oc,"x-reactions":{fulfill:{run:`$props({
  // 点击取消按钮
  onCancel: () => {
    $message.info('点击了取消')
  },
  // 点击确认按钮
  onConfirm: () => {
    $message.info('点击了确认')
  },
})`}}}}]});var sc=Rn(_t),cc=`Popover`;sc.Behavior=y({name:cc,extends:[`Field`],selector:e=>e.props[`x-component`]===cc,designerProps:{droppable:!0,propsSchema:I(P[cc])},designerLocales:O[cc]}),sc.Resource=b(`Layouts`,{icon:cc,elements:[{componentName:`Field`,props:{type:`void`,"x-component":cc}}]});var lc=x(({value:e,indicator:t,spinning:n,...r})=>(0,D.jsx)(d,{children:(0,D.jsx)(c,{...r,spinning:e||n,indicator:f({icon:t,spin:!0})})})),uc=`Spin`;lc.Behavior=y({name:uc,extends:[`Field`],selector:e=>e.props[`x-component`]===uc,designerProps:{droppable:!0,propsSchema:F(P[uc])},designerLocales:O[uc]}),lc.Resource=b(`Layouts`,{icon:uc,elements:[{componentName:`Field`,props:{type:`void`,"x-component":uc}}]});var dc=x(({value:e,children:t,icon:n,closeIcon:r,...i})=>(0,D.jsx)(Dt,{...i,icon:f({icon:n}),closeIcon:f({icon:r}),children:e||t||`Tag`})),fc=x(({value:e,children:t,onChange:n,onCheckedChange:r,...i})=>(0,D.jsx)(Dt.CheckableTag,{...i,onChange:r,children:e||t||`CheckableTag`})),Z=`Tag`;dc.Behavior=y({name:Z,extends:[`Field`],selector:e=>e.props[`x-component`]===Z,designerProps:{propsSchema:F(P[Z])},designerLocales:O[Z]}),dc.Resource=b(`Displays`,{icon:Z,elements:[{componentName:`Field`,props:{type:`string`,"x-component":Z}}]});var pc=`Checkable${Z}`;fc.Behavior=y({name:pc,extends:[`Field`],selector:e=>e.props[`x-component`]===pc,designerProps:{propsSchema:F(P[pc])},designerLocales:O[pc]}),fc.Resource=b(`Displays`,{icon:pc,elements:[{componentName:`Field`,props:{type:`string`,"x-component":pc,"x-reactions":{fulfill:{run:`$props({
  onCheckedChange: (checked) => {
    $self.componentProps.checked = checked
  },
})
`}}}}]});var mc=x(({value:e,message:t,...n})=>(0,D.jsx)(At,{...n,message:e||t})),hc=`Alert`;mc.Behavior=y({name:hc,extends:[`Field`],selector:e=>e.props[`x-component`]===hc,designerProps:{propsSchema:F(P[hc])},designerLocales:O[hc]}),mc.Resource=b(`Displays`,{icon:hc,elements:[{componentName:`Field`,props:{type:`string`,"x-component":hc}}]});var gc=x(({value:e,src:t,...n})=>(0,D.jsx)(`iframe`,{...n,src:e||t})),_c=`Iframe`;gc.Behavior=y({name:_c,extends:[`Field`],selector:e=>e.props[`x-component`]===_c,designerProps:{propsSchema:F(P[_c])},designerLocales:O[_c]}),gc.Resource=b(`Displays`,{icon:_c,elements:[{componentName:`Field`,props:{type:`string`,"x-component":_c,"x-component-props":{style:{width:`100%`,height:`100%`,borderStyle:`none`}},default:`https://www.baidu.com`}}]});var vc=x(e=>(0,D.jsx)(it,{...e})),yc=`CodeEditor`;vc.Behavior=y({name:yc,extends:[`Field`],selector:e=>e.props[`x-component`]===yc,designerProps:{propsSchema:F(P[yc])},designerLocales:O[yc]}),vc.Resource=b(`Inputs`,{icon:`CodeEditor`,elements:[{componentName:`Field`,props:{type:`string`,title:`代码编辑器`,"x-decorator":`FormItem`,"x-component":yc,"x-decorator-props":{style:{width:`inherit`}},"x-component-props":{language:`javascript`,height:300}}}]});var bc=x(({value:e,items:t,...n})=>(0,D.jsx)(Re,{...n,items:V(e??t)})),xc=`Descriptions`;bc.Behavior=y({name:xc,extends:[`Field`],selector:e=>e.props[`x-component`]===xc,designerProps:{propsSchema:F(P[xc])},designerLocales:O[xc]}),bc.Resource=b(`Displays`,{icon:xc,elements:[{componentName:`Field`,props:{type:`object`,"x-component":xc}}]});var Sc=x(({value:e,current:t,items:n,...r})=>(0,D.jsx)(dn,{...r,current:typeof e==`number`?e:t,items:n||[]})),Cc=`Steps`;Sc.Behavior=y({name:Cc,extends:[`Field`],selector:e=>e.props[`x-component`]===Cc,designerProps:{propsSchema:F(P[Cc])},designerLocales:O[Cc]}),Sc.Resource=b(`Displays`,{icon:Cc,elements:[{componentName:`Field`,props:{type:`number`,"x-component":Cc}}]});var wc=x(({children:e,extra:t,...n})=>{let r=_(),i=g(),a=(0,D.jsx)(`div`,{...r,style:{display:`flex`,gap:8,justifyContent:`center`,flexWrap:`wrap`,minWidth:80},children:i.children.length?e:(0,D.jsx)(d,{})});return(0,D.jsx)(Se,{...n,extra:a})}),Tc=`Result`;wc.Behavior=y({name:Tc,extends:[`Field`],selector:e=>e.props[`x-component`]===Tc,designerProps:{droppable:!0,propsSchema:I(P[Tc])},designerLocales:O[Tc]}),wc.Resource=b(`Displays`,{icon:Tc,elements:[{componentName:`Field`,props:{type:`void`,"x-component":Tc,"x-component-props":{status:`success`,title:`操作成功`,subTitle:``}}}]});var Ec=x(e=>(0,D.jsx)(un,{...e})),Dc=`Statistic`;Ec.Behavior=y({name:Dc,extends:[`Field`],selector:e=>e.props[`x-component`]===Dc,designerProps:{propsSchema:F(P[Dc])},designerLocales:O[Dc]}),Ec.Resource=b(`Displays`,{icon:Dc,elements:[{componentName:`Field`,props:{type:`number`,"x-component":Dc}}]});var Oc=x(({value:e,items:t,...n})=>(0,D.jsx)(hn,{...n,items:V(e??t)})),kc=`Timeline`;Oc.Behavior=y({name:kc,extends:[`Field`],selector:e=>e.props[`x-component`]===kc,designerProps:{propsSchema:F(P[kc])},designerLocales:O[kc]}),Oc.Resource=b(`Displays`,{icon:kc,elements:[{componentName:`Field`,props:{type:`object`,"x-component":kc}}]});var Ac=x(({children:e,...t})=>{let n=_(),r=g();return(0,D.jsx)(Ne,{...t,children:(0,D.jsx)(`div`,{...n,style:{display:`inline-block`,minWidth:40,minHeight:24},children:r.children.length?e:(0,D.jsx)(d,{})})})}),jc=`Badge`;Ac.Behavior=y({name:jc,extends:[`Field`],selector:e=>e.props[`x-component`]===jc,designerProps:{droppable:!0,propsSchema:I(P[jc])},designerLocales:O[jc]}),Ac.Resource=b(`Displays`,{icon:jc,elements:[{componentName:`Field`,props:{type:`void`,"x-component":jc,"x-component-props":{count:5}}}]});var Mc=x(({value:e,percent:t,...n})=>(0,D.jsx)(Vt,{...n,percent:typeof e==`number`?e:t})),Nc=`Progress`;Mc.Behavior=y({name:Nc,extends:[`Field`],selector:e=>e.props[`x-component`]===Nc,designerProps:{propsSchema:F(P[Nc])},designerLocales:O[Nc]}),Mc.Resource=b(`Displays`,{icon:Nc,elements:[{componentName:`Field`,props:{type:`number`,"x-component":Nc}}]});var Pc=e=>{let t=[];return e.children.forEach(e=>{R(e,`Collapse.Panel`)&&t.push(e)}),t},Fc=x(e=>{let[t,n]=(0,E.useState)([]),r=g(),i=_(),a=H(`Collapse`,e=>{let r=new S({componentName:`Field`,props:{type:`void`,"x-component":`Collapse.Panel`,"x-component-props":{header:`未命名面板`}},children:e});return n(T(t).concat(r.id)),[r]}),o=Pc(r),s=()=>r.children?.length?(0,D.jsx)(l,{...e,activeKey:o.map(e=>e.id),items:o.map(e=>{let t=e.props[`x-component-props`]||{};return{key:e.id,label:(0,D.jsx)(`span`,{"data-content-editable":`x-component-props.header`,"data-content-editable-node-id":e.id,children:t.header}),extra:t.extra,children:E.createElement(`div`,{[a.props.nodeIdAttrName]:e.id,style:{padding:`20px 0`}},e.children.length?(0,D.jsx)(p,{node:e}):(0,D.jsx)(d,{}))}})}):(0,D.jsx)(d,{});return(0,D.jsxs)(`div`,{...i,children:[s(),(0,D.jsx)(L,{actions:[{title:r.getMessage(`addPanel`),icon:`AddPanel`,onClick:()=>{let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`Collapse.Panel`,"x-component-props":{header:`未命名面板`}}});r.append(e);let i=T(t);n(i.concat(e.id))}}]})]})});Fc.Panel=e=>(0,D.jsx)(E.Fragment,{children:e.children}),Fc.Behavior=y({name:`Collapse`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Collapse`,designerProps:{droppable:!0,allowAppend:(e,t)=>e.children.length===0||!!t?.every(e=>e.props[`x-component`]===`Collapse.Panel`),propsSchema:I(Oo)},designerLocales:ni},{name:`Collapse.Panel`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Collapse.Panel`,designerProps:{droppable:!0,allowDrop:e=>e.props[`x-component`]===`Collapse`,propsSchema:I(Oo.Panel)},designerLocales:ri}),Fc.Resource=b(`Layouts`,{icon:`Collapse`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`Collapse`}}]});var Ic=e=>{let t=[];return e.children.forEach(e=>{R(e,`Tabs.TabPane`)&&t.push(e)}),t},Lc=(e,t=[])=>{if(t.length!==0)return t.some(t=>t.id===e)?e:t[t.length-1].id},Rc=x(e=>{let[t,n]=(0,E.useState)(),r=_(),i=g(),a=H(`Tabs`,e=>[new S({componentName:`Field`,props:{type:`void`,"x-component":`Tabs.TabPane`,"x-component-props":{tab:`未命名页签`}},children:e})]),o=Ic(i),s=()=>i.children?.length?(0,D.jsx)(ct,{...e,activeKey:Lc(t,o),onChange:e=>{n(e)},items:o.map(e=>{let t=e.props[`x-component-props`]||{};return{key:e.id,label:(0,D.jsx)(`span`,{"data-content-editable":`x-component-props.tab`,"data-content-editable-node-id":e.id,children:t.tab}),children:E.createElement(`div`,{[a.props.nodeIdAttrName]:e.id,style:{padding:`20px 0`}},e.children.length?(0,D.jsx)(p,{node:e}):(0,D.jsx)(d,{node:e}))}})}):(0,D.jsx)(d,{});return(0,D.jsxs)(`div`,{...r,children:[s(),(0,D.jsx)(L,{actions:[{title:i.getMessage(`addTabPane`),icon:`AddPanel`,onClick:()=>{let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`Tabs.TabPane`,"x-component-props":{tab:`未命名页签`}}});i.append(e),n(e.id)}}]})]})});Rc.TabPane=e=>(0,D.jsx)(E.Fragment,{children:e.children}),Rc.Behavior=y({name:`Tabs`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Tabs`,designerProps:{droppable:!0,allowAppend:(e,t)=>e.children.length===0||t?.every(e=>e.props[`x-component`]===`Tabs.TabPane`)||!1,propsSchema:I(ko)},designerLocales:ii},{name:`Tabs.TabPane`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Tabs.TabPane`,designerProps:{droppable:!0,allowDrop:e=>e.props[`x-component`]===`Tabs`,propsSchema:I(ko.TabPane)},designerLocales:ai}),Rc.Resource=b(`Layouts`,{icon:`Tabs`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`Tabs`}}]});var zc=x(({value:e,dataSource:t,columns:n,rowKey:r,...i})=>(0,D.jsx)(mn,{...i,columns:V(n),dataSource:V(e??t),rowKey:r||((e,t)=>e?.id??e?.key??String(t))})),Bc=`Table`;zc.Behavior=y({name:Bc,extends:[`Field`],selector:e=>e.props[`x-component`]===Bc,designerProps:{propsSchema:F(P[Bc])},designerLocales:O[Bc]}),zc.Resource=b(`Layouts`,{icon:Bc,elements:[{componentName:`Field`,props:{type:`array`,"x-component":Bc}}]});var Vc=x(({value:e,items:t,...n})=>(0,D.jsx)(ce,{...n,items:V(e??t)})),Hc=`Menu`;Vc.Behavior=y({name:Hc,extends:[`Field`],selector:e=>e.props[`x-component`]===Hc,designerProps:{propsSchema:F(P[Hc])},designerLocales:O[Hc]}),Vc.Resource=b(`Displays`,{icon:Hc,elements:[{componentName:`Field`,props:{type:`object`,"x-component":Hc}}]});var Uc=x(({value:e,treeData:t,...n})=>(0,D.jsx)(rt,{...n,treeData:V(e??t)})),Wc=`Tree`;Uc.Behavior=y({name:Wc,extends:[`Field`],selector:e=>e.props[`x-component`]===Wc,designerProps:{propsSchema:F(P[Wc])},designerLocales:O[Wc]}),Uc.Resource=b(`Displays`,{icon:Wc,elements:[{componentName:`Field`,props:{type:`object`,"x-component":Wc}}]});var Gc=x(({value:e,dataSource:t,...n})=>(0,D.jsx)(We,{...n,dataSource:V(e??t)})),Kc=`List`;Gc.Behavior=y({name:Kc,extends:[`Field`],selector:e=>e.props[`x-component`]===Kc,designerProps:{propsSchema:F(P[Kc])},designerLocales:O[Kc]}),Gc.Resource=b(`Displays`,{icon:Kc,elements:[{componentName:`Field`,props:{type:`array`,"x-component":Kc}}]});var qc=x(e=>(0,D.jsx)(_e,{...e})),Jc=`Pagination`;qc.Behavior=y({name:Jc,extends:[`Field`],selector:e=>e.props[`x-component`]===Jc,designerProps:{propsSchema:F(P[Jc])},designerLocales:O[Jc]}),qc.Resource=b(`Displays`,{icon:Jc,elements:[{componentName:`Field`,props:{type:`number`,"x-component":Jc}}]});var Yc=x(({value:e,items:t,...n})=>(0,D.jsx)(Qt,{...n,items:V(e??t)})),Xc=`Breadcrumb`;Yc.Behavior=y({name:Xc,extends:[`Field`],selector:e=>e.props[`x-component`]===Xc,designerProps:{propsSchema:F(P[Xc])},designerLocales:O[Xc]}),Yc.Resource=b(`Displays`,{icon:Xc,elements:[{componentName:`Field`,props:{type:`object`,"x-component":Xc}}]});var Zc=x(e=>(0,D.jsx)(nt,{...e})),Qc=`Img`;Zc.Behavior=y({name:Qc,extends:[`Field`],selector:e=>e.props[`x-component`]===Qc,designerProps:{propsSchema:F(P[Qc])},designerLocales:O[Qc]}),Zc.Resource=b(`Displays`,{icon:Qc,elements:[{componentName:`Field`,props:{type:`string`,"x-component":Qc}}]});var $c=x(({children:e,loading:t=!0,...n})=>{let i=_(),a=g();return(0,D.jsx)(r,{...n,loading:t,children:(0,D.jsx)(`div`,{...i,style:{minHeight:40},children:a.children.length?e:(0,D.jsx)(d,{})})})}),el=`Skeleton`;$c.Behavior=y({name:el,extends:[`Field`],selector:e=>e.props[`x-component`]===el,designerProps:{droppable:!0,propsSchema:I(P[el])},designerLocales:O[el]}),$c.Resource=b(`Displays`,{icon:el,elements:[{componentName:`Field`,props:{type:`void`,"x-component":el,"x-component-props":{loading:!0}}}]});var tl=x(({value:e,src:t,children:n,...r})=>(0,D.jsx)(yt,{...r,src:e||t,children:!e&&!t?n||`A`:void 0})),nl=`Avatar`;tl.Behavior=y({name:nl,extends:[`Field`],selector:e=>e.props[`x-component`]===nl,designerProps:{propsSchema:F(P[nl])},designerLocales:O[nl]}),tl.Resource=b(`Displays`,{icon:nl,elements:[{componentName:`Field`,props:{type:`string`,"x-component":nl}}]});var rl=x(({value:e,label:t,menu:n,...r})=>{let i={...n,items:V(e??n?.items)};return(0,D.jsx)(we,{...r,menu:i,children:(0,D.jsxs)(u,{children:[t||`下拉菜单`,` `,(0,D.jsx)(tn,{})]})})}),il=`Dropdown`;rl.Behavior=y({name:il,extends:[`Field`],selector:e=>e.props[`x-component`]===il,designerProps:{propsSchema:F(P[il])},designerLocales:O[il]}),rl.Resource=b(`Buttons`,{icon:il,elements:[{componentName:`Field`,props:{type:`array`,"x-component":il}}]});var al=x(({value:e,description:t,...n})=>(0,D.jsx)(Qe,{...n,description:e||t})),Q=`Empty`;al.Behavior=y({name:Q,extends:[`Field`],selector:e=>e.props[`x-component`]===Q,designerProps:{propsSchema:F(P[Q])},designerLocales:O[Q]}),al.Resource=b(`Displays`,{icon:Q,elements:[{componentName:`Field`,props:{type:`string`,"x-component":Q}}]});var ol=`x-component-props.children`,sl=x(({value:e,children:t,variant:n=`text`,level:r=1,className:i,...a})=>{let o=e??t,s={"data-content-editable":ol,className:(0,Hi.default)(`dn-typography`,i)};return n===`title`?(0,D.jsx)(Nt.Title,{level:r,...s,...a,children:o}):n===`paragraph`?(0,D.jsx)(Nt.Paragraph,{...s,...a,children:o}):(0,D.jsx)(Nt.Text,{...s,...a,children:o})}),cl=`Typography`;sl.Behavior=y({name:cl,extends:[`Field`],selector:e=>e.props[`x-component`]===cl,designerProps:{propsSchema:F(P[cl])},designerLocales:O[cl]}),sl.Resource=b(`Displays`,{icon:cl,elements:[{componentName:`Field`,props:{type:`string`,"x-component":cl}}]});var ll=x(({value:e,defaultValue:t,options:n,...r})=>(0,D.jsx)(ge,{...r,options:n||[`选项一`,`选项二`,`选项三`],value:e??t})),ul=`Segmented`;ll.Behavior=y({name:ul,extends:[`Field`],selector:e=>e.props[`x-component`]===ul,designerProps:{propsSchema:F(P[ul])},designerLocales:O[ul]}),ll.Resource=b(`Buttons`,{icon:ul,elements:[{componentName:`Field`,props:{type:`string`,"x-component":ul}}]});var dl=x(e=>(0,D.jsx)(pn,{...e})),fl=`Carousel`;dl.Behavior=y({name:fl,extends:[`Field`],selector:e=>e.props[`x-component`]===fl,designerProps:{propsSchema:F(P[fl])},designerLocales:O[fl]}),dl.Resource=b(`Displays`,{icon:fl,elements:[{componentName:`Field`,props:{type:`array`,"x-component":fl}}]});var pl=x(e=>(0,D.jsx)(mt,{...e})),ml=`Calendar`;pl.Behavior=y({name:ml,extends:[`Field`],selector:e=>e.props[`x-component`]===ml,designerProps:{propsSchema:F(P[ml])},designerLocales:O[ml]}),pl.Resource=b(`Displays`,{icon:ml,elements:[{componentName:`Field`,props:{type:`string`,"x-component":ml}}]});var hl=x(({children:e,...t})=>{let n=_(),r=g();return(0,D.jsx)(Pt,{content:t.content||`水印文字`,...t,children:(0,D.jsx)(`div`,{...n,style:{minHeight:100},children:r.children.length?e:(0,D.jsx)(d,{})})})}),gl=`Watermark`;hl.Behavior=y({name:gl,extends:[`Field`],selector:e=>e.props[`x-component`]===gl,designerProps:{droppable:!0,propsSchema:I(P[gl])},designerLocales:O[gl]}),hl.Resource=b(`Layouts`,{icon:gl,elements:[{componentName:`Field`,props:{type:`void`,"x-component":gl,"x-component-props":{content:`水印文字`}}}]});var _l=x(({open:e,steps:t,...n})=>{let[r,i]=(0,E.useState)(0),a=(0,E.useRef)(e);return(0,E.useEffect)(()=>{a.current&&!e&&i(e=>e+1),a.current=e},[e]),(0,D.jsx)(ln,{...n,open:e,steps:t||[]},r)}),vl=`Tour`;_l.Behavior=y({name:vl,extends:[`Field`],selector:e=>e.props[`x-component`]===vl,designerProps:{propsSchema:F(P[vl])},designerLocales:O[vl]}),_l.Resource=b(`Displays`,{icon:vl,elements:[{componentName:`Field`,props:{type:`void`,"x-component":vl,"x-component-props":{open:!1},"x-reactions":{fulfill:{run:`$props({
  onFinish: () => {
    $self.componentProps.open = false
  },
  onClose: () => {
    $self.componentProps.open = false
  },
})
`}}}}]});var yl=e=>{let t=[];return e.children.forEach(e=>{R(e,`Splitter.Panel`)&&t.push(e)}),t},bl=x(e=>{let t=g(),n=_(),r=H(`Splitter`,e=>[new S({componentName:`Field`,props:{type:`void`,"x-component":`Splitter.Panel`,"x-component-props":{}},children:e})]),i=yl(t),a=()=>t.children?.length?(0,D.jsx)(at,{...e,style:{minHeight:200,...e.style},children:i.map(e=>{let t=e.props[`x-component-props`]||{};return(0,D.jsx)(at.Panel,{...t,children:E.createElement(`div`,{[r.props.nodeIdAttrName]:e.id,style:{padding:8,minHeight:80}},e.children.length?(0,D.jsx)(p,{node:e}):(0,D.jsx)(d,{}))},e.id)})}):(0,D.jsx)(d,{});return(0,D.jsxs)(`div`,{...n,children:[a(),(0,D.jsx)(L,{actions:[{title:t.getMessage(`addPanel`),icon:`AddPanel`,onClick:()=>{let e=new S({componentName:`Field`,props:{type:`void`,"x-component":`Splitter.Panel`,"x-component-props":{}}});t.append(e)}}]})]})});bl.Panel=e=>(0,D.jsx)(E.Fragment,{children:e.children}),bl.Behavior=y({name:`Splitter`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Splitter`,designerProps:{droppable:!0,allowAppend:(e,t)=>e.children.length===0||!!t?.every(e=>e.props[`x-component`]===`Splitter.Panel`),propsSchema:I(qo)},designerLocales:Ci},{name:`Splitter.Panel`,extends:[`Field`],selector:e=>e.props[`x-component`]===`Splitter.Panel`,designerProps:{droppable:!0,allowDrop:e=>e.props[`x-component`]===`Splitter`,propsSchema:I(qo.Panel)},designerLocales:wi}),bl.Resource=b(`Layouts`,{icon:`Splitter`,elements:[{componentName:`Field`,props:{type:`void`,"x-component":`Splitter`}}]});var xl=x(({value:e,defaultValue:t,...n})=>(0,D.jsx)(et,{...n,value:e??t})),Sl=`ColorPicker`;xl.Behavior=y({name:Sl,extends:[`Field`],selector:e=>e.props[`x-component`]===Sl,designerProps:{propsSchema:F(P[Sl])},designerLocales:O[Sl]}),xl.Resource=b(`Inputs`,{icon:Sl,elements:[{componentName:`Field`,props:{type:`string`,"x-component":Sl}}]});var Cl=[{key:`part-1`,href:`#part-1`,title:`第一部分`},{key:`part-2`,href:`#part-2`,title:`第二部分`},{key:`part-3`,href:`#part-3`,title:`第三部分`}],wl=x(({value:e,items:t,...n})=>{let r=V(e??t);return(0,D.jsx)(ue,{...n,items:r.length?r:Cl})}),Tl=`Anchor`;wl.Behavior=y({name:Tl,extends:[`Field`],selector:e=>e.props[`x-component`]===Tl,designerProps:{propsSchema:F(P[Tl])},designerLocales:O[Tl]}),wl.Resource=b(`Displays`,{icon:Tl,elements:[{componentName:`Field`,props:{type:`array`,"x-component":Tl}}]});var El=x(({value:e,defaultValue:t,options:n,...r})=>(0,D.jsx)(Ve,{...r,value:e??t,options:n||[{value:`afc163`,label:`afc163`},{value:`zombieJ`,label:`zombieJ`}]})),Dl=`Mentions`;El.Behavior=y({name:Dl,extends:[`Field`],selector:e=>e.props[`x-component`]===Dl,designerProps:{propsSchema:F(P[Dl])},designerLocales:O[Dl]}),El.Resource=b(`Inputs`,{icon:Dl,elements:[{componentName:`Field`,props:{type:`string`,"x-component":Dl}}]});var Ol=x(e=>(0,D.jsx)(Et,{...e})),kl=`ECharts`;Ol.Behavior=y({name:kl,extends:[`Field`],selector:e=>e.props[`x-component`]===kl,designerProps:{propsSchema:F(P[kl])},designerLocales:O[kl]}),Ol.Resource=b(`Charts`,{icon:kl,elements:[{componentName:`Field`,props:{type:`string`,"x-decorator":`FormItem`,"x-component":kl,"x-decorator-props":{style:{width:`inherit`}},"x-component-props":{height:300}}}]});var Al=x(e=>(0,D.jsx)(rn,{...e})),jl=`Mermaid`;Al.Behavior=y({name:jl,extends:[`Field`],selector:e=>e.props[`x-component`]===jl,designerProps:{propsSchema:F(P[jl])},designerLocales:O[jl]}),Al.Resource=b(`Charts`,{icon:jl,elements:[{componentName:`Field`,props:{type:`string`,"x-decorator":`FormItem`,"x-component":jl,"x-decorator-props":{style:{width:`inherit`}},"x-component-props":{mode:`both`,definition:`flowchart LR
  A[开始] --> B{判断}
  B -- 是 --> C[处理]
  B -- 否 --> D[结束]
  C --> D`}}}]});var Ml=x(e=>(0,D.jsx)(qt,{...e})),Nl=`Markdown`;Ml.Behavior=y({name:Nl,extends:[`Field`],selector:e=>e.props[`x-component`]===Nl,designerProps:{propsSchema:F(P[Nl])},designerLocales:O[Nl]}),Ml.Resource=b(`Displays`,{icon:Nl,elements:[{componentName:`Field`,props:{type:`string`,"x-decorator":`FormItem`,"x-component":Nl,"x-decorator-props":{style:{width:`inherit`}},"x-component-props":{mode:`both`,content:`# 标题

这里是 **Markdown** 内容。`}}}]});var Pl=`${Ft}:__preview__`,Fl=x(e=>(0,D.jsx)(wt,{...e,storageKey:Pl,readOnly:!0})),$=`Kanban`;Fl.Behavior=y({name:$,extends:[`Field`],selector:e=>e.props[`x-component`]===$,designerProps:{propsSchema:F(P[$])},designerLocales:O[$]}),Fl.Resource=b(`Displays`,{icon:$,elements:[{componentName:`Field`,props:{type:`string`,"x-decorator":`FormItem`,"x-component":$,"x-decorator-props":{style:{width:`inherit`}},"x-component-props":{storageKey:Ft,height:500}}}]});var Il=t({Alert:()=>mc,Anchor:()=>wl,ArrayCards:()=>Os,ArrayTable:()=>Ms,Avatar:()=>tl,Badge:()=>Ac,Breadcrumb:()=>Yc,Button:()=>Hs,Calendar:()=>pl,Card:()=>ys,Carousel:()=>dl,Cascader:()=>os,CheckableTag:()=>fc,Checkbox:()=>cs,CodeEditor:()=>vc,Collapse:()=>Fc,ColorPicker:()=>xl,DatePicker:()=>ms,Descriptions:()=>bc,Div:()=>Bs,Divider:()=>Js,Drawer:()=>$s,Dropdown:()=>rl,DynamicSchemaBlock:()=>Zs,ECharts:()=>Ol,Empty:()=>al,Field:()=>Li,FloatButton:()=>qs,FloatButtonBackTop:()=>Ks,FloatButtonGroup:()=>Gs,Form:()=>ns,FormCollapse:()=>Ls,FormGrid:()=>Rs,FormLayout:()=>zs,FormTab:()=>Fs,Iframe:()=>gc,Img:()=>Zc,Input:()=>rs,IteratorLayout:()=>Ys,Kanban:()=>Fl,List:()=>Gc,Markdown:()=>Ml,Mentions:()=>El,Menu:()=>Vc,Mermaid:()=>Al,Modal:()=>rc,NumberPicker:()=>ds,ObjectContainer:()=>xs,Pagination:()=>qc,Password:()=>ps,Popconfirm:()=>ac,Popover:()=>sc,Progress:()=>Mc,QRCode:()=>Vs,Radio:()=>ss,Rate:()=>us,Result:()=>wc,Segmented:()=>ll,Select:()=>is,Skeleton:()=>$c,Slider:()=>ls,Space:()=>bs,Spin:()=>lc,Splitter:()=>bl,Statistic:()=>Ec,Steps:()=>Sc,Switch:()=>_s,Table:()=>zc,Tabs:()=>Rc,Tag:()=>dc,Text:()=>vs,TimePicker:()=>hs,Timeline:()=>Oc,Tooltip:()=>tc,Tour:()=>_l,Transfer:()=>fs,Tree:()=>Uc,TreeSelect:()=>as,Typography:()=>sl,Upload:()=>gs,Watermark:()=>hl,createComponentSchema:()=>ts,createFieldSchema:()=>F,createVoidFieldSchema:()=>I}),Ll=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`div-bg`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#b7eb8f`})]})}),(0,D.jsx)(`rect`,{x:`90`,y:`115`,width:`844`,height:`795`,rx:`47`,fill:`none`}),(0,D.jsx)(`path`,{d:`M122.88 165.888h778.24c-9.216 0-16.384-7.168-16.384-16.384v713.728c0-9.216 7.168-16.384 16.384-16.384H122.88c9.216 0 16.384 7.168 16.384 16.384V150.016c0 8.192-6.656 15.872-16.384 15.872z m-32.768 684.544c0 26.112 20.992 47.104 47.104 47.104h750.08c26.112 0 47.104-20.992 47.104-47.104V162.304c0-26.112-20.992-47.104-47.104-47.104H137.216c-26.112 0-47.104 20.992-47.104 47.104v688.128z`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M336.384 651.264H243.2V344.576h91.648c92.672 2.048 140.288 53.248 142.336 154.112 1.024 103.424-46.08 154.624-140.8 152.576z m1.536-257.536h-43.008v211.456h44.544c59.392 2.048 88.064-33.28 87.552-106.496 0-70.144-29.696-104.96-89.088-104.96zM517.12 344.576h51.712v59.392H517.12V344.576z m0 78.848h51.712v227.84H517.12V423.424zM748.032 423.424h53.248l-81.408 227.84h-43.008l-76.8-227.84h53.248l46.08 162.816 48.64-162.816z`,fill:`#52c41a`})]}),Rl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsxs)(`defs`,{children:[(0,D.jsxs)(`linearGradient`,{id:`img-bg`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]}),(0,D.jsxs)(`linearGradient`,{id:`img-mountain`,x1:`0`,y1:`1`,x2:`1`,y2:`0`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})]}),(0,D.jsx)(`rect`,{x:`5`,y:`42`,width:`1017`,height:`940`,rx:`82`,fill:`none`}),(0,D.jsx)(`path`,{d:`M937.814 41.726 86.28736 41.726c-44.7304 0-81.3199 33.2452-81.3199 78.0483l0 782.5664c0 44.802 36.5885 81.4653 81.3199 81.4653l858.312704 0c44.7304 0 77.951-36.6633 77.951-81.4653L1022.551064 119.774208C1022.55 74.9711 982.5454 41.726 937.814 41.726z`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`332`,cy:`282`,r:`100`,fill:`#95de64`}),(0,D.jsx)(`circle`,{cx:`332`,cy:`282`,r:`60`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M119.508 885.0156c-9.3532 0-18.7791-3.2225-26.4356-9.815-17.0588-14.635-19.0454-40.3425-4.4104-57.4269l186.9906-281.855c13.8854-16.2345 37.9218-18.9491 55.1014-6.2269l164.9889 122.5349 295.6196-335.8177c14.0052-17.5677 88.2739-100.3162 131.7437-6.4686 0.0481-0.1454 0.0973 124.0873 0.1454 250.9363 0.0481 132.3039 0.0727 324.0182 0.0727 324.0182C922.4284 884.6746 119.895 885.0156 119.508 885.0156z`,fill:`url(#img-mountain)`})]}),zl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`qr-grad`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#95de64`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#b7eb8f`})]})}),(0,D.jsx)(`path`,{d:`M85.312 85.312V384H384V85.312H85.312zM0 0h469.248v469.248H0V0z m170.624 170.624h128v128h-128v-128z`,fill:`url(#qr-grad)`}),(0,D.jsx)(`path`,{d:`M0 554.624h469.248v469.248H0V554.624z m85.312 85.312v298.624H384V639.936H85.312z m85.312 85.312h128v128h-128v-128z`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M554.624 0h469.248v469.248H554.624V0z m85.312 85.312V384h298.624V85.312H639.936z m85.312 85.312h128v128h-128v-128z`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M725.248 554.624h85.312v213.248h128V554.624h85.312v213.248H1024v85.376h-298.752V639.936H639.936V1023.872H554.624V554.624h255.936v213.248H725.248z`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`938.688`,y:`938.56`,width:`85.312`,height:`85.312`,rx:`4`,fill:`#b7eb8f`}),(0,D.jsx)(`rect`,{x:`725.376`,y:`938.56`,width:`85.312`,height:`85.312`,rx:`4`,fill:`#b7eb8f`})]}),Bl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`btn-bg`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})}),(0,D.jsx)(`rect`,{x:`32`,y:`96`,width:`960`,height:`832`,rx:`32`,fill:`none`}),(0,D.jsx)(`rect`,{x:`32`,y:`96`,width:`960`,height:`832`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`64`}),(0,D.jsx)(`path`,{d:`M294.4 499.2c6.4 0 6.4-6.4 6.4-12.8 12.8-12.8 19.2-25.6 19.2-44.8 0-19.2-6.4-38.4-25.6-51.2-19.2-12.8-38.4-19.2-64-19.2H140.8v281.6h89.6c25.6 0 51.2-6.4 70.4-25.6 19.2-19.2 32-38.4 32-64 0-19.2-6.4-38.4-19.2-51.2-6.4-6.4-12.8-6.4-19.2-12.8z m-51.2-32c-6.4 6.4-12.8 12.8-25.6 12.8h-12.8v-51.2h19.2c32 0 32 12.8 32 19.2 0 12.8-6.4 19.2-12.8 19.2z m-38.4 70.4h19.2c44.8 0 44.8 19.2 44.8 25.6-6.4 12.8-6.4 19.2-12.8 25.6-6.4 0-12.8 6.4-25.6 6.4h-25.6v-57.6zM371.2 428.8H448v224h64V428.8h70.4v-57.6H371.2zM819.2 371.2v172.8l-108.8-172.8h-64v281.6h64V480l108.8 172.8h64V371.2z`,fill:`#95de64`})]}),Vl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`fb-grad`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#95de64`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})}),(0,D.jsx)(`path`,{d:`M307.746548 456.898031c10.026354-2.306532 16.3422-12.229532 14.133905-22.35924-4.710278-21.153786-5.51255-42.813085-2.105964-64.467267 14.638395-94.449115 103.374392-159.523203 197.926861-144.885832 22.255887 3.40761 43.313481 11.030218 62.465681 22.461571 8.92016 5.313006 20.351514 2.403746 25.566282-6.418176 5.316076-8.821923 2.407839-20.351514-6.4192-25.66759-23.356964-13.938454-48.825009-23.162536-75.898621-27.372417-114.806769-17.747199-222.792179 61.163011-240.534261 176.065971-4.01443 26.270317-3.212158 52.638871 2.604314 78.406744 1.905396 8.724709 9.625218 14.638395 18.246573 14.638395 1.307785 0.102331 2.707668-0.099261 4.01443-0.402159z`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M827.618842 596.167958c0-26.671453-10.526751-50.230008-28.073382-66.577324 17.643845-40.805358 27.572986-85.724407 27.572986-133.052319 0-185.290053-150.696164-335.987241-335.991334-335.987241-185.290053 0-335.987241 150.696164-335.987241 335.987241 0 110.997 54.244438 209.358215 137.365554 270.618441 0.596588 3.310396 1.302669 6.618744 2.304486 9.92914 3.207042 10.824533 7.520277 20.448728 13.032828 28.875654 30.182416 45.922912 64.271816 97.959056 98.159623 148.694577 34.290991 51.332109 84.020602 83.315544 147.5935 94.947466 8.018627 1.404999 15.338337 2.408863 22.35924 3.310395 3.406586 0.49835 6.814196 0.901533 10.226923 1.405a53.918004 53.918004 0 0 0 8.018627 0.602727h37.899168c3.010567 0 6.016017-0.201591 8.925277-0.706081 3.308349-0.49835 6.716982-1.101077 10.026354-1.600451 5.713119-0.905626 11.529591-1.807159 17.246803-2.809999 80.414471-13.836123 141.071969-74.299193 154.706501-154.10889 2.809999-15.941064 4.209882-32.082696 4.312212-47.828308 0.200568-59.854203 0.200568-67.37448 0.200568-91.639117 0.101307-12.332886 0.101307-29.178553 0.101307-60.060911z`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`})]}),Hl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`fbg-grad`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})}),(0,D.jsx)(`path`,{d:`M71.68 828.416V297.984c0-39.936 32.768-72.704 72.704-72.704H901.12c0-39.936-32.768-71.68-72.704-71.68H72.704C32.768 153.6 0 186.368 0 226.304v530.432c0 39.936 31.744 72.704 71.68 71.68 0 1.024 0 0 0 0z`,fill:`none`}),(0,D.jsx)(`path`,{d:`M353.28 598.016h-32.768v83.968H358.4c16.384 0 28.672-4.096 37.888-11.264 9.216-7.168 13.312-18.432 13.312-31.744 0-27.648-18.432-40.96-56.32-40.96zM385.024 560.128c8.192-7.168 13.312-17.408 13.312-30.72 0-22.528-15.36-33.792-46.08-33.792h-31.744v75.776h28.672c15.36-1.024 26.624-4.096 35.84-11.264z`,fill:`#52c41a`}),(0,D.jsx)(`path`,{d:`M950.272 275.456H194.56c-39.936 0-72.704 32.768-72.704 72.704v530.432c0 39.936 32.768 72.704 72.704 72.704h755.712c39.936 0 72.704-32.768 72.704-72.704V348.16c0-39.936-32.768-72.704-72.704-72.704z`,fill:`none`,stroke:`#52c41a`,strokeWidth:`20`}),(0,D.jsx)(`path`,{d:`M419.84 690.176c-15.36 13.312-33.792 19.456-57.344 19.456h-72.704V467.968h70.656c21.504 0 37.888 5.12 51.2 15.36 12.288 10.24 19.456 23.552 19.456 39.936 0 13.312-4.096 25.6-11.264 34.816-7.168 10.24-18.432 17.408-30.72 21.504v1.024c16.384 2.048 29.696 8.192 39.936 18.432s14.336 23.552 14.336 39.936c-1.024 21.504-8.192 37.888-23.552 51.2z m201.728-194.56h-69.632v214.016h-31.744V495.616H450.56v-27.648h171.008v27.648z m234.496 214.016H819.2L697.344 521.216c-3.072-5.12-6.144-10.24-8.192-15.36h-1.024c1.024 5.12 1.024 16.384 1.024 33.792v169.984h-30.72V467.968h38.912l118.784 185.344c5.12 9.216 9.216 14.336 10.24 16.384h1.024c-1.024-7.168-2.048-18.432-2.048-34.816V467.968h30.72v241.664z`,fill:`#95de64`})]}),Ul=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`fbt-grad`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#52c41a`})]})}),(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`512`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M512 0C230.4 0 0 230.4 0 512S230.4 1024 512 1024 1024 793.6 1024 512 793.6 0 512 0z m185.606564 582.393436h-70.393436c-12.813128 0-19.219692 6.406564-19.219692 19.219692v108.780308c0 6.406564-6.380308 12.813128-12.786872 12.813128H428.767179c-6.406564 0-12.786872-6.406564-12.786871-12.813128V595.232821c0-6.406564-6.406564-19.219692-19.193436-19.219693H326.367179c-6.380308 6.406564-6.380308 0-6.380307 0l179.173743-172.767179c6.406564-6.406564 12.813128-6.406564 19.219693 0l185.606564 172.767179s0 6.406564-6.406564 6.406564z m6.406564-217.586872H320.013128c-19.219692 0-32.032821-12.813128-32.03282-32.006564 0-19.193436 12.813128-32.006564 32.03282-32.006564h383.973744c19.219692 0 32.032821 12.813128 32.03282 32.006564 0 19.193436-12.813128 32.006564-32.03282 32.006564z`,fill:`#52c41a`})]}),Wl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`117`,y:`245`,width:`117`,height:`64`,rx:`32`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`373`,y:`245`,width:`117`,height:`64`,rx:`32`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`629`,y:`245`,width:`117`,height:`64`,rx:`32`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`117`,y:`714`,width:`117`,height:`64`,rx:`32`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`373`,y:`714`,width:`117`,height:`64`,rx:`32`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`629`,y:`714`,width:`117`,height:`64`,rx:`32`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`85`,y:`480`,width:`854`,height:`64`,rx:`32`,fill:`#95de64`})]}),Gl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`iter-bg`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#b7eb8f`})]})}),(0,D.jsx)(`rect`,{x:`64`,y:`64`,width:`896`,height:`896`,rx:`32`,fill:`none`}),(0,D.jsx)(`path`,{d:`M928.028444 64H96.028444c-19.228444 0-32.028444 12.8-32.028444 32.028444v831.943112c0 19.228444 12.8 32.028444 32.028444 32.028444h831.943112c19.228444 0 32.028444-12.8 32.028444-32.028444V96.028444c0-19.171556-12.8-31.971556-32.028444-31.971555zM896 896H128V128h768v768z`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M769.080889 536.803556v191.829333H349.582222l74.638222 66.104889-44.145777 47.217778-150.414223-143.416889 0.512-0.568889-0.568888-0.568889L380.131556 537.6l46.876444 43.235556-77.368889 82.659555h354.133333V536.803556h65.365334z`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M555.576889 436.679111v150.641778H487.537778V436.622222h68.039111z`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M650.865778 172.259556l147.683555 151.324444-0.568889 0.512 0.568889 0.568889-147.683555 155.306667-45.852445-45.795556 72.476445-74.126222H315.960889V485.262222H247.580444V293.432889h429.909334l-74.922667-75.264 48.298667-45.909333z`,fill:`#52c41a`})]}),Kl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`dsb-grad`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#95de64`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})}),(0,D.jsx)(`path`,{d:`M583.232 493.76a23.68 23.68 0 0 1 23.232 0l212.992 119.936a23.68 23.68 0 0 1 12.032 20.608v246.144a23.68 23.68 0 0 1-12.032 20.608l-212.992 119.936a23.68 23.68 0 0 1-23.232 0l-212.992-119.936a23.68 23.68 0 0 1-12.032-20.608V634.304a23.68 23.68 0 0 1 12.032-20.608z m11.584 47.808l-189.312 106.56v218.496l189.312 106.56 189.312-106.56v-218.496z m143.936 110.976a19.2 19.2 0 0 1 25.088 7.616l0.32 0.64a19.2 19.2 0 0 1-7.616 25.088l-141.248 79.104v164.608a19.2 19.2 0 0 1-19.2 18.24h-1.6a19.2 19.2 0 0 1-19.2-18.24v-164.608l-141.248-79.104a19.2 19.2 0 0 1-7.616-25.088l0.32-0.64a19.2 19.2 0 0 1 25.088-7.616l0.64 0.32 142.464 79.808 142.464-79.808z`,fill:`url(#dsb-grad)`}),(0,D.jsx)(`path`,{d:`M620.8 0a356.608 356.608 0 0 1 354.88 321.536l0.448 5.12h1.984a277.76 277.76 0 0 1 245.888 271.296v4.608a277.696 277.696 0 0 1-273.088 277.632h-44.8a41.024 41.024 0 0 1-0.96-82.048h40.96a195.648 195.648 0 0 0 3.264-391.296h-13.312a41.024 41.024 0 0 1-41.024-40.32V358.4v-1.792a274.56 274.56 0 0 0-270.016-274.496H595.2a274.56 274.56 0 0 0-274.496 270.016v14.144a41.024 41.024 0 0 1-40.064 41.024h-2.944a195.648 195.648 0 0 0-3.264 391.296h10.496a41.024 41.024 0 0 1 0.96 82.048h-8.192a277.696 277.696 0 0 1-40.64-552.448l2.752-0.384v-0.384A356.608 356.608 0 0 1 589.312 0h32z`,fill:`#95de64`})]}),ql=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`drawer-bg`,x1:`0`,y1:`0`,x2:`0`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})}),(0,D.jsx)(`path`,{d:`M1016.992 652l-256-320c-6.08-7.584-15.264-12-24.992-12l-448 0c-9.728 0-18.912 4.416-24.992 12l-256 320c-4.544 5.664-7.008 12.736-7.008 20l0 288c0 35.36 28.64 64 64 64l896 0c35.36 0 64-28.64 64-64l0-288c0-7.264-2.464-14.304-7.008-20zM960 704l-224 0-128 128-192 0-128-128-224 0 0-20.768 239.392-299.232 417.248 0 239.392 299.232 0 20.768z`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`path`,{d:`M736 512l-448 0c-17.664 0-32-14.336-32-32s14.336-32 32-32l448 0c17.664 0 32 14.336 32 32s-14.336 32-32 32z`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M800 640l-576 0c-17.664 0-32-14.336-32-32s14.336-32 32-32l576 0c17.664 0 32 14.336 32 32s-14.336 32-32 32z`,fill:`#b7eb8f`})]}),Jl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`tooltip-bg`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})}),(0,D.jsx)(`rect`,{x:`0`,y:`320`,width:`1024`,height:`512`,rx:`64`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M352 381.568l125.28-133.76a32 32 0 0 1 47.808 1.248l111.84 132.48H352z`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M172.416 640v-105.6h40.32v-28.992H97.344v28.992H137.28V640h35.136z m118.656 1.536c41.664 0 72.768-29.568 72.768-68.928 0-38.976-31.104-68.16-72.768-68.16s-72.768 28.992-72.768 68.16c0 39.36 31.104 68.928 72.768 68.928z m0.384-29.952c-19.968 0-37.056-16.896-37.056-38.784 0-21.888 16.896-38.4 37.056-38.4 20.16 0 36.288 16.512 36.288 38.4 0 21.888-16.128 38.784-36.288 38.784z m153.984 29.952c41.664 0 72.768-29.568 72.768-68.928 0-38.976-31.104-68.16-72.768-68.16s-72.768 28.992-72.768 68.16c0 39.36 31.104 68.928 72.768 68.928z m0.384-29.952c-19.968 0-37.056-16.896-37.056-38.784 0-21.888 16.896-38.4 37.056-38.4 20.16 0 36.288 16.512 36.288 38.4 0 21.888-16.128 38.784-36.288 38.784zM627.84 640v-29.952h-57.024v-104.64H535.68V640h92.16z m79.296 0v-105.6h40.32v-28.992h-115.392v28.992H672V640h35.136z m89.664 0v-134.592h-35.136V640H796.8z m61.248 0v-37.248h24c34.368 0 54.144-18.432 54.144-50.112 0-29.952-19.776-47.232-54.144-47.232h-59.136V640h35.136z m22.272-65.28h-22.272v-41.28h22.272c14.208 0 22.464 7.104 22.464 20.352 0 13.632-8.256 20.928-22.464 20.928z`,fill:`#52c41a`})]}),Yl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsxs)(`defs`,{children:[(0,D.jsxs)(`linearGradient`,{id:`modal-header`,x1:`0`,y1:`0`,x2:`1`,y2:`0`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]}),(0,D.jsxs)(`linearGradient`,{id:`modal-body`,x1:`0`,y1:`0`,x2:`0`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#b7eb8f`})]})]}),(0,D.jsx)(`path`,{d:`M917.333 85.333H106.667C47.85 85.333 0 133.184 0 192v597.333C0 848.15 47.85 896 106.667 896h810.666C976.15 896 1024 848.15 1024 789.333V192c0-58.816-47.85-106.667-106.667-106.667zM106.667 128h810.666c35.286 0 64 28.715 64 64v106.667H42.667V192c0-35.285 28.714-64 64-64z`,fill:`none`,stroke:`#52c41a`,strokeWidth:`20`}),(0,D.jsx)(`path`,{d:`M42.667 298.667h938.666v448c0 35.286-28.714 64-64 64H106.667c-35.286 0-64-28.714-64-64v-448z`,fill:`none`}),(0,D.jsx)(`path`,{d:`M917.333 85.333H106.667C47.85 85.333 0 133.184 0 192v597.333C0 848.15 47.85 896 106.667 896h810.666C976.15 896 1024 848.15 1024 789.333V192c0-58.816-47.85-106.667-106.667-106.667z`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`170.667`,cy:`213.333`,r:`42.667`,fill:`#95de64`}),(0,D.jsx)(`circle`,{cx:`298.667`,cy:`213.333`,r:`42.667`,fill:`#b7eb8f`}),(0,D.jsx)(`circle`,{cx:`426.667`,cy:`213.333`,r:`42.667`,fill:`#95de64`})]}),Xl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`pc-bg`,x1:`0`,y1:`0`,x2:`0`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})}),(0,D.jsx)(`path`,{d:`M64 192h896v576H621.248L512 877.248 402.752 768H64V192z`,fill:`none`}),(0,D.jsx)(`path`,{d:`M64 192h896v576H621.248L512 877.248 402.752 768H64V192z`,fill:`none`,stroke:`#b7eb8f`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`640`,y:`448`,width:`192`,height:`96`,rx:`8`,fill:`#b7eb8f`}),(0,D.jsx)(`rect`,{x:`192`,y:`416`,width:`128`,height:`32`,rx:`8`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`192`,y:`448`,width:`192`,height:`32`,rx:`8`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`320`,y:`256`,width:`512`,height:`64`,rx:`8`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`192`,y:`256`,width:`64`,height:`64`,rx:`8`,fill:`#95de64`})]}),Zl=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`popover-bg`,x1:`0`,y1:`0`,x2:`0`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]})}),(0,D.jsx)(`path`,{d:`M234.88 179.328L349.653333 85.333333l115.2 93.994667 375.68 0.042667a72.533333 72.533333 0 0 1 72.533334 72.533333v597.333333a72.533333 72.533333 0 0 1-72.533334 72.533334h-682.666666a72.533333 72.533333 0 0 1-72.533334-72.533334v-597.333333l0.256-6.229333A72.533333 72.533333 0 0 1 157.866667 179.370667h77.013333z`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`285.867`,y:`395.52`,width:`453.333`,height:`59.733`,rx:`12`,fill:`#95de64`}),(0,D.jsx)(`rect`,{x:`285.867`,y:`608.853`,width:`453.333`,height:`59.733`,rx:`12`,fill:`#b7eb8f`})]}),Ql=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`path`,{d:`M256 529.066667H85.333333a17.066667 17.066667 0 1 1 0-34.133334h170.666667a17.066667 17.066667 0 0 1 0 34.133334z`,opacity:`.3`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M99.84 640a17.066667 17.066667 0 0 1-4.437333-33.553067l164.693333-44.373333a17.066667 17.066667 0 1 1 8.891733 32.9728l-164.693333 44.373333a17.544533 17.544533 0 0 1-4.4544 0.580267z`,opacity:`.35`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M264.533333 462.523733a16.896 16.896 0 0 1-4.369066-0.580266l-164.693334-43.52a17.0496 17.0496 0 1 1 8.721067-32.989867l164.693333 43.52a17.066667 17.066667 0 1 1-4.352 33.570133z`,opacity:`.25`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M384.017067 307.2a17.032533 17.032533 0 0 1-14.7968-8.533333l-85.333334-147.626667a17.066667 17.066667 0 0 1 29.559467-17.083733l85.333333 147.626666A17.066667 17.066667 0 0 1 384.017067 307.2z`,opacity:`.15`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M639.982933 307.2a17.0496 17.0496 0 0 1-14.762666-25.6l85.333333-147.626667a17.066667 17.066667 0 1 1 29.559467 17.066667l-85.333334 147.626667a17.032533 17.032533 0 0 1-14.7968 8.533333z`,opacity:`.95`,fill:`#52c41a`}),(0,D.jsx)(`path`,{d:`M692.906667 347.306667a17.066667 17.066667 0 0 1-12.117334-29.098667l120.337067-121.173333a17.066667 17.066667 0 1 1 24.234667 24.046933l-120.337067 121.173333a17.1008 17.1008 0 0 1-12.117333 5.051734z`,opacity:`.9`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M733.883733 401.066667a17.066667 17.066667 0 0 1-8.5504-31.8464l147.626667-85.333334a17.0496 17.0496 0 1 1 17.066667 29.5424l-147.626667 85.333334a16.776533 16.776533 0 0 1-8.516267 2.304z`,opacity:`.85`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M512 273.066667a17.066667 17.066667 0 0 1-17.066667-17.066667V85.333333a17.066667 17.066667 0 0 1 34.133334 0v170.666667a17.066667 17.066667 0 0 1-17.066667 17.066667z`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M578.577067 281.6a17.066667 17.066667 0 0 1-16.520534-21.418667l43.52-164.693333a17.066667 17.066667 0 0 1 33.006934 8.721067l-43.52 164.693333a17.066667 17.066667 0 0 1-16.4864 12.6976z`,opacity:`.98`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M445.44 282.453333a17.066667 17.066667 0 0 1-16.469333-12.629333l-44.373334-164.693333a17.066667 17.066667 0 0 1 32.955734-8.891734l44.373333 164.693334a17.066667 17.066667 0 0 1-16.4864 21.521066z`,opacity:`.1`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M924.177067 640c-1.4848 0-2.9696-0.187733-4.4544-0.580267l-164.693334-44.373333a17.066667 17.066667 0 0 1 8.874667-32.9728l164.693333 44.373333a17.066667 17.066667 0 0 1-4.420266 33.553067z`,opacity:`.75`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M881.476267 742.4a17.015467 17.015467 0 0 1-8.482134-2.269867l-148.48-85.333333a17.0496 17.0496 0 1 1 16.9984-29.5936l148.48 85.333333a17.0496 17.0496 0 0 1-8.516266 31.863467z`,opacity:`.7`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M813.226667 830.293333a17.015467 17.015467 0 0 1-12.066134-5.000533l-120.337066-120.337067a17.0496 17.0496 0 1 1 24.132266-24.132266l120.337067 120.337066a17.0496 17.0496 0 0 1-12.066133 29.1328z`,opacity:`.65`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M938.666667 529.066667H768a17.066667 17.066667 0 1 1 0-34.133334h170.666667a17.066667 17.066667 0 1 1 0 34.133334z`,opacity:`.8`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M401.066667 941.226667a17.066667 17.066667 0 0 1-16.4864-21.504l44.373333-164.693334a17.066667 17.066667 0 1 1 32.955733 8.874667l-44.373333 164.693333a17.066667 17.066667 0 0 1-16.469333 12.629334z`,opacity:`.5`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M298.6496 898.56a17.066667 17.066667 0 0 1-14.779733-25.565867l85.333333-148.48a17.083733 17.083733 0 0 1 29.5936 16.9984l-85.333333 148.48a17.032533 17.032533 0 0 1-14.813867 8.567467z`,opacity:`.45`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M512 955.733333a17.066667 17.066667 0 0 1-17.066667-17.066666V768a17.066667 17.066667 0 1 1 34.133334 0v170.666667a17.066667 17.066667 0 0 1-17.066667 17.066666z`,opacity:`.55`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M725.3504 898.56a17.032533 17.032533 0 0 1-14.7968-8.533333l-85.333333-147.626667a17.066667 17.066667 0 0 1 29.559466-17.066667l85.333334 147.626667a17.066667 17.066667 0 0 1-14.762667 25.6z`,opacity:`.6`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M622.062933 942.08c-7.509333 0-14.421333-5.0176-16.469333-12.629333l-44.3904-164.693334a17.066667 17.066667 0 1 1 32.9728-8.874666l44.3904 164.693333a17.066667 17.066667 0 0 1-16.503467 21.504z`,opacity:`.58`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M759.4496 463.36a17.083733 17.083733 0 0 1-4.420267-33.553067l164.693334-44.373333a17.066667 17.066667 0 0 1 8.874666 32.955733l-164.693333 44.373334a16.657067 16.657067 0 0 1-4.4544 0.597333z`,opacity:`.73`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M330.24 347.306667a17.015467 17.015467 0 0 1-12.066133-5.000534l-120.32-120.32a17.0496 17.0496 0 1 1 24.132266-24.132266l120.32 120.32a17.0496 17.0496 0 0 1-12.066133 29.1328z`,opacity:`.18`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M290.116267 401.066667a17.032533 17.032533 0 0 1-8.533334-2.286934l-147.626666-85.333333a17.066667 17.066667 0 1 1 17.083733-29.5424l147.626667 85.333333a17.066667 17.066667 0 0 1-8.5504 31.829334z`,opacity:`.22`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M142.523733 742.4a17.066667 17.066667 0 0 1-8.567466-31.8464l147.626666-85.333333a17.066667 17.066667 0 1 1 17.083734 29.559466l-147.626667 85.333334a16.930133 16.930133 0 0 1-8.516267 2.286933z`,opacity:`.38`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M209.92 830.293333a17.066667 17.066667 0 0 1-12.117333-29.098666l120.32-121.173334a17.066667 17.066667 0 0 1 24.2176 24.029867l-120.32 121.1904a16.896 16.896 0 0 1-12.100267 5.051733z`,opacity:`.42`,fill:`#95de64`})]}),$l=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`tag-grad`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#52c41a`})]})}),(0,D.jsx)(`path`,{d:`M1006.933333 0H614.4c-3.413333 0-10.24 3.413333-13.653333 3.413333L3.413333 600.746667c-6.826667 6.826667-6.826667 17.066667 0 23.893333l392.533334 392.533333c3.413333 3.413333 6.826667 3.413333 13.653333 3.413334 3.413333 0 10.24-3.413333 13.653333-6.826667l597.333334-614.4c3.413333-3.413333 3.413333-6.826667 3.413333-10.24V13.653333c0-6.826667-6.826667-13.653333-17.066667-13.653333z`,fill:`url(#tag-grad)`}),(0,D.jsx)(`circle`,{cx:`785.067`,cy:`238.933`,r:`102.4`,fill:`#b7eb8f`}),(0,D.jsx)(`circle`,{cx:`785.067`,cy:`238.933`,r:`60`,fill:`#95de64`})]}),eu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1088 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsxs)(`defs`,{children:[(0,D.jsxs)(`linearGradient`,{id:`ctag-grad`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#95de64`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#95de64`})]}),(0,D.jsxs)(`linearGradient`,{id:`ctag-grad2`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#b7eb8f`})]})]}),(0,D.jsx)(`path`,{d:`M992 64 768 64c-52.8 0-126.56 30.56-163.872 67.872L227.872 508.128c-37.344 37.344-37.344 98.432 0 135.776l280.224 280.224c37.344 37.344 98.432 37.344 135.776 0l376.224-376.224C1057.44 510.56 1088 436.8 1088 384L1088 160C1088 107.2 1044.8 64 992 64z`,fill:`url(#ctag-grad)`}),(0,D.jsx)(`circle`,{cx:`864`,cy:`288`,r:`96`,fill:`#b7eb8f`}),(0,D.jsx)(`circle`,{cx:`864`,cy:`288`,r:`56`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M86.624 598.624 428.992 940.992C392.736 960.16 346.528 954.528 316.128 924.128L35.872 643.872C-1.44 606.56-1.44 545.44 35.872 508.128L412.128 131.872C449.44 94.56 523.2 64 576 64L86.624 553.376C74.176 565.824 74.176 586.176 86.624 598.624Z`,fill:`url(#ctag-grad2)`})]}),tu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`path`,{d:`M512 96L160 736a64 64 0 0056 96h592a64 64 0 0056-96L568 96a32 32 0 00-56 0z`,fill:`none`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinejoin:`round`}),(0,D.jsx)(`path`,{d:`M512 360v224`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`688`,r:`28`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`})]}),nu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`defs`,{children:(0,D.jsxs)(`linearGradient`,{id:`iframe-bg`,x1:`0`,y1:`0`,x2:`1`,y2:`1`,children:[(0,D.jsx)(`stop`,{offset:`0%`,stopColor:`#b7eb8f`}),(0,D.jsx)(`stop`,{offset:`100%`,stopColor:`#b7eb8f`})]})}),(0,D.jsx)(`rect`,{x:`2`,y:`2`,width:`1020`,height:`1020`,rx:`96`,fill:`none`}),(0,D.jsx)(`path`,{d:`M928 2H98c-52.944 0-96 43.056-96 96V928c0 52.944 43.056 96 96 96H928c52.944 0 96-43.056 96-96V98c0-52.944-43.056-96-96-96zM960 928c0 17.648-14.352 32-32 32H98c-17.648 0-32-14.352-32-32V98c0-17.648 14.352-32 32-32H928c17.648 0 32 14.352 32 32V928z`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M102 651.344h40.96v166.64h-40.96zM176.656 818h40.96v-64.368h61.792v-36.528h-61.792v-29.248h72.32v-36.512h-113.28zM439.056 704.944c0-27.392-19.92-53.6-56.88-53.6H316.16v166.64h40.96v-62.032h13.808l29.488 62.032h47.52l-36.048-69.52c13.104-6.544 27.168-20.816 27.168-43.52z m-58.768 16.848H357.12v-33.712h23.168c11.232 0 17.792 8.208 17.792 16.864s-6.544 16.848-17.792 16.848zM512.528 651.344l-60.624 166.64h42.848l8.192-24.8h51.248l7.728 24.8h42.848l-60.64-166.64h-31.6z m1.888 107.664l14.976-44.464 14.048 44.464h-29.024zM699.328 724.832l-37.456-73.488H621.6v166.656h40.976v-79.824l23.616 41.2h26.24l23.616-41.2v79.824h40.976V651.344h-40.256zM810.704 818h113.296v-36.512h-72.32v-29.264h61.792v-36.512H851.68v-27.856h72.32v-36.512h-113.296z`,fill:`#95de64`}),(0,D.jsx)(`path`,{d:`M337.68 526.432c6.24 6.256 14.432 9.376 22.624 9.376s16.384-3.12 22.624-9.376a32 32 0 0 0 0-45.248l-102.656-102.656 102.656-102.656a32 32 0 1 0-45.248-45.248l-114.496 114.496a47.312 47.312 0 0 0 0 66.816l114.496 114.496z`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M802.816 345.12l-114.48-114.496a32 32 0 1 0-45.248 45.264l102.64 102.656-102.64 102.656a32 32 0 0 0 45.248 45.248l114.448-114.464c8.96-8.928 13.872-20.8 13.872-33.44s-4.928-24.528-13.84-33.424z`,fill:`#b7eb8f`}),(0,D.jsx)(`path`,{d:`M485.76 580.608a31.968 31.968 0 0 0 36.88-26.208l57.792-341.056a32 32 0 0 0-26.208-36.896 31.888 31.888 0 0 0-36.896 26.208l-57.792 341.056a32.032 32.032 0 0 0 26.224 36.896z`,fill:`#95de64`})]}),ru=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`64`,y:`160`,width:`896`,height:`704`,rx:`64`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M64 280h896`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`circle`,{cx:`160`,cy:`220`,r:`20`,fill:`none`,stroke:`#52c41a`,strokeWidth:`16`}),(0,D.jsx)(`circle`,{cx:`240`,cy:`220`,r:`20`,fill:`none`,stroke:`#52c41a`,strokeWidth:`16`}),(0,D.jsx)(`circle`,{cx:`320`,cy:`220`,r:`20`,fill:`none`,stroke:`#52c41a`,strokeWidth:`16`}),(0,D.jsx)(`path`,{d:`M360 420L240 540l120 120`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`path`,{d:`M664 420l120 120-120 120`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`path`,{d:`M560 380l-96 320`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),iu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`192`,width:`832`,height:`640`,rx:`48`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M512 192v640`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M96 405h832`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M96 619h832`,stroke:`#52c41a`,strokeWidth:`40`})]}),au=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`192`,cy:`512`,r:`80`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`80`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`832`,cy:`512`,r:`80`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M288 512h128`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M608 512h128`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`})]}),ou=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`384`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M352 520l112 112 208-240`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),su=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`160`,width:`832`,height:`704`,rx:`48`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M224 624l160-160 128 128 224-224`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`path`,{d:`M688 368h128v128`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),cu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`path`,{d:`M256 160v704`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`circle`,{cx:`256`,cy:`288`,r:`56`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`256`,cy:`512`,r:`56`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`256`,cy:`736`,r:`56`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M384 288h448`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M384 512h448`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M384 736h448`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`})]}),lu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`128`,y:`288`,width:`512`,height:`512`,rx:`64`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`704`,cy:`256`,r:`128`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`})]}),uu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`416`,width:`832`,height:`192`,rx:`96`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`160`,y:`480`,width:`384`,height:`64`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`})]}),du=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`160`,width:`832`,height:`160`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`96`,y:`432`,width:`832`,height:`160`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`96`,y:`704`,width:`832`,height:`160`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M760 222l40 40 40-40`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),fu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`288`,width:`832`,height:`544`,rx:`48`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M160 288v-64a48 48 0 0148-48h160a48 48 0 0148 48v64`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinejoin:`round`}),(0,D.jsx)(`path`,{d:`M416 288h448`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`,strokeDasharray:`8 40`})]}),pu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`192`,width:`832`,height:`640`,rx:`48`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M96 384h832`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M96 576h832`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M373 384v448`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M651 384v448`,stroke:`#52c41a`,strokeWidth:`40`})]}),mu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`path`,{d:`M160 288h704`,stroke:`#52c41a`,strokeWidth:`64`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M160 512h704`,stroke:`#52c41a`,strokeWidth:`64`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M160 736h704`,stroke:`#52c41a`,strokeWidth:`64`,strokeLinecap:`round`})]}),hu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`192`,cy:`192`,r:`56`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M192 248v160`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M192 408h192`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M192 408v192`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M192 600h192`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`}),(0,D.jsx)(`circle`,{cx:`448`,cy:`408`,r:`48`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`circle`,{cx:`448`,cy:`600`,r:`48`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`path`,{d:`M496 408h192`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`}),(0,D.jsx)(`circle`,{cx:`736`,cy:`408`,r:`40`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`})]}),gu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`192`,width:`832`,height:`160`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`96`,y:`432`,width:`832`,height:`160`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`96`,y:`672`,width:`832`,height:`160`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`192`,cy:`272`,r:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`circle`,{cx:`192`,cy:`512`,r:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`circle`,{cx:`192`,cy:`752`,r:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`})]}),_u=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`400`,width:`128`,height:`128`,rx:`24`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`272`,y:`400`,width:`128`,height:`128`,rx:`24`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`448`,y:`400`,width:`128`,height:`128`,rx:`24`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`624`,y:`400`,width:`128`,height:`128`,rx:`24`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`800`,y:`400`,width:`128`,height:`128`,rx:`24`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M512 432l-48 32 48 32`,stroke:`#52c41a`,strokeWidth:`28`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),vu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`path`,{d:`M128 512h160`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M352 512h160`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M576 512h160`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M304 384l128 128-128 128`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`path`,{d:`M528 384l128 128-128 128`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),yu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`192`,cy:`320`,r:`96`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`rect`,{x:`336`,y:`256`,width:`560`,height:`56`,rx:`28`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`rect`,{x:`336`,y:`352`,width:`400`,height:`40`,rx:`20`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`rect`,{x:`96`,y:`512`,width:`832`,height:`48`,rx:`24`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`rect`,{x:`96`,y:`608`,width:`832`,height:`48`,rx:`24`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`rect`,{x:`96`,y:`704`,width:`560`,height:`48`,rx:`24`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`})]}),bu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`400`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`380`,r:`140`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M192 820c0-176 144-320 320-320s320 144 320 320`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`,fill:`none`})]}),xu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`192`,width:`832`,height:`160`,rx:`16`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M512 352v80`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`rect`,{x:`96`,y:`432`,width:`832`,height:`128`,rx:`8`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`rect`,{x:`96`,y:`592`,width:`832`,height:`128`,rx:`8`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`rect`,{x:`96`,y:`752`,width:`832`,height:`128`,rx:`8`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`})]}),Su=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`ellipse`,{cx:`512`,cy:`720`,rx:`320`,ry:`80`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`path`,{d:`M192 720V400l128-192h384l128 192v320`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`path`,{d:`M192 400h192l64 96h128l64-96h192`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),Cu=(0,D.jsx)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,D.jsx)(`text`,{x:`80`,y:`680`,fontFamily:`serif`,fontSize:`640`,fill:`#52c41a`,children:`T`})}),wu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`64`,y:`352`,width:`896`,height:`320`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`line`,{x1:`363`,y1:`352`,x2:`363`,y2:`672`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`line`,{x1:`661`,y1:`352`,x2:`661`,y2:`672`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`rect`,{x:`80`,y:`368`,width:`267`,height:`288`,rx:`24`,fill:`#52c41a`,opacity:`0.15`})]}),Tu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`160`,y:`192`,width:`704`,height:`512`,rx:`16`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M96 448l-64 64 64 64`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`path`,{d:`M928 448l64 64-64 64`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`circle`,{cx:`432`,cy:`784`,r:`24`,fill:`#52c41a`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`784`,r:`24`,fill:`#52c41a`,opacity:`0.4`}),(0,D.jsx)(`circle`,{cx:`592`,cy:`784`,r:`24`,fill:`#52c41a`,opacity:`0.4`})]}),Eu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`192`,width:`832`,height:`736`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`line`,{x1:`96`,y1:`384`,x2:`928`,y2:`384`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`line`,{x1:`320`,y1:`96`,x2:`320`,y2:`288`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`line`,{x1:`704`,y1:`96`,x2:`704`,y2:`288`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`rect`,{x:`192`,y:`464`,width:`128`,height:`96`,rx:`8`,fill:`#52c41a`,opacity:`0.3`}),(0,D.jsx)(`rect`,{x:`384`,y:`464`,width:`128`,height:`96`,rx:`8`,fill:`none`,stroke:`#52c41a`,strokeWidth:`24`}),(0,D.jsx)(`rect`,{x:`576`,y:`464`,width:`128`,height:`96`,rx:`8`,fill:`none`,stroke:`#52c41a`,strokeWidth:`24`}),(0,D.jsx)(`rect`,{x:`768`,y:`464`,width:`64`,height:`96`,rx:`8`,fill:`none`,stroke:`#52c41a`,strokeWidth:`24`})]}),Du=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`96`,width:`832`,height:`832`,rx:`16`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`text`,{x:`512`,y:`560`,textAnchor:`middle`,fontSize:`200`,fill:`#52c41a`,opacity:`0.25`,transform:`rotate(-22, 512, 512)`,fontFamily:`sans-serif`,children:`水印`}),(0,D.jsx)(`text`,{x:`200`,y:`320`,textAnchor:`middle`,fontSize:`120`,fill:`#52c41a`,opacity:`0.2`,transform:`rotate(-22, 200, 320)`,fontFamily:`sans-serif`,children:`水印`}),(0,D.jsx)(`text`,{x:`800`,y:`780`,textAnchor:`middle`,fontSize:`120`,fill:`#52c41a`,opacity:`0.2`,transform:`rotate(-22, 800, 780)`,fontFamily:`sans-serif`,children:`水印`})]}),Ou=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`80`,fill:`#52c41a`,opacity:`0.3`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`80`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`200`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`,strokeDasharray:`40 24`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`340`,fill:`none`,stroke:`#52c41a`,strokeWidth:`24`,strokeDasharray:`32 20`}),(0,D.jsx)(`rect`,{x:`560`,y:`240`,width:`280`,height:`160`,rx:`16`,fill:`none`,stroke:`#52c41a`,strokeWidth:`32`}),(0,D.jsx)(`path`,{d:`M560 320l-48-48`,stroke:`#52c41a`,strokeWidth:`32`,strokeLinecap:`round`})]}),ku=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`96`,y:`192`,width:`832`,height:`640`,rx:`16`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`line`,{x1:`512`,y1:`192`,x2:`512`,y2:`832`,stroke:`#52c41a`,strokeWidth:`40`,strokeDasharray:`24 16`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`28`,fill:`#52c41a`}),(0,D.jsx)(`path`,{d:`M448 480l-48 32 48 32M576 480l48 32-48 32`,stroke:`#52c41a`,strokeWidth:`28`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),Au=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`512`,cy:`420`,r:`280`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`400`,cy:`340`,r:`80`,fill:`#ff4d4f`,opacity:`0.7`}),(0,D.jsx)(`circle`,{cx:`624`,cy:`340`,r:`80`,fill:`#1677ff`,opacity:`0.7`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`500`,r:`80`,fill:`#52c41a`,opacity:`0.7`}),(0,D.jsx)(`rect`,{x:`352`,y:`760`,width:`320`,height:`80`,rx:`16`,fill:`#52c41a`,opacity:`0.3`,stroke:`#52c41a`,strokeWidth:`32`})]}),ju=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`512`,cy:`240`,r:`80`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`line`,{x1:`512`,y1:`320`,x2:`512`,y2:`880`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M256 560c0 0 80 160 256 160s256-160 256-160`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`,fill:`none`}),(0,D.jsx)(`line`,{x1:`256`,y1:`400`,x2:`768`,y2:`400`,stroke:`#52c41a`,strokeWidth:`36`,strokeLinecap:`round`})]}),Mu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`320`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`circle`,{cx:`512`,cy:`512`,r:`120`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M832 512c0 176-144 320-320 320-88 0-160-32-160-32v-96`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`,fill:`none`}),(0,D.jsx)(`text`,{x:`440`,y:`560`,fontSize:`200`,fill:`#52c41a`,fontFamily:`sans-serif`,fontWeight:`bold`,children:`@`})]}),Nu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`path`,{d:`M128 128v768h768`,stroke:`#52c41a`,strokeWidth:`40`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`rect`,{x:`208`,y:`560`,width:`96`,height:`336`,rx:`8`,fill:`#52c41a`,opacity:`0.7`}),(0,D.jsx)(`rect`,{x:`368`,y:`400`,width:`96`,height:`496`,rx:`8`,fill:`#52c41a`,opacity:`0.5`}),(0,D.jsx)(`rect`,{x:`528`,y:`480`,width:`96`,height:`416`,rx:`8`,fill:`#52c41a`,opacity:`0.7`}),(0,D.jsx)(`rect`,{x:`688`,y:`288`,width:`96`,height:`608`,rx:`8`,fill:`#52c41a`,opacity:`0.9`}),(0,D.jsx)(`polyline`,{points:`256,560 416,400 576,480 736,288`,stroke:`#1677ff`,strokeWidth:`28`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`circle`,{cx:`256`,cy:`560`,r:`20`,fill:`#1677ff`}),(0,D.jsx)(`circle`,{cx:`416`,cy:`400`,r:`20`,fill:`#1677ff`}),(0,D.jsx)(`circle`,{cx:`576`,cy:`480`,r:`20`,fill:`#1677ff`}),(0,D.jsx)(`circle`,{cx:`736`,cy:`288`,r:`20`,fill:`#1677ff`})]}),Pu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`64`,y:`432`,width:`160`,height:`80`,rx:`12`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`text`,{x:`144`,y:`480`,textAnchor:`middle`,dominantBaseline:`middle`,fontSize:`56`,fill:`#52c41a`,fontFamily:`sans-serif`,children:`A`}),(0,D.jsx)(`polygon`,{points:`512,352 640,472 512,592 384,472`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`text`,{x:`512`,y:`480`,textAnchor:`middle`,dominantBaseline:`middle`,fontSize:`56`,fill:`#52c41a`,fontFamily:`sans-serif`,children:`B`}),(0,D.jsx)(`rect`,{x:`800`,y:`432`,width:`160`,height:`80`,rx:`12`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`text`,{x:`880`,y:`480`,textAnchor:`middle`,dominantBaseline:`middle`,fontSize:`56`,fill:`#52c41a`,fontFamily:`sans-serif`,children:`C`}),(0,D.jsx)(`rect`,{x:`800`,y:`640`,width:`160`,height:`80`,rx:`12`,fill:`none`,stroke:`#52c41a`,strokeWidth:`36`}),(0,D.jsx)(`text`,{x:`880`,y:`688`,textAnchor:`middle`,dominantBaseline:`middle`,fontSize:`56`,fill:`#52c41a`,fontFamily:`sans-serif`,children:`D`}),(0,D.jsx)(`path`,{d:`M224 472h160`,stroke:`#52c41a`,strokeWidth:`28`,strokeLinecap:`round`,markerEnd:`url(#arr)`}),(0,D.jsx)(`path`,{d:`M640 472h160`,stroke:`#52c41a`,strokeWidth:`28`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M880 512v128`,stroke:`#52c41a`,strokeWidth:`28`,strokeLinecap:`round`}),(0,D.jsx)(`defs`,{children:(0,D.jsx)(`marker`,{id:`arr`,markerWidth:`8`,markerHeight:`8`,refX:`6`,refY:`3`,orient:`auto`,children:(0,D.jsx)(`path`,{d:`M0,0 L0,6 L8,3 z`,fill:`#52c41a`})})})]}),Fu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`64`,y:`192`,width:`896`,height:`640`,rx:`32`,fill:`none`,stroke:`#52c41a`,strokeWidth:`40`}),(0,D.jsx)(`path`,{d:`M160 680V344l128 192 128-192v336`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`}),(0,D.jsx)(`path`,{d:`M608 344v240`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`}),(0,D.jsx)(`path`,{d:`M512 584l96 96 96-96`,stroke:`#52c41a`,strokeWidth:`48`,strokeLinecap:`round`,strokeLinejoin:`round`,fill:`none`})]}),Iu=(0,D.jsxs)(`svg`,{viewBox:`0 0 1024 1024`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,D.jsx)(`rect`,{x:`64`,y:`64`,width:`256`,height:`896`,rx:`24`,fill:`#e6f4ff`}),(0,D.jsx)(`rect`,{x:`80`,y:`80`,width:`224`,height:`56`,rx:`12`,fill:`#1677ff`,opacity:`0.85`}),(0,D.jsx)(`rect`,{x:`80`,y:`156`,width:`224`,height:`100`,rx:`12`,fill:`#fff`,stroke:`#1677ff`,strokeWidth:`8`,opacity:`0.9`}),(0,D.jsx)(`rect`,{x:`80`,y:`276`,width:`224`,height:`80`,rx:`12`,fill:`#fff`,stroke:`#1677ff`,strokeWidth:`8`,opacity:`0.9`}),(0,D.jsx)(`rect`,{x:`384`,y:`64`,width:`256`,height:`896`,rx:`24`,fill:`#fff7e6`}),(0,D.jsx)(`rect`,{x:`400`,y:`80`,width:`224`,height:`56`,rx:`12`,fill:`#fa8c16`,opacity:`0.85`}),(0,D.jsx)(`rect`,{x:`400`,y:`156`,width:`224`,height:`100`,rx:`12`,fill:`#fff`,stroke:`#fa8c16`,strokeWidth:`8`,opacity:`0.9`}),(0,D.jsx)(`rect`,{x:`400`,y:`276`,width:`224`,height:`120`,rx:`12`,fill:`#fff`,stroke:`#fa8c16`,strokeWidth:`8`,opacity:`0.9`}),(0,D.jsx)(`rect`,{x:`400`,y:`416`,width:`224`,height:`80`,rx:`12`,fill:`#fff`,stroke:`#fa8c16`,strokeWidth:`8`,opacity:`0.9`}),(0,D.jsx)(`rect`,{x:`704`,y:`64`,width:`256`,height:`896`,rx:`24`,fill:`#f6ffed`}),(0,D.jsx)(`rect`,{x:`720`,y:`80`,width:`224`,height:`56`,rx:`12`,fill:`#52c41a`,opacity:`0.85`}),(0,D.jsx)(`rect`,{x:`720`,y:`156`,width:`224`,height:`80`,rx:`12`,fill:`#fff`,stroke:`#52c41a`,strokeWidth:`8`,opacity:`0.9`})]}),Lu=t({Alert:()=>tu,Anchor:()=>ju,Avatar:()=>bu,Badge:()=>lu,Breadcrumb:()=>vu,Button:()=>Bl,Calendar:()=>Eu,Carousel:()=>Tu,CheckableTag:()=>eu,CodeEditor:()=>ru,Collapse:()=>du,ColorPicker:()=>Au,Descriptions:()=>iu,Div:()=>Ll,Divider:()=>Wl,Drawer:()=>ql,Dropdown:()=>xu,DynamicSchemaBlock:()=>Kl,ECharts:()=>Nu,Empty:()=>Su,FloatButton:()=>Vl,FloatButtonBackTop:()=>Ul,FloatButtonGroup:()=>Hl,Iframe:()=>nu,Img:()=>Rl,IteratorLayout:()=>Gl,Kanban:()=>Iu,List:()=>gu,Markdown:()=>Fu,Mentions:()=>Mu,Menu:()=>mu,Mermaid:()=>Pu,Modal:()=>Yl,Pagination:()=>_u,Popconfirm:()=>Xl,Popover:()=>Zl,Progress:()=>uu,QRCode:()=>zl,Result:()=>ou,Segmented:()=>wu,Skeleton:()=>yu,Spin:()=>Ql,Splitter:()=>ku,Statistic:()=>su,Steps:()=>au,Table:()=>pu,Tabs:()=>fu,Tag:()=>$l,Timeline:()=>cu,Tooltip:()=>Jl,Tour:()=>Ou,Tree:()=>hu,Typography:()=>Cu,Watermark:()=>Du});function Ru(e,t){if(!e?.children)return[];for(let n of e.children){if(n.id===t)return e.children;if(n.children?.length){let e=Ru(n,t);if(e.length)return e}}return[]}function zu(e,t){return e.includes(`.`)||e.includes(`,`)?(i.error({content:`标识不能输入点(.)和逗号(,)`,duration:2}),{valid:!1,shouldRollback:!0}):t.includes(`Column`)&&/^\d+$/.test(e)?(i.error({content:`表格列的标识不能是纯数字！`,duration:2}),{valid:!1,shouldRollback:!0}):{valid:!0,shouldRollback:!1}}function Bu(e){let{newValue:t,oldValue:n,field:r,engine:a,selectedNode:o,onBlurBackupRef:s}=e,c=`标识${t}与其它字段重复！`;i.error({content:c,duration:2}),r.setSelfErrors(c);let l=a.workbench?.currentWorkspace;l?.history&&(l.history.locking=!0),o&&(o.props.cacheName=n??``),s.current=r.onBlur,r.onBlur=()=>{l?.history&&(l.history.locking=!1),o&&o.props.cacheName!==void 0&&(o.props.name=o.props.cacheName,o.props.cacheName=void 0),r.setSelfErrors(),s.current&&=(r.onBlur=s.current,null)}}function Vu(e){let{newValue:t,field:n,form:r,engine:i,selectedNode:a,onBlurBackupRef:o}=e;if(a&&r?.props?.values?.cacheName!==void 0){let e=i.workbench?.currentWorkspace;e?.history&&(e.history.locking=!1),a.props.name=t,a.props.cacheName=void 0,n.setSelfErrors(),o.current&&=(n.onBlur=o.current,null)}}function Hu(e){let{field:t,form:n,engine:r}=e,i={current:null};return(e,a)=>{if(n.id!==window.__fieldReactionFormId||!e)return;let o=(r.getAllSelectedNodes?.()||[])[0],{valid:s}=zu(e,o?.props?.[`x-component`]||``);if(!s){o&&(o.props.name=a);return}let c=o?.id||n.values?.[`x-designable-id`],l=r.getCurrentTree();if((l?Ru(l,c):[]).some(t=>t.props?.name===e&&t.id!==c)){Bu({newValue:e,oldValue:a,field:t,engine:r,selectedNode:o,onBlurBackupRef:i});return}Vu({newValue:e,field:t,form:n,engine:r,selectedNode:o,onBlurBackupRef:i})}}function Uu(e){return t=>{Fn(`name`,(t,n)=>{t.title===`字段标识`&&(window.__fieldReactionFormId=n.id,yn(()=>t.value,Hu({field:t,form:n,engine:e})))})}}ot(`https://gitee.com/bingoogolapple/bga-god-assistant-config/raw/master/npmCDNRegistry`);var{ErrorBoundary:Wu}=At;w.registerDesignerIcons(Lu),w.registerDesignerLocales({"zh-CN":{sources:{Inputs:`输入控件`,Layouts:`布局组件`,Arrays:`自增组件`,Displays:`展示组件`,Buttons:`按钮组件`,Charts:`图表组件`,Others:`其他`}},"en-US":{sources:{Inputs:`Inputs`,Layouts:`Layouts`,Arrays:`Arrays`,Displays:`Displays`,Buttons:`Buttons`,Charts:`Charts`,Others:`Others`}}});var Gu=()=>{let{antdLocale:e,language:t}=ee();(0,E.useEffect)(()=>{w.setDesignerLanguage(t)},[t]);let r=(0,E.useMemo)(()=>Jt({shortcuts:[new Ot({codes:[[Ut.Meta,Ut.S],[Ut.Control,Ut.S]],handler(e){Ke(e.engine)}})],rootComponentName:`Form`}),[]);(0,E.useEffect)(()=>{An().then(e=>r.setCurrentTree(e)).catch(e=>n.error(`loadRootTreeNode error`,e))},[r]);let i=Nn();return(0,D.jsx)(re,{locale:e,theme:{token:{colorPrimary:s}},children:(0,D.jsx)(o,{children:(0,D.jsx)(Te,{engine:r,children:(0,D.jsxs)(Ge,{logo:(0,D.jsx)(Bt,{}),actions:(0,D.jsx)(ye,{}),children:[(0,D.jsxs)(He,{children:[(0,D.jsx)(He.Item,{title:`panels.Agent`,icon:`Agent`,children:(0,D.jsx)($t,{pageId:i})}),(0,D.jsx)(He.Item,{title:`panels.Component`,icon:`Component`,children:(0,D.jsx)(ze,{sources:Object.values({...Il})})}),(0,D.jsx)(He.Item,{title:`panels.OutlinedTree`,icon:`Outline`,children:(0,D.jsx)(tt,{})}),(0,D.jsx)(He.Item,{title:`panels.History`,icon:`History`,children:(0,D.jsx)(vn,{})})]}),(0,D.jsx)(Ze,{id:`form`,children:(0,D.jsx)(me,{children:(0,D.jsxs)(Wu,{children:[(0,D.jsxs)(Ht,{children:[(0,D.jsx)(lt,{}),(0,D.jsx)(je,{use:[`DESIGNABLE`,`JSONTREE`,`MARKUP`,`PREVIEW`]})]}),(0,D.jsxs)(Je,{style:{height:`100%`},children:[(0,D.jsx)(xe,{type:`DESIGNABLE`,children:()=>(0,D.jsx)(ht,{components:{...Il}})}),(0,D.jsx)(xe,{type:`JSONTREE`,scrollable:!1,children:(e,t)=>(0,D.jsx)(Wt,{tree:e,onChange:t})}),(0,D.jsx)(xe,{type:`MARKUP`,scrollable:!1,children:e=>(0,D.jsx)(on,{tree:e})}),(0,D.jsx)(xe,{type:`PREVIEW`,children:e=>(0,D.jsx)(Wu,{children:(0,D.jsx)(en,{tree:e})})})]})]})})}),(0,D.jsx)(zt,{title:`panels.PropertySettings`,children:(0,D.jsx)(Wu,{children:(0,D.jsx)(fe,{uploadAction:`https://www.mocky.io/v2/5cc8019d300000980a055e76`,effects:Uu(r)})})})]})})})})};ae.injectGaContext(`lowcode-editor`).finally(()=>{In.createRoot(document.getElementById(`root`)).render((0,D.jsx)(te,{children:(0,D.jsx)(Gu,{})}))});